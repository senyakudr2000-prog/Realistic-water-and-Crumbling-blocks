package kruszenie;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import kruszenie.net.ChipsPayload;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.coordinates.BlockPosArgument;
import net.minecraft.commands.arguments.coordinates.Vec3Argument;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class KruszenieMod implements ModInitializer {
   public static final String MOD_ID = "kruszenie";
   public static final Logger LOG = LoggerFactory.getLogger("Kruszenie");
   public static final boolean DEBUG = Boolean.getBoolean("kruszenie.debug");
   public static BlockEntityType<FragmentBlockEntity> FRAGMENT_BE;
   public static Item HAMMER;
   public static Item SHOTGUN;
   public static SoundEvent GUN_SHOT;
   public static SoundEvent GUN_PUMP;
   public static SoundEvent HAMMER_HIT;
   public static SoundEvent RUBBLE;
   public static SoundEvent RUBBLE_SMALL;

   private static SoundEvent sound(String name) {
      ResourceLocation id = id(name);
      return Registry.register(BuiltInRegistries.SOUND_EVENT, id, SoundEvent.createVariableRangeEvent(id));
   }

   public static ResourceLocation id(String path) {
      return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
   }

   @Override
   public void onInitialize() {
      KruszenieConfig.load();
      Set<Block> fragmentBlocks = new HashSet<>();

      for (Materials.Group group : Materials.Group.values()) {
         group.block = Registry.register(
            BuiltInRegistries.BLOCK,
            id(group.id),
            new FragmentBlock(
               BlockBehaviour.Properties.of()
                  .mapColor(group.color)
                  .strength(1.5F, 6.0F)
                  .sound(group.sound)
                  .dynamicShape()
                  .forceSolidOn()
                  .noLootTable()
                  .pushReaction(PushReaction.BLOCK)
            )
         );
         fragmentBlocks.add(group.block);
      }

      FRAGMENT_BE = Registry.register(
         BuiltInRegistries.BLOCK_ENTITY_TYPE,
         id("fragment"),
         BlockEntityType.Builder.of(FragmentBlockEntity::new, fragmentBlocks.toArray(new Block[0])).build(null)
      );
      HAMMER = Registry.register(
         BuiltInRegistries.ITEM,
         id("sledgehammer"),
         new Item(
            new Item.Properties()
               .durability(1500)
               .attributes(
                  ItemAttributeModifiers.builder()
                     .add(
                        Attributes.ATTACK_DAMAGE,
                        new AttributeModifier(Item.BASE_ATTACK_DAMAGE_ID, 8.0, AttributeModifier.Operation.ADD_VALUE),
                        EquipmentSlotGroup.MAINHAND
                     )
                     .add(
                        Attributes.ATTACK_SPEED,
                        new AttributeModifier(Item.BASE_ATTACK_SPEED_ID, -3.2, AttributeModifier.Operation.ADD_VALUE),
                        EquipmentSlotGroup.MAINHAND
                     )
                     .build()
               )
         )
      );
      SHOTGUN = Registry.register(BuiltInRegistries.ITEM, id("shotgun"), new ShotgunItem(new Item.Properties().durability(600)));
      ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(entries -> entries.accept(HAMMER));
      ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.COMBAT).register(entries -> {
         entries.accept(HAMMER);
         entries.accept(SHOTGUN);
      });
      GUN_SHOT = sound("gun.shot");
      GUN_PUMP = sound("gun.pump");
      HAMMER_HIT = sound("hammer.hit");
      RUBBLE = sound("rubble");
      RUBBLE_SMALL = sound("rubble.small");
      PayloadTypeRegistry.playS2C().register(ChipsPayload.TYPE, ChipsPayload.CODEC);
      AttackBlockCallback.EVENT.register(Tools::hammer);
      CommandRegistrationCallback.EVENT.register((dispatcher, buildContext, selection) -> dispatcher.register(
         Commands.literal("kruszenie")
            .requires(source -> source.hasPermission(2))
            .then(
               Commands.literal("carve")
                  .then(
                     Commands.argument("pos", Vec3Argument.vec3(false))
                        .then(
                           Commands.argument("radius", DoubleArgumentType.doubleArg(0.05, 24.0))
                              .executes(ctx -> carve(ctx, 0.12))
                              .then(
                                 Commands.argument("rough", DoubleArgumentType.doubleArg(0.0, 0.6))
                                    .executes(ctx -> carve(ctx, DoubleArgumentType.getDouble(ctx, "rough")))
                              )
                        )
                  )
            )
            .then(Commands.literal("info").then(Commands.argument("pos", BlockPosArgument.blockPos()).executes(KruszenieMod::info)))
            .then(
               Commands.literal("repair")
                  .executes(ctx -> repair(ctx, 32))
                  .then(
                     Commands.argument("radius", IntegerArgumentType.integer(1, 256))
                        .executes(ctx -> repair(ctx, IntegerArgumentType.getInteger(ctx, "radius")))
                  )
            )
            .then(
               Commands.literal("option")
                  .then(
                     Commands.argument("name", StringArgumentType.word())
                        .then(Commands.argument("value", StringArgumentType.word()).executes(KruszenieMod::option))
                  )
            )
      ));
      LOG.info("Kruszenie: blocks crumble in {} cm voxels", 6.25F);
   }

   private static int carve(CommandContext<CommandSourceStack> ctx, double rough) {
      ServerLevel level = ctx.getSource().getLevel();
      Vec3 pos = Vec3Argument.getVec3(ctx, "pos");
      double radius = DoubleArgumentType.getDouble(ctx, "radius");
      long start = System.nanoTime();
      Carver.Result result = Carver.sphere(level, pos, radius, rough, level.getRandom().nextLong());
      String message = String.format(
         Locale.ROOT,
         "Kruszenie: carved %d voxels out of %d blocks (%d fragile) in %.2f ms",
         result.voxels,
         result.chips.size(),
         result.fragile,
         (System.nanoTime() - start) / 1000000.0
      );
      ctx.getSource().sendSuccess(() -> Component.literal(message), false);
      LOG.info("[Kruszenie] {}", message);
      return result.voxels;
   }

   public static int repair(ServerLevel level, BlockPos center, int radius) {
      ArrayList<FragmentBlockEntity> found = new ArrayList<>();
      int minChunkX = center.getX() - radius >> 4;
      int maxChunkX = center.getX() + radius >> 4;
      int minChunkZ = center.getZ() - radius >> 4;
      int maxChunkZ = center.getZ() + radius >> 4;
      long maxDistSq = (long)radius * radius;

      for (int cx = minChunkX; cx <= maxChunkX; cx++) {
         for (int cz = minChunkZ; cz <= maxChunkZ; cz++) {
            LevelChunk chunk = level.getChunkSource().getChunkNow(cx, cz);
            if (chunk != null) {
               for (BlockEntity be : chunk.getBlockEntities().values()) {
                  if (be instanceof FragmentBlockEntity fragment && fragment.getBlockPos().distSqr(center) <= maxDistSq) {
                     found.add(fragment);
                  }
               }
            }
         }
      }

      for (FragmentBlockEntity fragment : found) {
         level.setBlock(fragment.getBlockPos(), fragment.original(), 3);
      }

      return found.size();
   }

   private static int repair(CommandContext<CommandSourceStack> ctx, int radius) {
      ServerLevel level = ctx.getSource().getLevel();
      int count = repair(level, BlockPos.containing(ctx.getSource().getPosition()), radius);
      String message = "Kruszenie: " + count + " damaged blocks made whole again";
      ctx.getSource().sendSuccess(() -> Component.literal(message), false);
      LOG.info("[Kruszenie] {}", message);
      return count;
   }

   private static int option(CommandContext<CommandSourceStack> ctx) {
      String name = StringArgumentType.getString(ctx, "name");
      String value = StringArgumentType.getString(ctx, "value");
      boolean ok = KruszenieConfig.set(name, value);
      String message = ok ? "Kruszenie: " + name + " = " + value : "Kruszenie: no option " + name + " or bad value " + value;
      ctx.getSource().sendSuccess(() -> Component.literal(message), false);
      LOG.info("[Kruszenie] {}", message);
      return ok ? 1 : 0;
   }

   private static int info(CommandContext<CommandSourceStack> ctx) throws CommandSyntaxException {
      ServerLevel level = ctx.getSource().getLevel();
      BlockPos pos = BlockPosArgument.getBlockPos(ctx, "pos");
      BlockState state = level.getBlockState(pos);
      FragmentBlockEntity fragment = FragmentBlock.entity(level, pos);
      String message = fragment == null
         ? "Kruszenie: "
            + pos.toShortString()
            + " is "
            + state
            + ", light block "
            + level.getBrightness(LightLayer.BLOCK, pos)
            + " sky "
            + level.getBrightness(LightLayer.SKY, pos)
         : String.format(
            Locale.ROOT,
            "Kruszenie: %s was %s, %d of %d voxels left, closed faces %s, light block %d sky %d",
            pos.toShortString(),
            fragment.original(),
            fragment.count(),
            4096,
            Integer.toBinaryString(FragmentBlock.faces(state)),
            level.getBrightness(LightLayer.BLOCK, pos),
            level.getBrightness(LightLayer.SKY, pos)
         );
      ctx.getSource().sendSuccess(() -> Component.literal(message), false);
      LOG.info("[Kruszenie] {}", message);
      return fragment == null ? 0 : fragment.count();
   }
}
