package kruszenie;

import net.minecraft.world.level.block.state.BlockState;

public record FragmentData(BlockState state, long[] bits) {
}
