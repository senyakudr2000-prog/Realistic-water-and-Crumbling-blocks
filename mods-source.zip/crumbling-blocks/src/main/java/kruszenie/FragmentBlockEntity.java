package kruszenie;

import java.util.concurrent.atomic.AtomicLong;
import net.fabricmc.fabric.api.rendering.data.v1.RenderAttachmentBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.BitSetDiscreteVoxelShape;
import net.minecraft.world.phys.shapes.CubeVoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class FragmentBlockEntity extends BlockEntity implements RenderAttachmentBlockEntity {
   public static final AtomicLong CLIENT_LOADS = new AtomicLong();
   private BlockState original = Blocks.STONE.defaultBlockState();
   private long[] bits = Mask.full();
   private VoxelShape shape;
   private int count = 4096;

   public FragmentBlockEntity(BlockPos pos, BlockState state) {
      super(KruszenieMod.FRAGMENT_BE, pos, state);
   }

   public BlockState original() {
      return this.original;
   }

   public long[] bits() {
      return this.bits;
   }

   public int count() {
      return this.count;
   }

   public float fraction() {
      return Math.min(1.0F, (float)this.count / Materials.volume(this.original));
   }

   public void set(BlockState original, long[] bits) {
      this.original = original;
      this.bits = bits;
      this.count = Mask.count(bits);
      this.shape = null;
      this.setChanged();
      if (this.level != null) {
         this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), 2);
      }
   }

   public VoxelShape shape() {
      VoxelShape result = this.shape;
      if (result == null) {
         this.shape = result = build(this.bits);
      }

      return result;
   }

   private static VoxelShape build(long[] bits) {
      if (Mask.isFull(bits)) {
         return Shapes.block();
      } else if (Mask.isEmpty(bits)) {
         return Shapes.empty();
      } else {
         BitSetDiscreteVoxelShape grid = new BitSetDiscreteVoxelShape(16, 16, 16);

         for (int y = 0; y < 16; y++) {
            for (int z = 0; z < 16; z++) {
               int row = Mask.row(bits, y, z);

               while (row != 0) {
                  int x = Integer.numberOfTrailingZeros(row);
                  row &= row - 1;
                  grid.fill(x, y, z);
               }
            }
         }

         return new CubeVoxelShape(grid);
      }
   }

   @Override
   public Object getRenderAttachmentData() {
      return new FragmentData(this.original, this.bits);
   }

   @Override
   public Packet<ClientGamePacketListener> getUpdatePacket() {
      return ClientboundBlockEntityDataPacket.create(this);
   }

   @Override
   public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
      return this.saveCustomOnly(registries);
   }

   @Override
   protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
      super.saveAdditional(tag, registries);
      tag.put("State", NbtUtils.writeBlockState(this.original));
      tag.putLongArray("Bits", this.bits);
   }

   @Override
   protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
      super.loadAdditional(tag, registries);
      this.original = tag.contains("State", Tag.TAG_COMPOUND)
         ? NbtUtils.readBlockState(BuiltInRegistries.BLOCK.asLookup(), tag.getCompound("State"))
         : Blocks.STONE.defaultBlockState();
      long[] loaded = tag.getLongArray("Bits");
      this.bits = loaded.length == 64 ? loaded : Mask.full();
      this.count = Mask.count(this.bits);
      this.shape = null;
      if (this.level != null && this.level.isClientSide()) {
         CLIENT_LOADS.incrementAndGet();
         this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), 8);
      }
   }
}
