package kruszenie;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class FragmentBlock extends BaseEntityBlock {
   public static final MapCodec<FragmentBlock> CODEC = simpleCodec(FragmentBlock::new);
   public static final BooleanProperty[] FACE = new BooleanProperty[]{
      BlockStateProperties.DOWN,
      BlockStateProperties.UP,
      BlockStateProperties.NORTH,
      BlockStateProperties.SOUTH,
      BlockStateProperties.WEST,
      BlockStateProperties.EAST
   };
   private static final double T = 0.0625;
   private static final VoxelShape[] PLATE = new VoxelShape[]{
      Shapes.box(0.0, 0.0, 0.0, 1.0, 0.0625, 1.0),
      Shapes.box(0.0, 0.9375, 0.0, 1.0, 1.0, 1.0),
      Shapes.box(0.0, 0.0, 0.0, 1.0, 1.0, 0.0625),
      Shapes.box(0.0, 0.0, 0.9375, 1.0, 1.0, 1.0),
      Shapes.box(0.0, 0.0, 0.0, 0.0625, 1.0, 1.0),
      Shapes.box(0.9375, 0.0, 0.0, 1.0, 1.0, 1.0)
   };
   private static final VoxelShape[] OCCLUSION = new VoxelShape[64];

   public FragmentBlock(BlockBehaviour.Properties properties) {
      super(properties);
      BlockState state = this.stateDefinition.any();

      for (BooleanProperty property : FACE) {
         state = state.setValue(property, false);
      }

      this.registerDefaultState(state);
   }

   @Override
   public MapCodec<? extends BaseEntityBlock> codec() {
      return CODEC;
   }

   @Override
   public void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
      builder.add(FACE);
   }

   public static int faces(BlockState state) {
      int mask = 0;

      for (int i = 0; i < 6; i++) {
         if (state.getValue(FACE[i])) {
            mask |= 1 << i;
         }
      }

      return mask;
   }

   public static BlockState withFaces(BlockState state, int mask) {
      for (int i = 0; i < 6; i++) {
         state = state.setValue(FACE[i], (mask >> i & 1) != 0);
      }

      return state;
   }

   public static FragmentBlockEntity entity(BlockGetter level, BlockPos pos) {
      return level.getBlockEntity(pos) instanceof FragmentBlockEntity fragment ? fragment : null;
   }

   @Override
   public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
      return new FragmentBlockEntity(pos, state);
   }

   @Override
   public RenderShape getRenderShape(BlockState state) {
      return RenderShape.MODEL;
   }

   @Override
   public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
      FragmentBlockEntity fragment = entity(level, pos);
      return fragment == null ? Shapes.block() : fragment.shape();
   }

   @Override
   public VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
      FragmentBlockEntity fragment = entity(level, pos);
      return fragment == null ? Shapes.block() : fragment.shape();
   }

   @Override
   public VoxelShape getOcclusionShape(BlockState state, BlockGetter level, BlockPos pos) {
      return OCCLUSION[faces(state)];
   }

   @Override
   public boolean useShapeForLightOcclusion(BlockState state) {
      return true;
   }

   @Override
   public boolean propagatesSkylightDown(BlockState state, BlockGetter level, BlockPos pos) {
      return !state.getValue(BlockStateProperties.UP) && !state.getValue(BlockStateProperties.DOWN);
   }

   @Override
   public float getShadeBrightness(BlockState state, BlockGetter level, BlockPos pos) {
      return 1.0F;
   }

   @Override
   public float getDestroyProgress(BlockState state, Player player, BlockGetter level, BlockPos pos) {
      FragmentBlockEntity fragment = entity(level, pos);
      return fragment == null
         ? super.getDestroyProgress(state, player, level, pos)
         : fragment.original().getDestroyProgress(player, level, pos) / Math.max(0.25F, fragment.fraction());
   }

   @Override
   public ItemStack getCloneItemStack(LevelReader level, BlockPos pos, BlockState state) {
      FragmentBlockEntity fragment = entity(level, pos);
      return fragment == null ? ItemStack.EMPTY : new ItemStack(fragment.original().getBlock());
   }

   @Override
   public void spawnDestroyParticles(Level level, Player player, BlockPos pos, BlockState state) {
      FragmentBlockEntity fragment = entity(level, pos);
      level.levelEvent(player, 2001, pos, getId(fragment == null ? state : fragment.original()));
   }

   @Override
   public void playerDestroy(Level level, Player player, BlockPos pos, BlockState state, BlockEntity blockEntity, ItemStack tool) {
      player.causeFoodExhaustion(0.005F);
      if (blockEntity instanceof FragmentBlockEntity fragment && fragment.fraction() >= 0.5F) {
         dropResources(fragment.original(), level, pos, null, player, tool);
      }
   }

   @Override
   public ItemInteractionResult useItemOn(
      ItemStack stack, BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit
   ) {
      FragmentBlockEntity fragment = entity(level, pos);
      if (fragment == null || !(stack.getItem() instanceof BlockItem blockItem && blockItem.getBlock() == fragment.original().getBlock())) {
         return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
      } else if (level.isClientSide()) {
         return ItemInteractionResult.SUCCESS;
      } else {
         BlockState original = fragment.original();
         level.setBlock(pos, original, 3);
         SoundType sound = original.getSoundType();
         level.playSound(null, pos, sound.getPlaceSound(), SoundSource.BLOCKS, (sound.getVolume() + 1.0F) / 2.0F, sound.getPitch() * 0.8F);
         if (!player.getAbilities().instabuild) {
            stack.shrink(1);
         }

         return ItemInteractionResult.SUCCESS;
      }
   }

   public static boolean faceClosed(BlockState state, Direction direction) {
      return state.getValue(FACE[direction.ordinal()]);
   }

   static {
      for (int mask = 0; mask < 64; mask++) {
         VoxelShape shape = Shapes.empty();

         for (int i = 0; i < 6; i++) {
            if ((mask >> i & 1) != 0) {
               shape = Shapes.or(shape, PLATE[i]);
            }
         }

         OCCLUSION[mask] = shape;
      }
   }
}
