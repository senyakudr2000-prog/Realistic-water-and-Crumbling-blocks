package kruszenie.mixin;

import kruszenie.Blast;
import kruszenie.KruszenieConfig;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.ExplosionDamageCalculator;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 1.21.1 has no ServerExplosion: the server calls Explosion.explode() (collects the block list) and then
 * Explosion.finalizeExplosion(false) (destroys the blocks, drops items). We take over right before the latter
 * and replace the list of whole blocks with the blocks that are really gone.
 */
@Mixin(Explosion.class)
public abstract class ExplosionMixin {
   @Shadow
   @Final
   private Level level;
   @Shadow
   @Final
   private double x;
   @Shadow
   @Final
   private double y;
   @Shadow
   @Final
   private double z;
   @Shadow
   @Final
   private float radius;
   @Shadow
   @Final
   private ExplosionDamageCalculator damageCalculator;
   @Shadow
   @Final
   private Explosion.BlockInteraction blockInteraction;

   @Inject(method = "finalizeExplosion", at = @At("HEAD"))
   private void kruszenie$crater(boolean spawnParticles, CallbackInfo ci) {
      if (!KruszenieConfig.enabled || !KruszenieConfig.blasts) {
         return;
      }

      if (!(this.level instanceof ServerLevel serverLevel)) {
         return;
      }

      // KEEP: nothing is destroyed; TRIGGER_BLOCK (wind charge): only triggers blocks.
      if (this.blockInteraction == Explosion.BlockInteraction.KEEP || "TRIGGER_BLOCK".equals(this.blockInteraction.name())) {
         return;
      }

      if (this.radius < 0.3F || this.radius > 16.0F || !Blast.inBudget(serverLevel)) {
         return;
      }

      Blast.apply((Explosion)(Object)this, serverLevel, new Vec3(this.x, this.y, this.z), this.radius, this.damageCalculator, this.blockInteraction, ((Explosion)(Object)this).getToBlow());
   }
}
