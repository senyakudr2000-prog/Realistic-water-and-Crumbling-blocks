package kruszenie;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import net.fabricmc.loader.api.FabricLoader;

public final class KruszenieConfig {
   public static boolean enabled = true;
   public static boolean blasts = true;
   public static boolean looseFalls = true;
   public static float toolPower = 1.0F;
   public static float debris = 1.0F;
   public static boolean cornerShade = true;

   private KruszenieConfig() {
   }

   private static Path file() {
      return FabricLoader.getInstance().getConfigDir().resolve("kruszenie.properties");
   }

   public static void load() {
      Path var0 = file();
      Properties var1 = new Properties();

      try {
         if (Files.exists(var0)) {
            try (BufferedReader var2 = Files.newBufferedReader(var0)) {
               var1.load(var2);
            }
         } else {
            save();
         }
      } catch (IllegalArgumentException | IOException var7) {
         KruszenieMod.LOG.warn("Kruszenie: cannot read {}: {}", var0, var7.toString());
      }

      enabled = bool(var1, "enabled", true);
      blasts = bool(var1, "blasts", true);
      looseFalls = bool(var1, "looseFalls", true);
      toolPower = (float)num(var1, "toolPower", 1.0, 0.5, 2.0);
      debris = (float)num(var1, "debris", 1.0, 0.0, 2.0);
      cornerShade = bool(var1, "cornerShade", true);
   }

   public static void save() {
      try {
         Files.writeString(
            file(),
            String.join(
               System.lineSeparator(),
               "# Kruszenie - crumbling blocks (also editable in game: Options > Kruszenie...)",
               "enabled=" + enabled,
               "# explosions cut craters voxel by voxel instead of removing whole blocks",
               "blasts=" + blasts,
               "# what a break leaves hanging in the air drops",
               "looseFalls=" + looseFalls,
               "# strength of the sledgehammer and the shotgun (0.5..2)",
               "toolPower=" + fmt(toolPower),
               "# how many pieces fly, client side (0 = none, 1 = default, 2 = twice as many)",
               "debris=" + fmt(debris),
               "# shade the corners of broken surfaces by the voxels around them, client side",
               "cornerShade=" + cornerShade,
               ""
            )
         );
      } catch (IOException var1) {
         KruszenieMod.LOG.warn("Kruszenie: cannot write {}: {}", file(), var1.toString());
      }
   }

   public static boolean set(String var0, String var1) {
      try {
         switch (var0) {
            case "enabled":
               enabled = Boolean.parseBoolean(var1);
               break;
            case "blasts":
               blasts = Boolean.parseBoolean(var1);
               break;
            case "looseFalls":
               looseFalls = Boolean.parseBoolean(var1);
               break;
            case "toolPower":
               toolPower = Math.clamp(Float.parseFloat(var1), 0.5F, 2.0F);
               break;
            case "debris":
               debris = Math.clamp(Float.parseFloat(var1), 0.0F, 2.0F);
               break;
            case "cornerShade":
               cornerShade = Boolean.parseBoolean(var1);
               break;
            default:
               return false;
         }

         return true;
      } catch (NumberFormatException var4) {
         return false;
      }
   }

   private static String fmt(float var0) {
      return var0 == Math.rint(var0) ? Long.toString((long)var0) : Float.toString(var0);
   }

   private static boolean bool(Properties var0, String var1, boolean var2) {
      return Boolean.parseBoolean(var0.getProperty(var1, Boolean.toString(var2)).trim());
   }

   private static double num(Properties var0, String var1, double var2, double var4, double var6) {
      try {
         return Math.clamp(Double.parseDouble(var0.getProperty(var1, Double.toString(var2)).trim()), var4, var6);
      } catch (NumberFormatException var9) {
         KruszenieMod.LOG.warn("Kruszenie: bad value for {}, using {}", var1, var2);
         return var2;
      }
   }
}
