package kruszenie;

import java.util.IdentityHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.EmptyBlockGetter;
import net.minecraft.world.level.block.BasePressurePlateBlock;
import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ButtonBlock;
import net.minecraft.world.level.block.CarpetBlock;
import net.minecraft.world.level.block.CrossCollisionBlock;
import net.minecraft.world.level.block.DiodeBlock;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.FenceGateBlock;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.WallBlock;
import net.minecraft.world.level.block.piston.PistonBaseBlock;
import net.minecraft.world.level.block.piston.PistonHeadBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.shapes.VoxelShape;

public final class Materials {
   private static final Map<SoundType, Materials.Group> BY_SOUND = new IdentityHashMap<>();
   private static final Map<BlockState, long[]> MASKS = new ConcurrentHashMap<>();
   private static final long[] NONE = new long[0];

   private static void put(Materials.Group var0, SoundType... var1) {
      for (SoundType var5 : var1) {
         BY_SOUND.put(var5, var0);
      }
   }

   private Materials() {
   }

   public static Materials.Group group(BlockState var0) {
      return BY_SOUND.getOrDefault(var0.getSoundType(), Materials.Group.STONE);
   }

   public static boolean carvable(BlockState var0, BlockGetter var1, BlockPos var2) {
      if (!var0.isAir() && var0.getFluidState().isEmpty()) {
         Block var3 = var0.getBlock();
         if (!(var3 instanceof FragmentBlock) && !var0.hasBlockEntity() && !var0.is(Blocks.TNT)) {
            if (!var0.canOcclude() || var0.getRenderShape() != RenderShape.MODEL) {
               return false;
            } else if (var0.getLightEmission() > 0 || var0.getDestroySpeed(var1, var2) < 0.0F) {
               return false;
            } else if (var0.isSolidRender(var1, var2)) {
               return true;
            } else {
               return !(var3 instanceof CrossCollisionBlock)
                     && !(var3 instanceof WallBlock)
                     && !(var3 instanceof FenceGateBlock)
                     && !(var3 instanceof DoorBlock)
                     && !(var3 instanceof TrapDoorBlock)
                     && !(var3 instanceof BedBlock)
                     && !(var3 instanceof LadderBlock)
                     && !(var3 instanceof CarpetBlock)
                     && !(var3 instanceof BasePressurePlateBlock)
                     && !(var3 instanceof ButtonBlock)
                     && !(var3 instanceof BaseRailBlock)
                     && !(var3 instanceof DiodeBlock)
                     && !(var3 instanceof PistonHeadBlock)
                     && !(var3 instanceof PistonBaseBlock)
                  ? mask(var0) != null
                  : false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public static long[] mask(BlockState var0) {
      if (var0.isSolidRender(EmptyBlockGetter.INSTANCE, BlockPos.ZERO)) {
         return null;
      } else {
         long[] var1 = MASKS.computeIfAbsent(var0, var0x -> {
            VoxelShape var1x = var0x.getCollisionShape(EmptyBlockGetter.INSTANCE, BlockPos.ZERO);
            if (var1x.isEmpty()) {
               return NONE;
            } else {
               long[] var2 = new long[64];
               byte var3 = 16;
               var1x.forAllBoxes((var1xx, var3x, var5, var7, var9, var11) -> {
                  int var13 = Math.clamp((long)((int)Math.ceil(var1xx * 16.0 - 0.5)), 0, 16);
                  int var14 = Math.clamp((long)((int)Math.floor(var7 * 16.0 + 0.5)), 0, 16);
                  int var15 = Math.clamp((long)((int)Math.ceil(var3x * 16.0 - 0.5)), 0, 16);
                  int var16 = Math.clamp((long)((int)Math.floor(var9 * 16.0 + 0.5)), 0, 16);
                  int var17 = Math.clamp((long)((int)Math.ceil(var5 * 16.0 - 0.5)), 0, 16);
                  int var18 = Math.clamp((long)((int)Math.floor(var11 * 16.0 + 0.5)), 0, 16);

                  for (int var19 = var15; var19 < var16; var19++) {
                     for (int var20 = var17; var20 < var18; var20++) {
                        for (int var21 = var13; var21 < var14; var21++) {
                           Mask.set(var2, Mask.idx(var21, var19, var20));
                        }
                     }
                  }
               });
               return Mask.count(var2) < 512 ? NONE : var2;
            }
         });
         return var1 == NONE ? null : var1;
      }
   }

   public static int volume(BlockState var0) {
      long[] var1 = mask(var0);
      return var1 == null ? 4096 : Mask.count(var1);
   }

   public static long[] fresh(BlockState var0) {
      long[] var1 = mask(var0);
      return var1 == null ? Mask.full() : (long[])var1.clone();
   }

   public static boolean fragile(BlockState var0, BlockGetter var1, BlockPos var2) {
      if (var0.is(Blocks.TNT)) {
         return true;
      } else if (var0.isAir() || !var0.getFluidState().isEmpty() || var0.hasBlockEntity()) {
         return false;
      } else if (!(var0.getBlock() instanceof FragmentBlock) && !var0.isSolidRender(var1, var2)) {
         float var3 = var0.getDestroySpeed(var1, var2);
         return var3 >= 0.0F && var3 <= 3.0F;
      } else {
         return false;
      }
   }

   public static float softness(BlockState var0, BlockGetter var1, BlockPos var2) {
      float var3 = var0.getDestroySpeed(var1, var2);
      if (var3 < 0.0F) {
         return 0.0F;
      } else {
         return var3 < 0.05F ? 1.35F : Math.clamp((float)Math.pow(1.5 / var3, 0.4), 0.15F, 1.35F);
      }
   }

   static {
      put(
         Materials.Group.WOOD,
         SoundType.WOOD,
         SoundType.BAMBOO_WOOD,
         SoundType.NETHER_WOOD,
         SoundType.CHERRY_WOOD,
         SoundType.STEM,
         SoundType.CHISELED_BOOKSHELF,
         SoundType.LADDER,
         SoundType.SCAFFOLDING,
         SoundType.BAMBOO
      );
      put(Materials.Group.DIRT, SoundType.GRAVEL, SoundType.ROOTED_DIRT, SoundType.MUD, SoundType.SOUL_SOIL, SoundType.SUSPICIOUS_GRAVEL);
      put(
         Materials.Group.GRASS,
         SoundType.GRASS,
         SoundType.WET_GRASS,
         SoundType.MOSS,
         SoundType.NYLIUM,
         SoundType.WART_BLOCK,
         SoundType.AZALEA_LEAVES,
         SoundType.CHERRY_LEAVES
      );
      put(Materials.Group.SAND, SoundType.SAND, SoundType.SOUL_SAND, SoundType.SUSPICIOUS_SAND);
      put(
         Materials.Group.METAL,
         SoundType.METAL,
         SoundType.COPPER,
         SoundType.NETHERITE_BLOCK,
         SoundType.IRON,
         SoundType.ANVIL,
         SoundType.CHAIN,
         SoundType.COPPER_GRATE,
         SoundType.COPPER_BULB,
         SoundType.LODESTONE,
         SoundType.ANCIENT_DEBRIS
      );
      put(Materials.Group.WOOL, SoundType.WOOL, SoundType.SPONGE, SoundType.WET_SPONGE);
      put(Materials.Group.SNOW, SoundType.SNOW, SoundType.POWDER_SNOW);
      put(Materials.Group.NETHER, SoundType.NETHERRACK, SoundType.NETHER_BRICKS, SoundType.NETHER_ORE, SoundType.NETHER_GOLD_ORE, SoundType.BASALT);
      put(
         Materials.Group.DEEPSLATE,
         SoundType.DEEPSLATE,
         SoundType.DEEPSLATE_BRICKS,
         SoundType.DEEPSLATE_TILES,
         SoundType.POLISHED_DEEPSLATE,
         SoundType.TUFF,
         SoundType.TUFF_BRICKS,
         SoundType.POLISHED_TUFF
      );
   }

   public static enum Group {
      STONE("fragment_stone", SoundType.STONE, MapColor.STONE),
      WOOD("fragment_wood", SoundType.WOOD, MapColor.WOOD),
      DIRT("fragment_dirt", SoundType.GRAVEL, MapColor.DIRT),
      GRASS("fragment_grass", SoundType.GRASS, MapColor.GRASS),
      SAND("fragment_sand", SoundType.SAND, MapColor.SAND),
      METAL("fragment_metal", SoundType.METAL, MapColor.METAL),
      WOOL("fragment_wool", SoundType.WOOL, MapColor.WOOL),
      SNOW("fragment_snow", SoundType.SNOW, MapColor.SNOW),
      NETHER("fragment_nether", SoundType.NETHERRACK, MapColor.NETHER),
      DEEPSLATE("fragment_deepslate", SoundType.DEEPSLATE, MapColor.DEEPSLATE);

      public final String id;
      public final SoundType sound;
      public final MapColor color;
      public Block block;

      private Group(String nullxx, SoundType nullxxx, MapColor nullxxxx) {
         this.id = nullxx;
         this.sound = nullxxx;
         this.color = nullxxxx;
      }
   }
}
