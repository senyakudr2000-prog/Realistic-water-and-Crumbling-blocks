package kruszenie.client;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack.Pose;
import java.util.ArrayList;
import java.util.List;
import kruszenie.FragmentBlock;
import kruszenie.FragmentBlockEntity;
import kruszenie.KruszenieConfig;
import kruszenie.Mask;
import kruszenie.net.ChipsPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.util.Mth;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.joml.Quaternionf;
import org.joml.Vector3f;

final class Debris {
   static final List<Debris.Piece> LIVE = new ArrayList<>();
   static final int MAX = 6000;
   private static final float GRAVITY = 16.0F;
   private static final MutableBlockPos MP = new MutableBlockPos();
   private static long ticks;
   private static ClientLevel lastLevel;
   private static final Quaternionf Q = new Quaternionf();
   private static final Vector3f V = new Vector3f();
   private static final Vector3f N = new Vector3f();
   private static final float[][] CUBE = new float[][]{
      {-1.0F, -1.0F, -1.0F, 1.0F, -1.0F, -1.0F, 1.0F, -1.0F, 1.0F, -1.0F, -1.0F, 1.0F, 0.0F, -1.0F, 0.0F},
      {-1.0F, 1.0F, -1.0F, -1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, -1.0F, 0.0F, 1.0F, 0.0F},
      {-1.0F, -1.0F, -1.0F, -1.0F, 1.0F, -1.0F, 1.0F, 1.0F, -1.0F, 1.0F, -1.0F, -1.0F, 0.0F, 0.0F, -1.0F},
      {-1.0F, -1.0F, 1.0F, 1.0F, -1.0F, 1.0F, 1.0F, 1.0F, 1.0F, -1.0F, 1.0F, 1.0F, 0.0F, 0.0F, 1.0F},
      {-1.0F, -1.0F, -1.0F, -1.0F, -1.0F, 1.0F, -1.0F, 1.0F, 1.0F, -1.0F, 1.0F, -1.0F, -1.0F, 0.0F, 0.0F},
      {1.0F, -1.0F, -1.0F, 1.0F, 1.0F, -1.0F, 1.0F, 1.0F, 1.0F, 1.0F, -1.0F, 1.0F, 1.0F, 0.0F, 0.0F}
   };

   private Debris() {
   }

   static void clear() {
      LIVE.clear();
   }

   private static float lerp(float a, float b, float t) {
      return a + (b - a) * t;
   }

   private static float rnd() {
      return (float)Math.random();
   }

   static void add(ChipsPayload var0) {
      Minecraft var1 = Minecraft.getInstance();
      if (var1.level != null) {
         boolean var2 = var0.kind() == 2;
         boolean var3 = var0.kind() == 3;
         int var4 = var0.pos().length;
         float var5 = KruszenieConfig.debris;
         if (!(var5 <= 0.0F)) {
            float var6 = (var2 ? (var4 > 300 ? 500 : (var4 > 120 ? 240 : 120)) : 22) / var5;
            float var7 = Mth.sqrt(var0.dx() * var0.dx() + var0.dy() * var0.dy() + var0.dz() * var0.dz());
            int var8 = Math.min(6000, var4 * 10);
            if (LIVE.size() + var8 > 6000) {
               LIVE.subList(0, Math.min(LIVE.size(), LIVE.size() + var8 - 6000)).clear();
            }

            for (int var9 = 0; var9 < var4; var9++) {
               BlockState var10 = Block.stateById(var0.state()[var9]);
               if (!var10.isAir()) {
                  BlockState var11 = Interior.of(var10);
                  TextureAtlasSprite var12 = var1.getBlockRenderer().getBlockModel(var11).getParticleIcon();
                  int var13 = -1;
                                    long var15 = var0.pos()[var9];
                  int var17 = BlockPos.getX(var15);
                  int var18 = BlockPos.getY(var15);
                  int var19 = BlockPos.getZ(var15);
                  int var20 = var1.getBlockColors().getColor(var11, var1.level, MP.set(var17, var18, var19), 0);
                  if (var20 != -1) {
                     var13 = var20;
                  }

                  byte var40 = var0.sampleCount()[var9];
                  int var21 = Math.min(var40, Math.max(1, Math.round(var0.removed()[var9] / var6)));
                  float var22 = var2 ? 1.3F + 1.5F * Math.min(1.0F, var0.removed()[var9] / 4096.0F) : (var3 ? 1.2F : 1.0F);

                  for (int var23 = 0; var23 < var21; var23++) {
                     if (LIVE.size() >= 6000) {
                        return;
                     }

                     int var24 = (var9 * 10 + var23) * 3;
                     Debris.Piece var25 = new Debris.Piece();
                     var25.x = var25.px = var17 + (var0.samples()[var24] + 0.5) * 0.0625;
                     var25.y = var25.py = var18 + (var0.samples()[var24 + 1] + 0.5) * 0.0625;
                     var25.z = var25.pz = var19 + (var0.samples()[var24 + 2] + 0.5) * 0.0625;
                     var25.hx = 0.0625F * (0.45F + rnd() * 0.9F) * var22;
                     var25.hy = 0.0625F * (0.4F + rnd() * 0.7F) * var22;
                     var25.hz = 0.0625F * (0.45F + rnd() * 0.9F) * var22;
                     float var26 = rnd() * 2.0F - 1.0F;
                     float var27 = rnd() * 2.0F - 1.0F;
                     float var28 = rnd() * 2.0F - 1.0F;
                     float var29 = var0.speed() * (0.25F + rnd() * 0.75F);
                     if (var3) {
                        var25.vx = var26 * 0.4;
                        var25.vy = var27 * 0.3;
                        var25.vz = var28 * 0.4;
                     } else if (var7 > 1.0E-4F) {
                        float var30 = -var0.dx() / var7 * 0.7F + var26 * 0.75F;
                        float var31 = -var0.dy() / var7 * 0.7F + var27 * 0.75F + 0.35F;
                        float var32 = -var0.dz() / var7 * 0.7F + var28 * 0.75F;
                        float var33 = Math.max(0.001F, Mth.sqrt(var30 * var30 + var31 * var31 + var32 * var32));
                        var25.vx = var30 / var33 * var29;
                        var25.vy = var31 / var33 * var29;
                        var25.vz = var32 / var33 * var29;
                     } else {
                        double var41 = var25.x - var0.x();
                        double var44 = var25.y - var0.y();
                        double var34 = var25.z - var0.z();
                        double var36 = Math.sqrt(var41 * var41 + var34 * var34);
                        var44 = Math.abs(var44) * 0.5 + 0.55 * (var36 + 0.4);
                        double var38 = Math.max(0.001, Math.sqrt(var41 * var41 + var44 * var44 + var34 * var34));
                        var25.vx = var41 / var38 * var29 + var26 * var29 * 0.2;
                        var25.vy = var44 / var38 * var29 + Math.abs(var27) * var29 * 0.3;
                        var25.vz = var34 / var38 * var29 + var28 * var29 * 0.2;
                     }

                     var25.w.set(rnd() - 0.5F, rnd() - 0.5F, rnd() - 0.5F).mul(14.0F);
                     var25.q.rotateXYZ(rnd() * 6.28F, rnd() * 6.28F, rnd() * 6.28F);
                     var25.pq.set(var25.q);
                     var25.life = 7.0F + rnd() * 5.0F;
                     float var42 = 0.2F + rnd() * 0.15F;
                     float var43 = rnd() * (1.0F - var42);
                     float var46 = rnd() * (1.0F - var42);
                     var25.u0 = lerp(var12.getU0(), var12.getU1(), var43);
                     var25.u1 = lerp(var12.getU0(), var12.getU1(), var43 + var42);
                     var25.v0 = lerp(var12.getV0(), var12.getV1(), var46);
                     var25.v1 = lerp(var12.getV0(), var12.getV1(), var46 + var42);
                     var25.tint = var13;
                     var25.light = lightAt(var1.level, var25.x, var25.y, var25.z);
                     LIVE.add(var25);
                  }
               }
            }
         }
      }
   }

   private static int lightAt(ClientLevel var0, double var1, double var3, double var5) {
      MP.set(Mth.floor(var1), Mth.floor(var3 + 0.1), Mth.floor(var5));
      if (var0.isOutsideBuildHeight(MP)) {
         return 15728640;
      } else if (!var0.getBlockState(MP).isSolidRender(var0, MP)) {
         return LevelRenderer.getLightColor(var0, MP);
      } else {
         int var7 = MP.getX();
         int var8 = MP.getY();
         int var9 = MP.getZ();
         int var10 = 0;
         int var11 = 0;

         for (Direction var15 : Direction.values()) {
            MP.set(var7 + var15.getStepX(), var8 + var15.getStepY(), var9 + var15.getStepZ());
            var10 = Math.max(var10, var0.getBrightness(LightLayer.BLOCK, MP));
            var11 = Math.max(var11, var0.getBrightness(LightLayer.SKY, MP));
         }

         return LightTexture.pack(var10, var11);
      }
   }

   static boolean solid(ClientLevel var0, double var1, double var3, double var5) {
      MP.set(Mth.floor(var1), Mth.floor(var3), Mth.floor(var5));
      BlockState var7 = var0.getBlockState(MP);
      if (var7.isAir()) {
         return false;
      } else if (var7.getBlock() instanceof FragmentBlock) {
         FragmentBlockEntity var17 = FragmentBlock.entity(var0, MP);
         if (var17 == null) {
            return true;
         } else {
            int var18 = Math.clamp((long)((int)((var1 - MP.getX()) * 16.0)), 0, 15);
            int var10 = Math.clamp((long)((int)((var3 - MP.getY()) * 16.0)), 0, 15);
            int var19 = Math.clamp((long)((int)((var5 - MP.getZ()) * 16.0)), 0, 15);
            return Mask.get(var17.bits(), var18, var10, var19);
         }
      } else {
         VoxelShape var8 = var7.getCollisionShape(var0, MP);
         if (var8.isEmpty()) {
            return false;
         } else if (var8 == Shapes.block()) {
            return true;
         } else {
            double var9 = var1 - MP.getX();
            double var11 = var3 - MP.getY();
            double var13 = var5 - MP.getZ();

            for (AABB var16 : var8.toAabbs()) {
               if (var16.contains(var9, var11, var13)) {
                  return true;
               }
            }

            return false;
         }
      }
   }

   static void tick() {
      ClientLevel var0 = Minecraft.getInstance().level;
      if (var0 != lastLevel) {
         lastLevel = var0;
         LIVE.clear();
      }

      if (var0 != null) {
         ticks++;

         for (int var1 = LIVE.size() - 1; var1 >= 0; var1--) {
            Debris.Piece var2 = LIVE.get(var1);
            var2.px = var2.x;
            var2.py = var2.y;
            var2.pz = var2.z;
            var2.pq.set(var2.q);
            var2.age += 0.05F;
            if (var2.age > var2.life) {
               LIVE.remove(var1);
            } else {
               if (var2.asleep) {
                  if ((var1 + ticks) % 10L == 0L && !solid(var0, var2.x, var2.y - var2.hy - 0.04, var2.z)) {
                     var2.asleep = false;
                  }
               } else {
                  for (int var3 = 0; var3 < 2; var3++) {
                     step(var0, var2, 0.025F);
                  }
               }

               if ((var1 + ticks) % 4L == 0L) {
                  var2.light = lightAt(var0, var2.x, var2.y, var2.z);
               }
            }
         }
      }
   }

   private static void step(ClientLevel var0, Debris.Piece var1, float var2) {
      var1.vy -= 16.0F * var2;
      double var3 = var1.x + var1.vx * var2;
      if (solid(var0, var3 + Math.signum(var1.vx) * var1.hx, var1.y, var1.z)) {
         var1.vx = -var1.vx * 0.3;
         var1.w.mul(0.7F);
      } else {
         var1.x = var3;
      }

      double var5 = var1.z + var1.vz * var2;
      if (solid(var0, var1.x, var1.y, var5 + Math.signum(var1.vz) * var1.hz)) {
         var1.vz = -var1.vz * 0.3;
         var1.w.mul(0.7F);
      } else {
         var1.z = var5;
      }

      double var7 = var1.y + var1.vy * var2;
      if (solid(var0, var1.x, var7 + Math.signum(var1.vy) * var1.hy, var1.z)) {
         if (var1.vy < 0.0) {
            if (!var1.grounded) {
               var1.grounded = true;
               Vector3f var9 = var1.q.transform(new Vector3f(0.0F, 0.0F, 1.0F));
               var1.rest.rotationY((float)Math.atan2(var9.x, var9.z));
            }

            var1.vy = -var1.vy * 0.28;
            var1.vx *= 0.55;
            var1.vz *= 0.55;
            var1.w.mul(0.5F);
            if (var1.vy < 0.9 && var1.vx * var1.vx + var1.vz * var1.vz < 0.25) {
               var1.asleep = true;
               var1.vx = var1.vy = var1.vz = 0.0;
               var1.q.set(var1.rest);
               return;
            }
         } else {
            var1.vy = -var1.vy * 0.2;
         }
      } else {
         var1.y = var7;
      }

      if (var1.grounded) {
         var1.q.slerp(var1.rest, 0.25F);
      } else {
         Quaternionf var10 = new Quaternionf(var1.w.x * 0.5F * var2, var1.w.y * 0.5F * var2, var1.w.z * 0.5F * var2, 0.0F).mul(var1.q);
         var1.q.set(var1.q.x + var10.x, var1.q.y + var10.y, var1.q.z + var10.z, var1.q.w + var10.w).normalize();
      }
   }

   static void emit(Pose var0, VertexConsumer var1, Vec3 var2, float var3) {
      for (Debris.Piece var5 : LIVE) {
         float var6 = Math.clamp((var5.life - var5.age) / 1.2F, 0.0F, 1.0F);
         if (!(var6 <= 0.0F)) {
            float var7 = (float)(var5.px + (var5.x - var5.px) * var3 - var2.x);
            float var8 = (float)(var5.py + (var5.y - var5.py) * var3 - var2.y);
            float var9 = (float)(var5.pz + (var5.z - var5.pz) * var3 - var2.z);
            if (!(var7 * var7 + var8 * var8 + var9 * var9 > 9216.0F)) {
               var5.pq.slerp(var5.q, var3, Q);
               int var10 = var5.tint == -1 ? 255 : var5.tint >> 16 & 0xFF;
               int var11 = var5.tint == -1 ? 255 : var5.tint >> 8 & 0xFF;
               int var12 = var5.tint == -1 ? 255 : var5.tint & 0xFF;
               float var13 = var5.hx * var6;
               float var14 = var5.hy * var6;
               float var15 = var5.hz * var6;
               if (var5.asleep) {
                  var8 -= var5.hy - var14;
               }

               for (float[] var19 : CUBE) {
                  N.set(var19[12], var19[13], var19[14]);
                  Q.transform(N);

                  for (int var20 = 0; var20 < 4; var20++) {
                     V.set(var19[var20 * 3] * var13, var19[var20 * 3 + 1] * var14, var19[var20 * 3 + 2] * var15);
                     Q.transform(V);
                     float var21 = var20 != 1 && var20 != 2 ? var5.u0 : var5.u1;
                     float var22 = var20 >= 2 ? var5.v0 : var5.v1;
                     var1.addVertex(var0, var7 + V.x, var8 + V.y, var9 + V.z)
                        .setColor(var10, var11, var12, 255)
                        .setUv(var21, var22)
                        .setOverlay(OverlayTexture.NO_OVERLAY)
                        .setLight(var5.light)
                        .setNormal(var0, N.x, N.y, N.z);
                  }
               }
            }
         }
      }
   }

   static final class Piece {
      double x;
      double y;
      double z;
      double px;
      double py;
      double pz;
      double vx;
      double vy;
      double vz;
      final Quaternionf q = new Quaternionf();
      final Quaternionf pq = new Quaternionf();
      final Quaternionf rest = new Quaternionf();
      final Vector3f w = new Vector3f();
      float hx;
      float hy;
      float hz;
      float age;
      float life;
      boolean asleep;
      boolean grounded;
      int light = 15728880;
      float u0;
      float v0;
      float u1;
      float v1;
      int tint = -1;
   }
}
