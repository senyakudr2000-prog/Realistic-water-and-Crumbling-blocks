package kruszenie.client;

import java.util.function.Supplier;
import kruszenie.FragmentData;
import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.fabricmc.fabric.api.rendering.data.v1.RenderAttachedBlockView;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.state.BlockState;

/** Wraps the (stone-textured placeholder) model of a fragment block and emits the carved voxel mesh instead. */
public final class FragmentModel extends ForwardingBakedModel {
   public FragmentModel(BakedModel wrapped) {
      this.wrapped = wrapped;
   }

   static FragmentData data(BlockAndTintGetter level, BlockPos pos) {
      if (level instanceof RenderAttachedBlockView view) {
         return view.getBlockEntityRenderAttachment(pos) instanceof FragmentData data ? data : null;
      }

      return null;
   }

   @Override
   public boolean isVanillaAdapter() {
      return false;
   }

   @Override
   public void emitBlockQuads(BlockAndTintGetter level, BlockState state, BlockPos pos, Supplier<RandomSource> randomSupplier, RenderContext context) {
      FragmentData data = data(level, pos);
      Mesher mesher = Mesher.get();
      if (data != null && !mesher.busy) {
         mesher.busy = true;

         try {
            mesher.emit(context.getEmitter(), level, pos, data, randomSupplier.get());
         } finally {
            mesher.busy = false;
         }
      } else {
         super.emitBlockQuads(level, state, pos, randomSupplier, context);
      }
   }
}
