package kruszenie.client;

import net.minecraft.core.Direction.Axis;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockState;

final class Interior {
   private Interior() {
   }

   static BlockState of(BlockState var0) {
      Block var1 = var0.getBlock();
      if (var1 == Blocks.GRASS_BLOCK || var1 == Blocks.PODZOL || var1 == Blocks.MYCELIUM || var1 == Blocks.DIRT_PATH || var1 == Blocks.FARMLAND) {
         return Blocks.DIRT.defaultBlockState();
      } else if (var1 == Blocks.CRIMSON_NYLIUM || var1 == Blocks.WARPED_NYLIUM) {
         return Blocks.NETHERRACK.defaultBlockState();
      } else if (var1 == Blocks.BOOKSHELF) {
         return Blocks.OAK_PLANKS.defaultBlockState();
      } else if (var1 == Blocks.CRAFTING_TABLE || var1 == Blocks.FLETCHING_TABLE || var1 == Blocks.CARTOGRAPHY_TABLE || var1 == Blocks.SMITHING_TABLE) {
         return Blocks.OAK_PLANKS.defaultBlockState();
      } else if (var1 == Blocks.TNT) {
         return Blocks.SAND.defaultBlockState();
      } else {
         if (var0.is(BlockTags.LOGS) && var0.hasProperty(RotatedPillarBlock.AXIS)) {
            ResourceLocation var2 = BuiltInRegistries.BLOCK.getKey(var1);
            if (!var2.getPath().startsWith("stripped_")) {
               ResourceLocation var3 = ResourceLocation.fromNamespaceAndPath(var2.getNamespace(), "stripped_" + var2.getPath());
               Block var4 = (Block)BuiltInRegistries.BLOCK.getOptional(var3).orElse(null);
               if (var4 != null && var4.defaultBlockState().hasProperty(RotatedPillarBlock.AXIS)) {
                  return (BlockState)var4.defaultBlockState().setValue(RotatedPillarBlock.AXIS, (Axis)var0.getValue(RotatedPillarBlock.AXIS));
               }
            }
         }

         return var0;
      }
   }
}
