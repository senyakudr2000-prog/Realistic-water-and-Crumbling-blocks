package kruszenie.client;

import java.lang.reflect.Method;

final class Iris {
   private static Method inUse;
   private static Object api;
   private static boolean tried;

   private Iris() {
   }

   private static synchronized void init() {
      if (!tried) {
         tried = true;

         try {
            Class var0 = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
            api = var0.getMethod("getInstance").invoke(null);
            inUse = var0.getMethod("isShaderPackInUse");
         } catch (LinkageError | ReflectiveOperationException var1) {
            api = null;
         }
      }
   }

   static boolean active() {
      init();
      if (api != null && inUse != null) {
         try {
            return (Boolean)inUse.invoke(api);
         } catch (ReflectiveOperationException var1) {
            return false;
         }
      } else {
         return false;
      }
   }
}
