package kruszenie.client;

import java.util.Arrays;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import kruszenie.FragmentBlock;
import kruszenie.FragmentData;
import kruszenie.KruszenieConfig;
import kruszenie.KruszenieMod;
import kruszenie.Mask;
import kruszenie.Materials;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.rendering.data.v1.RenderAttachedBlockView;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.Shapes;

final class Mesher {
   private static final ThreadLocal<Mesher> TL = ThreadLocal.withInitial(Mesher::new);
   private static final int N = 16;
   private static final float V = 0.0625F;
   private static final Direction[] DIRS = Direction.values();
   private static final int P = 18;
   private static final int PX = 1;
   private static final int PZ = 18;
   private static final int PY = 324;
   private static final int[] SA = new int[]{1, 18, 324, 1, 18, 324};
   private static final int[] SB = new int[]{18, 1, 1, 324, 324, 18};
   private static final int[] SN = new int[]{324, 324, 18, 18, 1, 1};
   private static final int MAX_RECTS = 4096;
   private static final float[] CORNER_PLAIN = new float[]{0.52F, 0.68F, 0.84F, 1.0F};
   private static final float[] CORNER_SHADERS = new float[]{0.8F, 0.87F, 0.94F, 1.0F};
   private static final int OPEN = 255;
   private static final float SEAM = 4.0E-4F;
   boolean busy;
   private final byte[] occ = new byte[5832];
   private final int[][] rects = new int[6][4096];
   private final int[] rectCount = new int[6];
   private final int[] rowsOuter = new int[16];
   private final int[] rowsInner = new int[16];
   private final MutableBlockPos scratch = new MutableBlockPos();
   private final Map<BlockState, BlockState> interior = new IdentityHashMap<>();
   private final Map<BlockState, byte[]> shapes = new IdentityHashMap<>();
   private static final byte[] CUBE = pad(null);
   private byte[] orig = CUBE;
   private final float[][] drawn = new float[6][40];
   private final int[] drawnCount = new int[6];
   private QuadEmitter out;
   private BlockAndTintGetter level;
   private BlockPos pos;
   private BlockState tintState;
   private int seenOuter;
   private int seenInner;
   private boolean outer;
   private boolean inner;
   static final AtomicLong BLOCKS = new AtomicLong();
   static final AtomicLong QUADS = new AtomicLong();
   static final AtomicLong NANOS = new AtomicLong();
   private float[] CORNER = CORNER_PLAIN;
   private final short[] cell = new short[256];
   private final float[] p = new float[12];

   static Mesher get() {
      return TL.get();
   }

   private static byte[] pad(long[] var0) {
      byte[] var1 = new byte[5832];

      for (int var2 = 0; var2 < 16; var2++) {
         for (int var3 = 0; var3 < 16; var3++) {
            for (int var4 = 0; var4 < 16; var4++) {
               if (var0 == null || Mask.get(var0, var4, var2, var3)) {
                  var1[(var2 + 1) * 324 + (var3 + 1) * 18 + var4 + 1] = 1;
               }
            }
         }
      }

      return var1;
   }

   void emit(QuadEmitter var1, BlockAndTintGetter var2, BlockPos var3, FragmentData var4, RandomSource var5) {
      long var6 = KruszenieMod.DEBUG ? System.nanoTime() : 0L;
      this.emit0(var1, var2, var3, var4, var5);
      if (KruszenieMod.DEBUG) {
         int var8 = 0;

         for (int var12 : this.rectCount) {
            var8 += var12;
         }

         BLOCKS.incrementAndGet();
         QUADS.addAndGet(var8);
         NANOS.addAndGet(System.nanoTime() - var6);
      }
   }

   private static BakedModel modelOf(BlockState state) {
      return Minecraft.getInstance().getBlockRenderer().getBlockModel(state);
   }

   private void collect(BakedModel model, BlockState state, RandomSource random, long seed) {
      for (int d = 0; d <= 6; d++) {
         Direction face = d == 6 ? null : DIRS[d];
         random.setSeed(seed);
         List<BakedQuad> quads = model.getQuads(state, face, random);
         for (int i = 0; i < quads.size(); i++) {
            this.layer(quads.get(i));
         }
      }
   }

   private void emit0(QuadEmitter var1, BlockAndTintGetter var2, BlockPos var3, FragmentData var4, RandomSource var5) {
      this.CORNER = Iris.active() ? CORNER_SHADERS : CORNER_PLAIN;
      BlockState var6 = var4.state();
      this.orig = var6.isSolidRender(var2, var3) ? CUBE : this.shapes.computeIfAbsent(var6, var0 -> pad(Materials.mask(var0)));
      this.fill(var4.bits(), var2, var3);
      this.build();
      this.out = var1;
      this.level = var2;
      this.pos = var3;
      this.seenOuter = this.seenInner = 0;
      BlockState var7 = this.interior.computeIfAbsent(var6, Interior::of);
      BakedModel var9 = modelOf(var6);
      long var10 = var6.getSeed(var3);
      this.tintState = var6;
      this.outer = true;
      this.inner = var7 == var6;
      Arrays.fill(this.drawnCount, 0);
      this.collect(var9, var6, var5, var10);
      if (var7 != var6) {
         this.tintState = var7;
         this.outer = false;
         this.inner = true;
         Arrays.fill(this.drawnCount, 0);
         this.collect(modelOf(var7), var7, var5, var10);
      }

      if (this.seenOuter != 63 || this.seenInner != 63) {
         this.plain(var9.getParticleIcon());
      }

      this.out = null;
      this.level = null;
   }

   private void fill(long[] var1, BlockAndTintGetter var2, BlockPos var3) {
      byte[] var4 = this.occ;

      for (int var5 = 0; var5 < 16; var5++) {
         for (int var6 = 0; var6 < 16; var6++) {
            int var7 = Mask.row(var1, var5, var6);
            int var8 = (var5 + 1) * 324 + (var6 + 1) * 18 + 1;

            for (int var9 = 0; var9 < 16; var9++) {
               var4[var8 + var9] = (byte)(var7 >> var9 & 1);
            }
         }
      }

      for (int var21 = -1; var21 <= 1; var21++) {
         for (int var22 = -1; var22 <= 1; var22++) {
            for (int var23 = -1; var23 <= 1; var23++) {
               if (var23 != 0 || var21 != 0 || var22 != 0) {
                  this.scratch.set(var3.getX() + var23, var3.getY() + var21, var3.getZ() + var22);
                  BlockState var24 = var2.getBlockState(this.scratch);
                  long[] var25 = null;
                  byte var10 = 0;
                  if (var24.isSolidRender(var2, this.scratch)) {
                     var10 = 1;
                  } else if (var24.getBlock() instanceof FragmentBlock) {
                     if (((RenderAttachedBlockView)var2).getBlockEntityRenderAttachment(this.scratch) instanceof FragmentData var12) {
                        var25 = var12.bits();
                     } else {
                        var10 = 1;
                     }
                  } else if (Math.abs(var23) + Math.abs(var21) + Math.abs(var22) == 1) {
                     Direction var26 = var23 < 0 ? Direction.WEST : var23 > 0 ? Direction.EAST : var21 < 0 ? Direction.DOWN : var21 > 0 ? Direction.UP : var22 < 0 ? Direction.NORTH : Direction.SOUTH;
                     if (var24.getFaceOcclusionShape(var2, this.scratch, var26.getOpposite()) == Shapes.block()) {
                        var10 = 1;
                     }
                  }

                  int var27 = var23 < 0 ? -1 : (var23 > 0 ? 16 : 0);
                  int var28 = var23 == 0 ? 15 : var27;
                  int var13 = var21 < 0 ? -1 : (var21 > 0 ? 16 : 0);
                  int var14 = var21 == 0 ? 15 : var13;
                  int var15 = var22 < 0 ? -1 : (var22 > 0 ? 16 : 0);
                  int var16 = var22 == 0 ? 15 : var15;

                  for (int var17 = var13; var17 <= var14; var17++) {
                     for (int var18 = var15; var18 <= var16; var18++) {
                        for (int var19 = var27; var19 <= var28; var19++) {
                           byte var20 = var10;
                           if (var25 != null) {
                              var20 = (byte)(Mask.get(var25, var19 & 15, var17 & 15, var18 & 15) ? 1 : 0);
                           }

                           var4[(var17 + 1) * 324 + (var18 + 1) * 18 + var19 + 1] = var20;
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private void build() {
      byte[] var1 = this.occ;
      byte[] var2 = this.orig;
      boolean var3 = KruszenieConfig.cornerShade;

      for (int var4 = 0; var4 < 6; var4++) {
         this.rectCount[var4] = 0;
         boolean var5 = (var4 & 1) == 1;
         int var6 = SA[var4];
         int var7 = SB[var4];
         int var8 = SN[var4];
         int var9 = var5 ? var8 : -var8;
         int[] var10 = this.rects[var4];
         int var11 = 0;
         short[] var12 = this.cell;

         for (int var13 = 0; var13 < 16; var13++) {
            boolean var14 = false;
            boolean var15 = false;
            boolean var16 = false;

            for (int var17 = 0; var17 < 16; var17++) {
               int var18 = 0;
               int var19 = 0;
               int var20 = (var13 + 1) * var8 + (var17 + 1) * var7 + var6;

               for (int var21 = 0; var21 < 16; var20 += var6) {
                  var12[var17 << 4 | var21] = 0;
                  if (var1[var20] != 0) {
                     int var22 = var20 + var9;
                     if (var1[var22] == 0) {
                        boolean var23 = var2[var22] == 0;
                        int var24 = !var3
                           ? 255
                           : corner(var1, var22, -var6, -var7)
                              | corner(var1, var22, var6, -var7) << 2
                              | corner(var1, var22, var6, var7) << 4
                              | corner(var1, var22, -var6, var7) << 6;
                        if (var24 != 255) {
                           var12[var17 << 4 | var21] = (short)(var24 + 1 | (var23 ? 512 : 0));
                           var16 = true;
                        } else if (var23) {
                           var18 |= 1 << var21;
                        } else {
                           var19 |= 1 << var21;
                        }
                     }
                  }

                  var21++;
               }

               this.rowsOuter[var17] = var18;
               this.rowsInner[var17] = var19;
               var14 |= var18 != 0;
               var15 |= var19 != 0;
            }

            if (var14) {
               var11 = merge(var10, var11, var13 | 1048576, this.rowsOuter);
            }

            if (var15) {
               var11 = merge(var10, var11, var13, this.rowsInner);
            }

            if (var16) {
               var11 = strips(var10, var11, var13, var12);
            }
         }

         this.rectCount[var4] = var11;
      }
   }

   private static int strips(int[] var0, int var1, int var2, short[] var3) {
      for (int var4 = 0; var4 < 16; var4++) {
         for (int var5 = 0; var5 < 16; var5++) {
            short var6 = var3[var4 << 4 | var5];
            if (var6 != 0) {
               int var7 = (var6 & 511) - 1;
               if ((var7 & 3) == (var7 >> 2 & 3) && (var7 >> 6 & 3) == (var7 >> 4 & 3)) {
                  int var8;
                  for (var8 = 1; var5 + var8 < 16 && var3[var4 << 4 | var5 + var8] == var6; var8++) {
                     var3[var4 << 4 | var5 + var8] = 0;
                  }

                  var3[var4 << 4 | var5] = 0;
                  var0[var1++] = var2 | var5 << 4 | var4 << 8 | var8 - 1 << 12 | var6 >> 9 << 20 | var7 << 21;
               }
            }
         }
      }

      for (int var9 = 0; var9 < 16; var9++) {
         for (int var10 = 0; var10 < 16; var10++) {
            short var11 = var3[var10 << 4 | var9];
            if (var11 != 0) {
               int var12 = (var11 & 511) - 1;
               int var13 = 1;
               if ((var12 & 3) == (var12 >> 6 & 3) && (var12 >> 2 & 3) == (var12 >> 4 & 3)) {
                  while (var10 + var13 < 16 && var3[var10 + var13 << 4 | var9] == var11) {
                     var3[var10 + var13 << 4 | var9] = 0;
                     var13++;
                  }
               }

               var3[var10 << 4 | var9] = 0;
               var0[var1++] = var2 | var9 << 4 | var10 << 8 | var13 - 1 << 16 | var11 >> 9 << 20 | var12 << 21;
            }
         }
      }

      return var1;
   }

   private static int corner(byte[] var0, int var1, int var2, int var3) {
      byte var4 = var0[var1 + var2];
      byte var5 = var0[var1 + var3];
      return (var4 & var5) != 0 ? 0 : 3 - var4 - var5 - var0[var1 + var2 + var3];
   }

   private static int merge(int[] var0, int var1, int var2, int[] var3) {
      for (int var4 = 0; var4 < 16; var4++) {
         int var5 = var3[var4];

         while (var5 != 0) {
            int var6 = Integer.numberOfTrailingZeros(var5);
            int var7 = Integer.numberOfTrailingZeros(~(var5 >>> var6));
            int var8 = (1 << var7) - 1 << var6;

            int var9;
            for (var9 = 1; var4 + var9 < 16 && (var3[var4 + var9] & var8) == var8; var9++) {
               var3[var4 + var9] = var3[var4 + var9] & ~var8;
            }

            var5 &= ~var8;
            var0[var1++] = var2 | var6 << 4 | var4 << 8 | var7 - 1 << 12 | var9 - 1 << 16 | 534773760;
         }
      }

      return var1;
   }

   private void corners(int var1, int var2) {
      int var3 = var2 & 15;
      int var4 = var2 >> 4 & 15;
      int var5 = var2 >> 8 & 15;
      int var6 = var4 + (var2 >> 12 & 15) + 1;
      int var7 = var5 + (var2 >> 16 & 15) + 1;
      float var8 = ((var1 & 1) == 1 ? var3 + 1 : var3) * 0.0625F;

      for (int var9 = 0; var9 < 4; var9++) {
         float var10 = var9 != 1 && var9 != 2 ? var4 * 0.0625F - 4.0E-4F : var6 * 0.0625F + 4.0E-4F;
         float var11 = var9 >= 2 ? var7 * 0.0625F + 4.0E-4F : var5 * 0.0625F - 4.0E-4F;
         float var12;
         float var13;
         float var14;
         switch (var1) {
            case 0:
               var12 = var10;
               var13 = var8;
               var14 = var11;
               break;
            case 1:
               var12 = var11;
               var13 = var8;
               var14 = var10;
               break;
            case 2:
               var12 = var11;
               var13 = var10;
               var14 = var8;
               break;
            case 3:
               var12 = var10;
               var13 = var11;
               var14 = var8;
               break;
            case 4:
               var12 = var8;
               var13 = var11;
               var14 = var10;
               break;
            default:
               var12 = var8;
               var13 = var10;
               var14 = var11;
         }

         this.p[var9 * 3] = var12;
         this.p[var9 * 3 + 1] = var13;
         this.p[var9 * 3 + 2] = var14;
      }
   }

   private static int shade(int var0, float var1) {
      int var2 = Math.round((var0 >> 16 & 0xFF) * var1);
      int var3 = Math.round((var0 >> 8 & 0xFF) * var1);
      int var4 = Math.round((var0 & 0xFF) * var1);
      return var0 & 0xFF000000 | var2 << 16 | var3 << 8 | var4;
   }

   private static float qx(int[] v, int i) {
      return Float.intBitsToFloat(v[i * 8]);
   }

   private static float qy(int[] v, int i) {
      return Float.intBitsToFloat(v[i * 8 + 1]);
   }

   private static float qz(int[] v, int i) {
      return Float.intBitsToFloat(v[i * 8 + 2]);
   }

   private static float qu(int[] v, int i) {
      return Float.intBitsToFloat(v[i * 8 + 4]);
   }

   private static float qv(int[] v, int i) {
      return Float.intBitsToFloat(v[i * 8 + 5]);
   }

   private void layer(BakedQuad quad) {
      int[] q = quad.getVertices();
      Direction var2 = quad.getDirection();
      int var3 = var2.ordinal();
      if (this.outer) {
         this.seenOuter |= 1 << var3;
      }

      if (this.inner) {
         this.seenInner |= 1 << var3;
      }

      int var4 = this.rectCount[var3];
      if (var4 != 0) {
         float var5 = qx(q, 0);
         float var6 = qy(q, 0);
         float var7 = qz(q, 0);
         float var8 = qx(q, 1) - var5;
         float var9 = qy(q, 1) - var6;
         float var10 = qz(q, 1) - var7;
         float var11 = qx(q, 3) - var5;
         float var12 = qy(q, 3) - var6;
         float var13 = qz(q, 3) - var7;
         float var14 = var8 * var8 + var9 * var9 + var10 * var10;
         float var15 = var11 * var11 + var12 * var12 + var13 * var13;
         if (!(var14 < 1.0E-9F) && !(var15 < 1.0E-9F)) {
            float var16 = qu(q, 0);
            float var17 = qv(q, 0);
            float var18 = (qu(q, 1) - var16) / var14;
            float var19 = (qv(q, 1) - var17) / var14;
            float var20 = (qu(q, 3) - var16) / var15;
            float var21 = (qv(q, 3) - var17) / var15;
            float[] var22 = this.drawn[var3];
            float var23 = (0.3F - var5) * var8 + (0.3F - var6) * var9 + (0.3F - var7) * var10;
            float var24 = (0.3F - var5) * var11 + (0.3F - var6) * var12 + (0.3F - var7) * var13;
            float var25 = (0.7F - var5) * var8 + (0.7F - var6) * var9 + (0.7F - var7) * var10;
            float var26 = (0.7F - var5) * var11 + (0.7F - var6) * var12 + (0.7F - var7) * var13;
            float var27 = var16 + var23 * var18 + var24 * var20;
            float var28 = var17 + var23 * var19 + var24 * var21;
            float var29 = var16 + var25 * var18 + var26 * var20;
            float var30 = var17 + var25 * var19 + var26 * var21;
            float var31 = quad.getTintIndex();

            for (int var32 = 0; var32 < this.drawnCount[var3]; var32++) {
               int var33 = var32 * 5;
               if (Math.abs(var22[var33] - var27) < 1.0E-5F
                  && Math.abs(var22[var33 + 1] - var28) < 1.0E-5F
                  && Math.abs(var22[var33 + 2] - var29) < 1.0E-5F
                  && Math.abs(var22[var33 + 3] - var30) < 1.0E-5F
                  && var22[var33 + 4] == var31) {
                  return;
               }
            }

            if (this.drawnCount[var3] < 8) {
               int var45 = this.drawnCount[var3]++ * 5;
               var22[var45] = var27;
               var22[var45 + 1] = var28;
               var22[var45 + 2] = var29;
               var22[var45 + 3] = var30;
               var22[var45 + 4] = var31;
            }

            int var46 = 0xFFFFFFFF;
            if (quad.isTinted()) {
               int var35 = Minecraft.getInstance().getBlockColors().getColor(this.tintState, this.level, this.pos, quad.getTintIndex());
               if (var35 != -1) {
                  var46 = 0xFF000000 | var35;
               }
            }

            int[] var48 = this.rects[var3];

            for (int var49 = 0; var49 < var4; var49++) {
               int var36 = var48[var49];
               if ((var36 >> 20 & 1) != 0 ? this.outer : this.inner) {
                  this.corners(var3, var36);
                  int var37 = var36 >>> 21;

                  for (int var38 = 0; var38 < 4; var38++) {
                     float var39 = this.p[var38 * 3];
                     float var40 = this.p[var38 * 3 + 1];
                     float var41 = this.p[var38 * 3 + 2];
                     float var42 = (var39 - var5) * var8 + (var40 - var6) * var9 + (var41 - var7) * var10;
                     float var43 = (var39 - var5) * var11 + (var40 - var6) * var12 + (var41 - var7) * var13;
                     this.out.pos(var38, var39, var40, var41);
                     this.out.uv(var38, var16 + var42 * var18 + var43 * var20, var17 + var42 * var19 + var43 * var21);
                     int var44 = var37 >> var38 * 2 & 3;
                     this.out.color(var38, var44 == 3 ? var46 : shade(var46, this.CORNER[var44]));
                  }

                  this.out.colorIndex(-1);
                  this.out.cullFace(null);
                  this.out.nominalFace(var2);
                  this.out.emit();
               }
            }
         }
      }
   }

   private void plain(TextureAtlasSprite var1) {
      for (int var2 = 0; var2 < 6; var2++) {
         boolean var3 = (this.seenOuter >> var2 & 1) == 0;
         boolean var4 = (this.seenInner >> var2 & 1) == 0;
         if (var3 || var4) {
            Direction var5 = DIRS[var2];
            int[] var6 = this.rects[var2];

            for (int var7 = 0; var7 < this.rectCount[var2]; var7++) {
               int var8 = var6[var7];
               if ((var8 >> 20 & 1) != 0 ? var3 : var4) {
                  this.corners(var2, var8);
                  int var9 = var8 >>> 21;

                  for (int var10 = 0; var10 < 4; var10++) {
                     float var11 = this.p[var10 * 3];
                     float var12 = this.p[var10 * 3 + 1];
                     float var13 = this.p[var10 * 3 + 2];
                     float var14 = var2 < 4 ? var11 : var13;
                     float var15 = var2 < 2 ? var13 : 1.0F - var12;
                     this.out.pos(var10, var11, var12, var13);
                     this.out.uv(var10, var1.getU0() + (var1.getU1() - var1.getU0()) * var14, var1.getV0() + (var1.getV1() - var1.getV0()) * var15);
                     this.out.color(var10, shade(-1, this.CORNER[var9 >> var10 * 2 & 3]));
                  }

                  this.out.cullFace(null);
                  this.out.nominalFace(var5);
                  this.out.emit();
               }
            }
         }
      }
   }
}
