package kruszenie.client;

import java.util.List;
import java.util.UUID;
import kruszenie.KruszenieConfig;
import kruszenie.KruszenieMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/** Simple options screen (plain Screen, so it does not depend on OptionsSubScreen internals). */
public class KruszenieOptionsScreen extends Screen {
   private static final List<Integer> POWER = List.of(50, 75, 100, 150, 200);
   private static final List<Integer> DEBRIS = List.of(0, 50, 100, 200);
   private static final int REPAIR_RADIUS = 64;
   private final Screen parent;

   public KruszenieOptionsScreen(Screen parent) {
      super(Component.translatable("kruszenie.options.title"));
      this.parent = parent;
   }

   private static int nearest(List<Integer> values, float target) {
      int best = values.get(0);
      float bestDistance = Float.MAX_VALUE;
      for (int v : values) {
         float d = Math.abs(v - target);
         if (d < bestDistance) {
            bestDistance = d;
            best = v;
         }
      }
      return best;
   }

   private static CycleButton<Boolean> toggle(int x, int y, int w, String key, boolean value, java.util.function.Consumer<Boolean> apply) {
      CycleButton<Boolean> button = CycleButton.onOffBuilder(value)
         .create(x, y, w, 20, Component.translatable(key), (b, v) -> apply.accept(v));
      button.setTooltip(Tooltip.create(Component.translatable(key + ".tooltip")));
      return button;
   }

   @Override
   protected void init() {
      int w = 200;
      int x = this.width / 2 - w / 2;
      int y = 32;
      int step = 24;

      this.addRenderableWidget(toggle(x, y, w, "kruszenie.options.enabled", KruszenieConfig.enabled, v -> {
         KruszenieConfig.enabled = v;
         KruszenieConfig.save();
      }));
      y += step;
      this.addRenderableWidget(toggle(x, y, w, "kruszenie.options.blasts", KruszenieConfig.blasts, v -> {
         KruszenieConfig.blasts = v;
         KruszenieConfig.save();
      }));
      y += step;
      this.addRenderableWidget(toggle(x, y, w, "kruszenie.options.loose", KruszenieConfig.looseFalls, v -> {
         KruszenieConfig.looseFalls = v;
         KruszenieConfig.save();
      }));
      y += step;

      CycleButton<Integer> power = CycleButton.<Integer>builder(v -> Component.literal(v + "%"))
         .withValues(POWER)
         .withInitialValue(nearest(POWER, KruszenieConfig.toolPower * 100.0F))
         .create(x, y, w, 20, Component.translatable("kruszenie.options.power"), (b, v) -> {
            KruszenieConfig.toolPower = v / 100.0F;
            KruszenieConfig.save();
         });
      power.setTooltip(Tooltip.create(Component.translatable("kruszenie.options.power.tooltip")));
      this.addRenderableWidget(power);
      y += step;

      CycleButton<Integer> debris = CycleButton.<Integer>builder(v -> Component.translatable("kruszenie.options.debris." + v))
         .withValues(DEBRIS)
         .withInitialValue(nearest(DEBRIS, KruszenieConfig.debris * 100.0F))
         .create(x, y, w, 20, Component.translatable("kruszenie.options.debris"), (b, v) -> {
            KruszenieConfig.debris = v / 100.0F;
            KruszenieConfig.save();
         });
      debris.setTooltip(Tooltip.create(Component.translatable("kruszenie.options.debris.tooltip")));
      this.addRenderableWidget(debris);
      y += step;

      this.addRenderableWidget(toggle(x, y, w, "kruszenie.options.shade", KruszenieConfig.cornerShade, v -> {
         KruszenieConfig.cornerShade = v;
         KruszenieConfig.save();
         if (this.minecraft != null && this.minecraft.level != null) {
            this.minecraft.levelRenderer.allChanged();
         }
      }));
      y += step;

      Button repair = Button.builder(Component.translatable("kruszenie.options.repair"), b -> this.repair())
         .bounds(x, y, w, 20)
         .tooltip(Tooltip.create(Component.translatable("kruszenie.options.repair.tooltip", REPAIR_RADIUS)))
         .build();
      repair.active = this.minecraft != null && this.minecraft.player != null;
      this.addRenderableWidget(repair);

      this.addRenderableWidget(
         Button.builder(Component.translatable("gui.done"), b -> this.onClose()).bounds(this.width / 2 - 100, this.height - 28, 200, 20).build()
      );
   }

   @Override
   public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
      super.render(graphics, mouseX, mouseY, partialTick);
      graphics.drawCenteredString(this.font, this.title, this.width / 2, 12, 0xFFFFFF);
   }

   @Override
   public void onClose() {
      if (this.minecraft != null) {
         this.minecraft.setScreen(this.parent);
      }
   }

   private void repair() {
      Minecraft mc = this.minecraft;
      if (mc == null || mc.player == null) {
         return;
      }
      IntegratedServer server = mc.getSingleplayerServer();
      if (server == null) {
         mc.player.connection.sendCommand("kruszenie repair " + REPAIR_RADIUS);
      } else {
         UUID id = mc.player.getUUID();
         server.execute(() -> {
            ServerPlayer player = server.getPlayerList().getPlayer(id);
            if (player != null) {
               int n = KruszenieMod.repair(player.serverLevel(), player.blockPosition(), REPAIR_RADIUS);
               player.sendSystemMessage(Component.translatable("kruszenie.options.repaired", n));
            }
         });
      }
   }
}
