package kruszenie.client;

import kruszenie.FragmentBlock;
import kruszenie.FragmentBlockEntity;
import kruszenie.KruszenieMod;
import kruszenie.net.ChipsPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec3;

public class KruszenieClient implements ClientModInitializer {
   private static int debugTicks;
   private static long lastBlocks;
   private static long lastQuads;
   private static long lastNanos;
   private static long lastLoads;

   @Override
   public void onInitializeClient() {
      ModelLoadingPlugin.register(
         ctx -> ctx.modifyModelAfterBake()
            .register((model, context) -> {
               if (model != null && context.topLevelId() != null && isFragmentModel(context.topLevelId().id().getPath(), context.topLevelId().id().getNamespace())) {
                  return new FragmentModel(model);
               }
               return model;
            })
      );
      ClientPlayNetworking.registerGlobalReceiver(ChipsPayload.TYPE, (payload, context) -> Debris.add(payload));
      ClientTickEvents.END_CLIENT_TICK.register(client -> {
         if (!client.isPaused()) {
            Debris.tick();
            if (KruszenieMod.DEBUG && ++debugTicks % 40 == 0) {
               long blocks = Mesher.BLOCKS.get();
               if (blocks != lastBlocks) {
                  long quads = Mesher.QUADS.get();
                  long nanos = Mesher.NANOS.get();
                  long loads = FragmentBlockEntity.CLIENT_LOADS.get();
                  KruszenieMod.LOG.info(
                     "[Kruszenie] meshed {} damaged blocks: {} quads, {} ms; {} updates received, {} pieces flying",
                     blocks - lastBlocks,
                     quads - lastQuads,
                     (nanos - lastNanos) / 1000000L,
                     loads - lastLoads,
                     Debris.LIVE.size()
                  );
                  lastLoads = loads;
                  lastBlocks = blocks;
                  lastQuads = quads;
                  lastNanos = nanos;
               }
            }
         }
      });
      ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> Debris.clear());
      ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
         if (screen.getClass().getSimpleName().equals("OptionsScreen")) {
            Button button = Button.builder(
               Component.translatable("kruszenie.options.button"), b -> client.setScreen(new KruszenieOptionsScreen(screen))
            ).bounds(w - 105, 6, 100, 20).build();
            Screens.getButtons(screen).add(button);
         }
      });
      WorldRenderEvents.AFTER_ENTITIES.register(context -> {
         if (!Debris.LIVE.isEmpty() && context.consumers() != null) {
            Vec3 camera = context.camera().getPosition();
            float partial = context.tickCounter().getGameTimeDeltaPartialTick(false);
            Debris.emit(
               context.matrixStack().last(),
               context.consumers().getBuffer(RenderType.entityCutout(TextureAtlas.LOCATION_BLOCKS)),
               camera,
               partial
            );
         }
      });
   }

   private static boolean isFragmentModel(String path, String namespace) {
      return namespace.equals("kruszenie") && path.startsWith("fragment_");
   }
}
