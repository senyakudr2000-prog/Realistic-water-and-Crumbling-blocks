package kruszenie.net;

import kruszenie.KruszenieMod;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;

public record ChipsPayload(
   byte kind,
   double x,
   double y,
   double z,
   float dx,
   float dy,
   float dz,
   float speed,
   long[] pos,
   int[] state,
   int[] removed,
   byte[] sampleCount,
   byte[] samples
) implements CustomPacketPayload {
   public static final byte BLOW = 0;
   public static final byte SHOT = 1;
   public static final byte BLAST = 2;
   public static final byte FALL = 3;
   public static final CustomPacketPayload.Type<ChipsPayload> TYPE = new CustomPacketPayload.Type<>(KruszenieMod.id("chips"));
   public static final StreamCodec<RegistryFriendlyByteBuf, ChipsPayload> CODEC = StreamCodec.of(ChipsPayload::write, ChipsPayload::read);

   private static void write(RegistryFriendlyByteBuf buf, ChipsPayload p) {
      buf.writeByte(p.kind);
      buf.writeDouble(p.x);
      buf.writeDouble(p.y);
      buf.writeDouble(p.z);
      buf.writeFloat(p.dx);
      buf.writeFloat(p.dy);
      buf.writeFloat(p.dz);
      buf.writeFloat(p.speed);
      int n = p.pos.length;
      buf.writeVarInt(n);

      for (int i = 0; i < n; i++) {
         buf.writeLong(p.pos[i]);
         buf.writeVarInt(p.state[i]);
         buf.writeVarInt(p.removed[i]);
         byte count = p.sampleCount[i];
         buf.writeByte(count);
         buf.writeBytes(p.samples, i * 10 * 3, count * 3);
      }
   }

   private static ChipsPayload read(RegistryFriendlyByteBuf buf) {
      byte kind = buf.readByte();
      double x = buf.readDouble();
      double y = buf.readDouble();
      double z = buf.readDouble();
      float dx = buf.readFloat();
      float dy = buf.readFloat();
      float dz = buf.readFloat();
      float speed = buf.readFloat();
      int n = buf.readVarInt();
      long[] pos = new long[n];
      int[] state = new int[n];
      int[] removed = new int[n];
      byte[] sampleCount = new byte[n];
      byte[] samples = new byte[n * 10 * 3];

      for (int i = 0; i < n; i++) {
         pos[i] = buf.readLong();
         state[i] = buf.readVarInt();
         removed[i] = buf.readVarInt();
         int count = Math.max(0, Math.min(buf.readByte(), 10));
         sampleCount[i] = (byte)count;
         buf.readBytes(samples, i * 10 * 3, count * 3);
      }

      return new ChipsPayload(kind, x, y, z, dx, dy, dz, speed, pos, state, removed, sampleCount, samples);
   }

   @Override
   public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
      return TYPE;
   }
}
