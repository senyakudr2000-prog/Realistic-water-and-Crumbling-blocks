package kruszenie;

import java.util.List;
import kruszenie.net.ChipsPayload;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

public final class Effects {
   private static final int MAX_CHIPS = 500;

   private Effects() {
   }

   public static void chips(ServerLevel var0, byte var1, Vec3 var2, Vec3 var3, float var4, List<Carver.Chip> var5) {
      if (!var5.isEmpty()) {
         int var6 = (var5.size() + 500 - 1) / 500;
         int var7 = (var5.size() + var6 - 1) / var6;
         long[] var8 = new long[var7];
         int[] var9 = new int[var7];
         int[] var10 = new int[var7];
         byte[] var11 = new byte[var7];
         byte[] var12 = new byte[var7 * 10 * 3];

         for (int var13 = 0; var13 < var7; var13++) {
            Carver.Chip var14 = (Carver.Chip)var5.get(var13 * var6);
            var8[var13] = var14.pos.asLong();
            var9[var13] = Block.getId(var14.state);
            var10[var13] = var14.removed;
            var11[var13] = (byte)var14.sampleCount;
            System.arraycopy(var14.samples, 0, var12, var13 * 10 * 3, var14.sampleCount * 3);
         }

         ChipsPayload var16 = new ChipsPayload(
            var1,
            var2.x,
            var2.y,
            var2.z,
            var3 == null ? 0.0F : (float)var3.x,
            var3 == null ? 0.0F : (float)var3.y,
            var3 == null ? 0.0F : (float)var3.z,
            var4,
            var8,
            var9,
            var10,
            var11,
            var12
         );

         for (ServerPlayer var15 : PlayerLookup.around(var0, var2, 96.0)) {
            if (ServerPlayNetworking.canSend(var15, ChipsPayload.TYPE)) {
               ServerPlayNetworking.send(var15, var16);
            }
         }
      }
   }

   public static BlockState main(Carver.Result var0) {
      Carver.Chip var1 = null;

      for (Carver.Chip var3 : var0.chips) {
         if (var1 == null || var3.removed > var1.removed) {
            var1 = var3;
         }
      }

      return var1 == null ? null : var1.state;
   }

   public static void dustAndSound(ServerLevel var0, Vec3 var1, Carver.Result var2, int var3, float var4, float var5) {
      BlockState var6 = main(var2);
      if (var6 != null) {
         if (var3 > 0) {
            var0.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, var6), var1.x, var1.y, var1.z, var3, 0.12, 0.12, 0.12, 0.08);
         }

         SoundType var7 = var6.getSoundType();
         float var8 = var5 * var7.getPitch() * (0.9F + var0.getRandom().nextFloat() * 0.2F);
         var0.playSound(null, var1.x, var1.y, var1.z, var7.getBreakSound(), SoundSource.BLOCKS, var4 * (var7.getVolume() + 1.0F) / 2.0F, var8);
      }
   }
}
