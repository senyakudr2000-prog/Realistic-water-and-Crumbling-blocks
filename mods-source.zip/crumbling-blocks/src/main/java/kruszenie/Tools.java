package kruszenie;

import java.util.IdentityHashMap;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public final class Tools {
   public static final int HAMMER_COOLDOWN = 11;
   public static final double HAMMER_RADIUS = 0.42;
   private static final int PELLETS = 14;
   private static final double SPREAD = 0.07;
   private static final double RANGE = 64.0;
   private static final double PELLET_RADIUS = 0.22;
   private static final float PELLET_DAMAGE = 2.5F;

   private Tools() {
   }

   /** Server: the full adventure/spectator style check of Player.blockActionRestricted. Client: only spectators are blocked. */
   private static boolean restricted(Player player, Level level, BlockPos pos) {
      if (player instanceof ServerPlayer sp) {
         return sp.blockActionRestricted(level, pos, sp.gameMode.getGameModeForPlayer());
      }

      return player.isSpectator();
   }

   public static InteractionResult hammer(Player player, Level level, InteractionHand hand, BlockPos blockPos, Direction face) {
      ItemStack stack = player.getItemInHand(hand);
      if (!stack.is(KruszenieMod.HAMMER) || player.isSpectator() || !KruszenieConfig.enabled) {
         return InteractionResult.PASS;
      }

      if (player.getCooldowns().isOnCooldown(stack.getItem())) {
         return InteractionResult.FAIL;
      }

      if (restricted(player, level, blockPos)) {
         return InteractionResult.FAIL;
      }

      player.getCooldowns().addCooldown(stack.getItem(), HAMMER_COOLDOWN);
      if (!(level instanceof ServerLevel serverLevel) || !(player instanceof ServerPlayer)) {
         return InteractionResult.SUCCESS;
      }

      if (!serverLevel.mayInteract(player, blockPos)) {
         return InteractionResult.FAIL;
      }

      Vec3 eye = player.getEyePosition();
      Vec3 look = player.getLookAngle();
      double reach = player.blockInteractionRange() + 1.0;
      BlockHitResult hit = level.clip(new ClipContext(eye, eye.add(look.scale(reach)), ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, player));
      Vec3 point = hit.getType() == HitResult.Type.BLOCK
         ? hit.getLocation()
         : Vec3.atCenterOf(blockPos).add(face.getStepX() * 0.5, face.getStepY() * 0.5, face.getStepZ() * 0.5);
      Vec3 inside = point.add(look.scale(0.1));
      Carver.Job job = new Carver.Job(serverLevel, serverLevel.getRandom().nextLong()).by(player);
      BlockState targeted = serverLevel.getBlockState(blockPos);
      if (Materials.fragile(targeted, serverLevel, blockPos)) {
         job.breakFragile(blockPos, targeted);
      }

      Carver.sphere(job, inside, HAMMER_RADIUS * KruszenieConfig.toolPower, 0.3);
      Carver.Result result = job.finish();
      serverLevel.playSound(null, point.x, point.y, point.z, KruszenieMod.HAMMER_HIT, SoundSource.PLAYERS, 0.9F, 0.9F + serverLevel.getRandom().nextFloat() * 0.2F);
      if (result.voxels > 0) {
         Effects.chips(serverLevel, (byte)0, inside, look, 4.5F, result.chips);
         Effects.chips(serverLevel, (byte)3, inside, null, 1.0F, result.loose);
         Effects.dustAndSound(serverLevel, point, result, 14, 1.0F, 0.8F);
         if (!player.isCreative()) {
            for (Carver.Chip chip : result.chips) {
               if (chip.gone) {
                  net.minecraft.world.level.block.Block.dropResources(chip.state, serverLevel, chip.pos, null, player, new ItemStack(Items.IRON_PICKAXE));
               }
            }
         }

         stack.hurtAndBreak(1, player, LivingEntity.getSlotForHand(hand));
      }

      return InteractionResult.SUCCESS;
   }

   public static void shoot(ServerLevel level, ServerPlayer player, ItemStack stack, InteractionHand hand) {
      Vec3 eye = player.getEyePosition();
      Vec3 look = player.getLookAngle();
      RandomSource random = level.getRandom();
      Vec3 right = look.cross(Math.abs(look.y) > 0.95 ? new Vec3(1.0, 0.0, 0.0) : new Vec3(0.0, 1.0, 0.0)).normalize();
      Vec3 up = right.cross(look);
      Carver.Job job = KruszenieConfig.enabled ? new Carver.Job(level, random.nextLong()).by(player) : null;
      Map<Entity, Float> hurt = new IdentityHashMap<>();
      double sumX = 0.0;
      double sumY = 0.0;
      double sumZ = 0.0;
      int hits = 0;

      for (int i = 0; i < PELLETS; i++) {
         double angle = random.nextDouble() * Math.PI * 2.0;
         double radius = Math.sqrt((i + random.nextDouble()) / PELLETS) * SPREAD;
         Vec3 dir = look.add(right.scale(Math.cos(angle) * radius)).add(up.scale(Math.sin(angle) * radius)).normalize();
         Vec3 far = eye.add(dir.scale(RANGE));
         BlockHitResult block = level.clip(new ClipContext(eye, far, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
         Vec3 end = block.getType() == HitResult.Type.BLOCK ? block.getLocation() : far;
         EntityHitResult entityHit = ProjectileUtil.getEntityHitResult(
            player, eye, end, new AABB(eye, end).inflate(1.0), e -> e.isPickable() && !e.isSpectator(), eye.distanceToSqr(end)
         );
         if (entityHit != null) {
            hurt.merge(entityHit.getEntity(), PELLET_DAMAGE, Float::sum);
         } else if (block.getType() == HitResult.Type.BLOCK) {
            if (job != null && level.mayInteract(player, block.getBlockPos()) && !restricted(player, level, block.getBlockPos())) {
               BlockState state = level.getBlockState(block.getBlockPos());
               if (Materials.fragile(state, level, block.getBlockPos())) {
                  job.breakFragile(block.getBlockPos(), state);
               }

               Carver.sphere(job, end.add(dir.scale(0.05)), PELLET_RADIUS * KruszenieConfig.toolPower, 0.35);
            }

            sumX += end.x;
            sumY += end.y;
            sumZ += end.z;
            hits++;
         }
      }

      DamageSource source = level.damageSources().playerAttack(player);

      for (Map.Entry<Entity, Float> entry : hurt.entrySet()) {
         boolean done = entry.getKey().hurt(source, entry.getValue());
         if (KruszenieMod.DEBUG) {
            KruszenieMod.LOG.info("[Kruszenie] shot hurt {} by {}: {}", entry.getKey().getType(), entry.getValue(), done);
         }
      }

      if (KruszenieMod.DEBUG) {
         KruszenieMod.LOG.info("[Kruszenie] shot: {} pellets on blocks, {} creatures hit", hits, hurt.size());
      }

      Vec3 muzzle = eye.add(look.scale(1.1)).add(right.scale(-0.25)).add(0.0, -0.15, 0.0);
      level.sendParticles(ParticleTypes.SMOKE, muzzle.x, muzzle.y, muzzle.z, 7, 0.06, 0.06, 0.06, 0.02);
      level.playSound(null, eye.x, eye.y, eye.z, KruszenieMod.GUN_SHOT, SoundSource.PLAYERS, 1.0F, 0.95F + random.nextFloat() * 0.1F);
      level.playSound(null, eye.x, eye.y, eye.z, KruszenieMod.GUN_PUMP, SoundSource.PLAYERS, 0.7F, 0.95F + random.nextFloat() * 0.1F);
      if (job != null) {
         Carver.Result result = job.finish();
         if (result.voxels > 0 && hits > 0) {
            Vec3 center = new Vec3(sumX / hits, sumY / hits, sumZ / hits);
            Effects.chips(level, (byte)1, center, look, 3.5F, result.chips);
            Effects.chips(level, (byte)3, center, null, 1.0F, result.loose);
            Effects.dustAndSound(level, center, result, 10, 0.8F, 1.1F);
         }
      }

      stack.hurtAndBreak(1, player, LivingEntity.getSlotForHand(hand));
   }
}
