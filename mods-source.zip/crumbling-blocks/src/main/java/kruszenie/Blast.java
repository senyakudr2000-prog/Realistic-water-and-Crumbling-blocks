package kruszenie;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.ExplosionDamageCalculator;
import net.minecraft.world.level.Explosion.BlockInteraction;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.storage.loot.LootParams.Builder;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.phys.Vec3;

public final class Blast {
   private static final int M = 20;
   private static final double STEP = 0.15;
   private static final float POWER_SCALE = 1.0F;
   public static final float MAX_POWER = 16.0F;
   private static final long TICK_BUDGET = 120000000L;
   private static long budgetTick = Long.MIN_VALUE;
   private static long spent;
   private final float[] reach = new float[2400];
   private float maxReach;
   private static final int L = 5;
   private static final int LS = 4;
   private static final float LUMPS_MAX = 0.32F;
   private static final float LUMPS_MIN = 0.1F;
   private static final int LUMP = 8;
   private static final float GRAIN = 0.045F;

   public static boolean inBudget(ServerLevel var0) {
      long var1 = var0.getServer().getTickCount();
      if (var1 != budgetTick) {
         budgetTick = var1;
         spent = 0L;
      }

      return spent < 120000000L;
   }

   private Blast() {
   }

   public static void apply(Explosion var0, ServerLevel var1, Vec3 var2, float var3, ExplosionDamageCalculator var4, BlockInteraction interaction, List<BlockPos> var5) {
      long var6 = System.nanoTime();
      long var8 = var1.getRandom().nextLong();
      Blast var10 = new Blast();
      var10.march(var0, var1, var2, var3, var4, var8);
      long var11 = System.nanoTime();
      Carver.Job var13 = new Carver.Job(var1, var8);
      ArrayList var14 = new ArrayList();
      ArrayList var15 = new ArrayList();
      var10.cut(var0, var1, var2, var3, var4, var13, var14, var15);
      long var16 = System.nanoTime();
      Carver.Result var18 = var13.finish();
      long var19 = System.nanoTime();
      var5.clear();
      var5.addAll(var14);

      for (Carver.Chip var22 : var18.chips) {
         drops(var0, var1, var22, var3, interaction);
      }

      for (Carver.Chip var24 : var18.loose) {
         drops(var0, var1, var24, var3, interaction);
      }

      var18.chips.addAll(var15);
      Effects.chips(var1, (byte)2, var2, null, 5.0F + var3 * 1.6F, var18.chips);
      Effects.chips(var1, (byte)3, var2, null, 1.0F, var18.loose);
      if (!var18.chips.isEmpty()) {
         var1.playSound(
            null,
            var2.x,
            var2.y,
            var2.z,
            var18.chips.size() > 12 ? KruszenieMod.RUBBLE : KruszenieMod.RUBBLE_SMALL,
            SoundSource.BLOCKS,
            Math.min(2.5F, 0.6F + var3 * 0.3F),
            0.9F + var1.getRandom().nextFloat() * 0.2F
         );
      }

      spent = spent + (System.nanoTime() - var6);
      if (KruszenieMod.DEBUG) {
         KruszenieMod.LOG
            .info(
               String.format(
                  Locale.ROOT,
                  "[Kruszenie] blast power %.1f at %.1f %.1f %.1f: reach up to %.1f m, %d whole blocks, %d cut blocks, %d voxels; rays %.1f ms, cut %.1f ms, loose %.1f ms, write %.1f ms, effects %.1f ms",
                  var3,
                  var2.x,
                  var2.y,
                  var2.z,
                  var10.maxReach,
                  var14.size(),
                  var18.chips.size() - var15.size(),
                  var18.voxels,
                  (var11 - var6) / 1000000.0,
                  (var16 - var11) / 1000000.0,
                  var13.looseNanos / 1000000.0,
                  (var19 - var16 - var13.looseNanos) / 1000000.0,
                  (System.nanoTime() - var19) / 1000000.0
               )
            );
      }
   }

   private static void drops(Explosion var0, ServerLevel var1, Carver.Chip var2, float radius, BlockInteraction interaction) {
      BlockState var3 = var2.state;
      if (!(var1.getRandom().nextFloat() * Materials.volume(var3) >= var2.removed)) {
         if (var3.getBlock().dropFromExplosion(var0)) {
            Builder var4 = new Builder(var1)
               .withParameter(LootContextParams.ORIGIN, Vec3.atCenterOf(var2.pos))
               .withParameter(LootContextParams.TOOL, ItemStack.EMPTY)
               .withOptionalParameter(LootContextParams.THIS_ENTITY, var0.getDirectSourceEntity());
            if (interaction == BlockInteraction.DESTROY_WITH_DECAY) {
               var4.withParameter(LootContextParams.EXPLOSION_RADIUS, radius);
            }

            var3.getDrops(var4).forEach(var2x -> Block.popResource(var1, var2.pos, var2x));
         }
      }
   }

   private static void direction(int var0, int var1, int var2, double[] var3) {
      double var4 = (var1 + 0.5) / 20.0 * 2.0 - 1.0;
      double var6 = (var2 + 0.5) / 20.0 * 2.0 - 1.0;
      double var8 = (var0 & 1) == 0 ? 1.0 : -1.0;
      double var10;
      double var12;
      double var14;
      switch (var0 >> 1) {
         case 0:
            var10 = var8;
            var12 = var4;
            var14 = var6;
            break;
         case 1:
            var10 = var4;
            var12 = var8;
            var14 = var6;
            break;
         default:
            var10 = var4;
            var12 = var6;
            var14 = var8;
      }

      double var16 = Math.sqrt(var10 * var10 + var12 * var12 + var14 * var14);
      var3[0] = var10 / var16;
      var3[1] = var12 / var16;
      var3[2] = var14 / var16;
   }

   private void march(Explosion var1, ServerLevel var2, Vec3 var3, float var4, ExplosionDamageCalculator var5, long var6) {
      double[] var8 = new double[3];
      MutableBlockPos var9 = new MutableBlockPos();
      BlockState var10 = Blocks.AIR.defaultBlockState();
      FluidState var11 = Fluids.EMPTY.defaultFluidState();

      for (int var12 = 0; var12 < 6; var12++) {
         for (int var13 = 0; var13 < 20; var13++) {
            for (int var14 = 0; var14 < 20; var14++) {
               direction(var12, var14, var13, var8);
               float var15 = Carver.noise((int)Math.round(var8[0] * 11.0), (int)Math.round(var8[1] * 11.0), (int)Math.round(var8[2] * 11.0), var6 ^ 20907L);
               float var16 = var4 * 1.0F * (1.0F + 0.14F * var15);
               double var17 = 0.0;
               long var19 = Long.MIN_VALUE;
               long var21 = Long.MIN_VALUE;
               float var23 = 0.0F;
               float var24 = 0.0F;

               for (float var25 = 0.0F; var16 > 0.0F; var17 += 0.15) {
                  double var26 = var3.x + var8[0] * var17;
                  double var28 = var3.y + var8[1] * var17;
                  double var30 = var3.z + var8[2] * var17;
                  var9.set(Mth.floor(var26), Mth.floor(var28), Mth.floor(var30));
                  if (!var2.isInWorldBounds(var9)) {
                     break;
                  }

                  long var32 = var9.asLong();
                  if (var32 != var21) {
                     var21 = var32;
                     var25 = var16;
                  }

                  float var34;
                  float var35;
                  if (var32 == var19) {
                     var34 = var23;
                     var35 = var24;
                  } else {
                     BlockState var36 = var2.getBlockState(var9);
                     boolean var37 = var36.getBlock() instanceof FragmentBlock;
                     if (var37) {
                        FragmentBlockEntity var38 = FragmentBlock.entity(var2, var9);
                        if (var38 == null) {
                           var36 = var10;
                        } else {
                           int var39 = Math.clamp((long)((int)((var26 - var9.getX()) * 16.0)), 0, 15);
                           int var40 = Math.clamp((long)((int)((var28 - var9.getY()) * 16.0)), 0, 15);
                           int var41 = Math.clamp((long)((int)((var30 - var9.getZ()) * 16.0)), 0, 15);
                           var36 = Mask.get(var38.bits(), var39, var40, var41) ? var38.original() : var10;
                        }
                     }

                     FluidState var44 = var37 ? var11 : var2.getFluidState(var9);
                     Optional var45 = var5.getBlockExplosionResistance(var1, var2, var9, var36, var44);
                     var35 = var45.isPresent() ? (Float)var45.get() + 0.3F : 0.0F;
                     var34 = (float)(0.15 * (0.75 + var35));
                     if (!var37) {
                        var19 = var32;
                        var23 = var34;
                        var24 = var35;
                     }
                  }

                  if (var16 <= var34) {
                     var17 += 0.15 * var16 / var34;
                     if (var35 > 0.0F) {
                        float var42 = var35 * 0.3F;
                        float var43 = 0.5F + 0.6F * Math.clamp((var35 - 1.3F) / 3.0F, 0.0F, 1.0F);
                        var17 += var43 * Math.clamp((var25 - var42) / var42, 0.0F, 1.0F);
                     }
                     break;
                  }

                  var16 -= var34;
               }

               this.reach[(var12 * 20 + var13) * 20 + var14] = (float)var17;
               this.maxReach = Math.max(this.maxReach, (float)var17);
            }
         }
      }
   }

   private float reach(double var1, double var3, double var5) {
      double var7 = Math.abs(var1);
      double var9 = Math.abs(var3);
      double var11 = Math.abs(var5);
      int var13;
      double var14;
      double var16;
      if (var7 >= var9 && var7 >= var11) {
         if (var7 < 1.0E-9) {
            return this.maxReach;
         }

         var13 = var1 > 0.0 ? 0 : 1;
         var14 = var3 / var7;
         var16 = var5 / var7;
      } else if (var9 >= var11) {
         var13 = var3 > 0.0 ? 2 : 3;
         var14 = var1 / var9;
         var16 = var5 / var9;
      } else {
         var13 = var5 > 0.0 ? 4 : 5;
         var14 = var1 / var11;
         var16 = var3 / var11;
      }

      double var18 = Math.clamp((var14 + 1.0) * 0.5 * 20.0 - 0.5, 0.0, 19.0);
      double var20 = Math.clamp((var16 + 1.0) * 0.5 * 20.0 - 0.5, 0.0, 19.0);
      int var22 = Math.min((int)var18, 18);
      int var23 = Math.min((int)var20, 18);
      float var24 = (float)(var18 - var22);
      float var25 = (float)(var20 - var23);
      int var26 = (var13 * 20 + var23) * 20 + var22;
      float var27 = this.reach[var26] + (this.reach[var26 + 1] - this.reach[var26]) * var24;
      float var28 = this.reach[var26 + 20] + (this.reach[var26 + 20 + 1] - this.reach[var26 + 20]) * var24;
      return var27 + (var28 - var27) * var25;
   }

   private float beyond(double var1, double var3, double var5) {
      double var7 = Math.sqrt(var1 * var1 + var3 * var3 + var5 * var5);
      return var7 < 1.0E-6 ? -this.maxReach : (float)(var7 - this.reach(var1, var3, var5));
   }

   private void cut(
      Explosion var1, ServerLevel var2, Vec3 var3, float var4, ExplosionDamageCalculator var5, Carver.Job var6, List<BlockPos> var7, List<Carver.Chip> var8
   ) {
      byte var9 = 16;
      float var10 = 0.365F;
      double var11 = this.maxReach + var10 + 0.9;
      int var13 = Mth.floor(var3.x - var11);
      int var14 = Mth.floor(var3.x + var11);
      int var15 = Math.max(Mth.floor(var3.y - var11), var2.getMinBuildHeight());
      int var16 = Math.min(Mth.floor(var3.y + var11), (var2.getMaxBuildHeight() - 1));
      int var17 = Mth.floor(var3.z - var11);
      int var18 = Mth.floor(var3.z + var11);
      float var19 = var4 * 1.0F * 1.14F / 0.3F - 0.3F;
      MutableBlockPos var20 = new MutableBlockPos();
      FluidState var21 = Fluids.EMPTY.defaultFluidState();
      float[] var22 = new float[125];
      long var23 = var6.seed ^ 1280658768L;

      for (int var25 = var15; var25 <= var16; var25++) {
         for (int var26 = var17; var26 <= var18; var26++) {
            for (int var27 = var13; var27 <= var14; var27++) {
               double var28 = var27 - var3.x;
               double var30 = var25 - var3.y;
               double var32 = var26 - var3.z;
               double var34 = var28 + 0.5;
               double var36 = var30 + 0.5;
               double var38 = var32 + 0.5;
               if (!(var34 * var34 + var36 * var36 + var38 * var38 > var11 * var11)) {
                  var20.set(var27, var25, var26);
                  BlockState var40 = var2.getBlockState(var20);
                  if (!var40.isAir()) {
                     float var41 = this.beyond(var34, var36, var38);
                     float var42 = var41;
                     float var43 = var41;

                     for (int var44 = 0; var44 < 8; var44++) {
                        float var45 = this.beyond(var28 + (var44 & 1), var30 + (var44 >> 1 & 1), var32 + (var44 >> 2));
                        var42 = Math.min(var42, var45);
                        var43 = Math.max(var43, var45);
                     }

                     if (!(var42 >= var10)) {
                        Carver.Entry var77 = var6.entry(var20);
                        BlockState var78 = var77 != null ? var77.original : var40;
                        Optional var46 = var5.getBlockExplosionResistance(var1, var2, var20, var78, var77 != null ? var21 : var2.getFluidState(var20));
                        if ((!var46.isPresent() || !((Float)var46.get() > var19)) && var5.shouldBlockExplode(var1, var2, var20, var78, var4)) {
                           if (var77 == null) {
                              if (var41 < 0.0F) {
                                 var7.add(var20.immutable());
                              }
                           } else if (var43 < -var10) {
                              if (var77.current == var77.original) {
                                 var6.forget(var77);
                                 var7.add(var77.pos);
                                 Carver.Chip var80 = new Carver.Chip(var77.pos, var77.original);
                                 var80.removed = Mask.count(var77.bits);
                                 var80.sampleAll(var77.bits, var6.seed + var77.pos.asLong());
                                 var8.add(var80);
                              } else {
                                 var77.clearAll(var6.seed);
                              }
                           } else {
                              for (int var47 = 0; var47 < 5; var47++) {
                                 for (int var48 = 0; var48 < 5; var48++) {
                                    for (int var49 = 0; var49 < 5; var49++) {
                                       double var50 = var28 + (double)(var49 * 4) / var9;
                                       double var52 = var30 + (double)(var47 * 4) / var9;
                                       double var54 = var32 + (double)(var48 * 4) / var9;
                                       double var56 = Math.sqrt(var50 * var50 + var52 * var52 + var54 * var54);
                                       float var58 = var56 < 1.0E-6 ? this.maxReach : this.reach(var50, var52, var54);
                                       float var59 = Math.clamp(var58 * 0.1F, 0.1F, 0.32F)
                                          * Carver.lumps(var27 * var9 + var49 * 4, var25 * var9 + var47 * 4, var26 * var9 + var48 * 4, var23, 8);
                                       var22[(var47 * 5 + var48) * 5 + var49] = (float)(var56 - var58) - var59;
                                    }
                                 }
                              }

                              long[] var79 = var77.bits;

                              for (int var81 = 0; var81 < 4; var81++) {
                                 for (int var82 = 0; var82 < 4; var82++) {
                                    for (int var83 = 0; var83 < 4; var83++) {
                                       int var51 = (var81 * 5 + var82) * 5 + var83;
                                       float var84 = var22[var51];
                                       float var53 = var22[var51 + 1];
                                       float var85 = var22[var51 + 5];
                                       float var55 = var22[var51 + 5 + 1];
                                       float var86 = var22[var51 + 25];
                                       float var57 = var22[var51 + 25 + 1];
                                       float var87 = var22[var51 + 25 + 5];
                                       float var88 = var22[var51 + 25 + 5 + 1];
                                       float var60 = Math.min(
                                          Math.min(Math.min(var84, var53), Math.min(var85, var55)), Math.min(Math.min(var86, var57), Math.min(var87, var88))
                                       );
                                       if (!(var60 >= 0.045F)) {
                                          float var61 = Math.max(
                                             Math.max(Math.max(var84, var53), Math.max(var85, var55)), Math.max(Math.max(var86, var57), Math.max(var87, var88))
                                          );
                                          int var62 = var83 * 4;
                                          int var63 = var81 * 4;
                                          int var64 = var82 * 4;
                                          if (var61 < -0.045F) {
                                             for (int var89 = var63; var89 < var63 + 4; var89++) {
                                                for (int var90 = var64; var90 < var64 + 4; var90++) {
                                                   var77.clearRun(var62, 4, var89, var90, var6.seed);
                                                }
                                             }
                                          } else {
                                             for (int var65 = var63; var65 < var63 + 4; var65++) {
                                                float var66 = (var65 + 0.5F - var63) / 4.0F;

                                                for (int var67 = var64; var67 < var64 + 4; var67++) {
                                                   float var68 = (var67 + 0.5F - var64) / 4.0F;
                                                   int var69 = Mask.row(var79, var65, var67) >> var62 & 15;
                                                   if (var69 != 0) {
                                                      float var70 = var84 + (var85 - var84) * var68;
                                                      float var71 = var53 + (var55 - var53) * var68;
                                                      float var72 = var86 + (var87 - var86) * var68;
                                                      float var73 = var57 + (var88 - var57) * var68;
                                                      var70 += (var72 - var70) * var66;
                                                      var71 += (var73 - var71) * var66;

                                                      for (int var74 = 0; var74 < 4; var74++) {
                                                         if ((var69 >> var74 & 1) != 0) {
                                                            int var75 = var62 + var74;
                                                            float var76 = var70 + (var71 - var70) * ((var74 + 0.5F) / 4.0F);
                                                            if (!(var76 >= 0.045F)
                                                               && (
                                                                  !(var76 > -0.045F)
                                                                     || !(
                                                                        var76
                                                                           >= 0.045F
                                                                              * Carver.grain(
                                                                                 var27 * var9 + var75, var25 * var9 + var65, var26 * var9 + var67, var6.seed
                                                                              )
                                                                     )
                                                               )) {
                                                               var77.clear(var75, var65, var67, var6.seed + Mask.idx(var75, var65, var67));
                                                            }
                                                         }
                                                      }
                                                   }
                                                }
                                             }
                                          }
                                       }
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }
}
