package kruszenie;

import java.util.function.Function;
import net.minecraft.core.Direction;

final class Loose {
   private static final long WEST = 281479271743489L;
   private static final long EAST = -9223231297218904064L;
   private static final int W = 64;

   private Loose() {
   }

   static Carver.Chip drop(Carver.Entry var0, Function<Direction, long[]> var1, long var2) {
      if (!KruszenieConfig.looseFalls) {
         return null;
      } else {
         long[] var4 = var0.bits;
         long[] var5 = new long[64];
         long[] var6 = (long[])var1.apply(Direction.DOWN);
         if (var6 != null) {
            for (int var7 = 0; var7 < 4; var7++) {
               var5[var7] |= var4[var7] & var6[var7 + 64 - 4];
            }
         }

         var6 = (long[])var1.apply(Direction.UP);
         if (var6 != null) {
            for (int var25 = 60; var25 < 64; var25++) {
               var5[var25] |= var4[var25] & var6[var25 - 64 + 4];
            }
         }

         var6 = (long[])var1.apply(Direction.NORTH);
         if (var6 != null) {
            for (int var26 = 0; var26 < 16; var26++) {
               var5[var26 * 4] = var5[var26 * 4] | var4[var26 * 4] & var6[var26 * 4 + 3] >>> 48;
            }
         }

         var6 = (long[])var1.apply(Direction.SOUTH);
         if (var6 != null) {
            for (int var27 = 0; var27 < 16; var27++) {
               var5[var27 * 4 + 3] = var5[var27 * 4 + 3] | var4[var27 * 4 + 3] & var6[var27 * 4] << 48;
            }
         }

         var6 = (long[])var1.apply(Direction.WEST);
         if (var6 != null) {
            for (int var28 = 0; var28 < 64; var28++) {
               var5[var28] |= var4[var28] & 281479271743489L & var6[var28] >>> 15;
            }
         }

         var6 = (long[])var1.apply(Direction.EAST);
         if (var6 != null) {
            for (int var29 = 0; var29 < 64; var29++) {
               var5[var29] |= var4[var29] & -9223231297218904064L & var6[var29] << 15;
            }
         }

         boolean var30 = true;

         for (int var8 = 0; var30 && var8 < 64; var8++) {
            var30 = false;
            boolean var9 = (var8 & 1) == 0;

            for (int var10 = 0; var10 < 64; var10++) {
               int var11 = var9 ? var10 : 63 - var10;
               long var12 = var4[var11];
               if (var12 != 0L) {
                  long var14 = var5[var11];
                  long var16 = var14;
                  if ((var11 & 3) != 0) {
                     var16 = var14 | var5[var11 - 1] >>> 48;
                  }

                  if ((var11 & 3) != 3) {
                     var16 |= var5[var11 + 1] << 48;
                  }

                  if (var11 >= 4) {
                     var16 |= var5[var11 - 4];
                  }

                  if (var11 < 60) {
                     var16 |= var5[var11 + 4];
                  }

                  var16 &= var12;

                  while (true) {
                     long var18 = (var16 | var16 << 1 & -281479271743490L | var16 >>> 1 & 9223231297218904063L | var16 << 16 | var16 >>> 16) & var12;
                     if (var18 == var16) {
                        if (var16 != var14) {
                           var5[var11] = var16;
                           var30 = true;
                        }
                        break;
                     }

                     var16 = var18;
                  }
               }
            }
         }

         Carver.Chip var31 = null;

         for (int var32 = 0; var32 < 64; var32++) {
            long var33 = var4[var32] & ~var5[var32];
            if (var33 != 0L) {
               if (var31 == null) {
                  var31 = new Carver.Chip(var0.pos, var0.original);
               }

               var4[var32] &= var5[var32];

               while (var33 != 0L) {
                  int var34 = var32 * 64 + Long.numberOfTrailingZeros(var33);
                  var33 &= var33 - 1L;
                  var31.removed++;
                  var31.sample(var34 & 15, var34 >> 8, var34 >> 4 & 15, var2 + var34);
               }
            }
         }

         return var31;
      }
   }
}
