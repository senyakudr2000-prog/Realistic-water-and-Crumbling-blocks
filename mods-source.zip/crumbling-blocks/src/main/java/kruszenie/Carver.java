package kruszenie;

import it.unimi.dsi.fastutil.longs.Long2ObjectLinkedOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.TntBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

public final class Carver {
   public static final int SAMPLES = 10;
   static final long[] FULL = Mask.full();

   private Carver() {
   }

   static long mix(long var0) {
      var0 ^= var0 >>> 30;
      var0 *= -4658895280553007687L;
      var0 ^= var0 >>> 27;
      var0 *= -7723592293110705685L;
      return var0 ^ var0 >>> 31;
   }

   private static float lattice(int var0, int var1, int var2, long var3) {
      long var5 = mix(var3 ^ var0 * -7046029254386353131L ^ var1 * -4417276706812531889L ^ var2 * 1609587929392839161L);
      return (float)(var5 & 65535L) / 32767.5F - 1.0F;
   }

   public static float noise(int var0, int var1, int var2, long var3) {
      return 0.75F * lumps(var0, var1, var2, var3, 5) + 0.25F * grain(var0, var1, var2, var3);
   }

   public static float grain(int var0, int var1, int var2, long var3) {
      return lattice(var0, var1, var2, var3 ^ 25214903917L);
   }

   public static float lumps(int var0, int var1, int var2, long var3, int var5) {
      int var6 = Math.floorDiv(var0, var5);
      int var7 = Math.floorDiv(var1, var5);
      int var8 = Math.floorDiv(var2, var5);
      float var9 = (var0 - var6 * var5 + 0.5F) / var5;
      float var10 = (var1 - var7 * var5 + 0.5F) / var5;
      float var11 = (var2 - var8 * var5 + 0.5F) / var5;
      var9 = var9 * var9 * (3.0F - 2.0F * var9);
      var10 = var10 * var10 * (3.0F - 2.0F * var10);
      var11 = var11 * var11 * (3.0F - 2.0F * var11);
      float var12 = 0.0F;

      for (int var13 = 0; var13 < 8; var13++) {
         int var14 = var13 & 1;
         int var15 = var13 >> 1 & 1;
         int var16 = var13 >> 2;
         float var17 = (var14 == 1 ? var9 : 1.0F - var9) * (var15 == 1 ? var10 : 1.0F - var10) * (var16 == 1 ? var11 : 1.0F - var11);
         var12 += var17 * lattice(var6 + var14, var7 + var15, var8 + var16, var3);
      }

      return var12;
   }

   public static Carver.Result sphere(ServerLevel var0, Vec3 var1, double var2, double var4, long var6) {
      Carver.Job var8 = new Carver.Job(var0, var6);
      sphere(var8, var1, var2, var4);
      return var8.finish();
   }

   public static void sphere(Carver.Job var0, Vec3 var1, double var2, double var4) {
      ServerLevel var6 = var0.level;
      double var7 = var2 * 1.35 * (1.0 + var4);
      int var9 = Mth.floor(var1.x - var7);
      int var10 = Mth.floor(var1.x + var7);
      int var11 = Math.max(Mth.floor(var1.y - var7), var6.getMinBuildHeight());
      int var12 = Math.min(Mth.floor(var1.y + var7), (var6.getMaxBuildHeight() - 1));
      int var13 = Mth.floor(var1.z - var7);
      int var14 = Mth.floor(var1.z + var7);
      MutableBlockPos var15 = new MutableBlockPos();

      for (int var16 = var11; var16 <= var12; var16++) {
         for (int var17 = var13; var17 <= var14; var17++) {
            for (int var18 = var9; var18 <= var10; var18++) {
               var15.set(var18, var16, var17);
               Carver.Entry var19 = var0.entry(var15);
               if (var19 == null) {
                  BlockState var20 = var6.getBlockState(var15);
                  if (Materials.fragile(var20, var6, var15)) {
                     double var21 = var18 + 0.5 - var1.x;
                     double var23 = var16 + 0.5 - var1.y;
                     double var25 = var17 + 0.5 - var1.z;
                     if (var21 * var21 + var23 * var23 + var25 * var25 < var2 * var2 + 0.3) {
                        var0.breakFragile(var15.immutable(), var20);
                     }
                  }
               } else {
                  double var38 = var2 * Materials.softness(var19.original, var6, var15);
                  if (!(var38 <= 0.0)) {
                     double var22 = var38 * (1.0 + var4);
                     double var24 = var38 * (1.0 - var4);
                     double var26 = Math.max(Math.max(var18 - var1.x, var1.x - var18 - 1.0), 0.0);
                     double var28 = Math.max(Math.max(var16 - var1.y, var1.y - var16 - 1.0), 0.0);
                     double var30 = Math.max(Math.max(var17 - var1.z, var1.z - var17 - 1.0), 0.0);
                     if (!(var26 * var26 + var28 * var28 + var30 * var30 >= var22 * var22)) {
                        double var32 = Math.max(var1.x - var18, var18 + 1 - var1.x);
                        double var34 = Math.max(var1.y - var16, var16 + 1 - var1.y);
                        double var36 = Math.max(var1.z - var17, var17 + 1 - var1.z);
                        if (var32 * var32 + var34 * var34 + var36 * var36 < var24 * var24) {
                           var19.clearAll(var0.seed);
                        } else {
                           carve(var19, var18, var16, var17, var1.x, var1.y, var1.z, var38, var4, var0.seed);
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private static void carve(Carver.Entry var0, int var1, int var2, int var3, double var4, double var6, double var8, double var10, double var12, long var14) {
      long[] var16 = var0.bits;
      double var17 = var10 * (1.0 + var12);
      double var19 = var10 * (1.0 - var12);
      double var21 = var17 * var17;
      double var23 = var19 * var19;
      int var25 = Math.clamp((long)Mth.floor((var4 - var17 - var1) * 16.0), 0, 15);
      int var26 = Math.clamp((long)Mth.floor((var4 + var17 - var1) * 16.0), 0, 15);
      int var27 = Math.clamp((long)Mth.floor((var6 - var17 - var2) * 16.0), 0, 15);
      int var28 = Math.clamp((long)Mth.floor((var6 + var17 - var2) * 16.0), 0, 15);
      int var29 = Math.clamp((long)Mth.floor((var8 - var17 - var3) * 16.0), 0, 15);
      int var30 = Math.clamp((long)Mth.floor((var8 + var17 - var3) * 16.0), 0, 15);

      for (int var31 = var27; var31 <= var28; var31++) {
         double var32 = var2 + (var31 + 0.5) / 16.0 - var6;

         for (int var34 = var29; var34 <= var30; var34++) {
            double var35 = var3 + (var34 + 0.5) / 16.0 - var8;
            double var37 = var32 * var32 + var35 * var35;
            if (!(var37 >= var21)) {
               for (int var39 = var25; var39 <= var26; var39++) {
                  double var40 = var1 + (var39 + 0.5) / 16.0 - var4;
                  double var42 = var37 + var40 * var40;
                  if (!(var42 >= var21)) {
                     int var44 = Mask.idx(var39, var31, var34);
                     if (Mask.get(var16, var44)) {
                        if (var42 > var23) {
                           double var45 = var10 * (1.0 + var12 * noise(var1 * 16 + var39, var2 * 16 + var31, var3 * 16 + var34, var14));
                           if (var42 >= var45 * var45) {
                              continue;
                           }
                        }

                        var0.clear(var39, var31, var34, var14 + var44);
                     }
                  }
               }
            }
         }
      }
   }

   static void apply(ServerLevel var0, Carver.Entry var1) {
      BlockPos var2 = var1.pos;
      long[] var3 = var1.bits;
      if (Mask.isEmpty(var3)) {
         var1.chip.gone = true;
         var0.setBlock(var2, Blocks.AIR.defaultBlockState(), 3);
      } else {
         int var4 = Mask.fullFaces(var3);
         FragmentBlockEntity var5 = var1.be;
         BlockState var6;
         if (var5 == null) {
            var6 = FragmentBlock.withFaces(Materials.group(var1.original).block.defaultBlockState(), var4);
            var0.setBlock(var2, var6, 18);
            var5 = FragmentBlock.entity(var0, var2);
            if (var5 == null) {
               return;
            }
         } else {
            var6 = FragmentBlock.withFaces(var1.current, var4);
            if (var6 != var1.current) {
               var0.setBlock(var2, var6, 18);
            }
         }

         var5.set(var1.original, var3);
         notifyNeighbours(var0, var2, var6);
      }
   }

   static void notifyNeighbours(ServerLevel var0, BlockPos var1, BlockState var2) {
      var0.updateNeighborsAt(var1, var2.getBlock());
      var2.updateNeighbourShapes(var0, var1, 3);
   }

   public static final class Chip {
      public final BlockPos pos;
      public final BlockState state;
      public int removed;
      public final byte[] samples = new byte[30];
      public int sampleCount;
      public boolean gone;

      public Chip(BlockPos var1, BlockState var2) {
         this.pos = var1;
         this.state = var2;
      }

      void sample(int var1, int var2, int var3, long var4) {
         int var6;
         if (this.sampleCount < 10) {
            var6 = this.sampleCount++;
         } else {
            long var7 = Carver.mix(var4 + this.removed * -7046029254386353131L);
            int var9 = (int)Long.remainderUnsigned(var7, this.removed);
            if (var9 >= 10) {
               return;
            }

            var6 = var9;
         }

         this.samples[var6 * 3] = (byte)var1;
         this.samples[var6 * 3 + 1] = (byte)var2;
         this.samples[var6 * 3 + 2] = (byte)var3;
      }

      public void sampleAll(long[] var1, long var2) {
         int var4 = 0;

         for (int var5 = (int)(Carver.mix(var2) & 255L); var5 < 4096 && var4 < 10; var5 += 397) {
            if (var1 == null || Mask.get(var1, var5)) {
               this.samples[this.sampleCount * 3] = (byte)(var5 & 15);
               this.samples[this.sampleCount * 3 + 1] = (byte)(var5 >> 8);
               this.samples[this.sampleCount * 3 + 2] = (byte)(var5 >> 4 & 15);
               this.sampleCount++;
               var4++;
            }
         }
      }
   }

   public static final class Entry {
      public final BlockPos pos;
      final BlockState current;
      public final BlockState original;
      final FragmentBlockEntity be;
      public final long[] bits;
      public final Carver.Chip chip;

      Entry(BlockPos var1, BlockState var2, BlockState var3, FragmentBlockEntity var4) {
         this.pos = var1;
         this.current = var2;
         this.original = var3;
         this.be = var4;
         this.bits = var4 != null ? (long[])var4.bits().clone() : Materials.fresh(var3);
         this.chip = new Carver.Chip(var1, var3);
      }

      public void clear(int var1, int var2, int var3, long var4) {
         Mask.clear(this.bits, Mask.idx(var1, var2, var3));
         this.chip.removed++;
         this.chip.sample(var1, var2, var3, var4);
      }

      public void clearRun(int var1, int var2, int var3, int var4, long var5) {
         int var7 = Mask.idx(var1, var3, var4);
         long var8 = (1L << var2) - 1L << (var7 & 63);
         long var10 = this.bits[var7 >> 6] & var8;
         if (var10 != 0L) {
            this.bits[var7 >> 6] = this.bits[var7 >> 6] & ~var8;
            this.chip.removed = this.chip.removed + Long.bitCount(var10);
            this.chip.sample(var1 + Long.numberOfTrailingZeros(var10 >>> (var7 & 63)), var3, var4, var5 + var7);
         }
      }

      public void clearAll(long var1) {
         this.chip.removed = this.chip.removed + Mask.count(this.bits);
         this.chip.sampleCount = 0;
         this.chip.sampleAll(this.bits, var1);
         Arrays.fill(this.bits, 0L);
      }
   }

   public static final class Job {
      public final ServerLevel level;
      public final long seed;
      private final Long2ObjectLinkedOpenHashMap<Carver.Entry> entries = new Long2ObjectLinkedOpenHashMap();
      private final Carver.Result result = new Carver.Result();
      private Player breaker;
      public long looseNanos;

      public Job(ServerLevel var1, long var2) {
         this.level = var1;
         this.seed = var2;
      }

      public Carver.Entry entry(BlockPos var1) {
         long var2 = var1.asLong();
         Carver.Entry var4 = (Carver.Entry)this.entries.get(var2);
         if (var4 != null) {
            return var4;
         } else {
            BlockState var5 = this.level.getBlockState(var1);
            if (var5.isAir()) {
               return null;
            } else {
               if (var5.getBlock() instanceof FragmentBlock) {
                  FragmentBlockEntity var6 = FragmentBlock.entity(this.level, var1);
                  if (var6 == null) {
                     return null;
                  }

                  var4 = new Carver.Entry(var1.immutable(), var5, var6.original(), var6);
               } else {
                  if (!Materials.carvable(var5, this.level, var1)) {
                     return null;
                  }

                  var4 = new Carver.Entry(var1.immutable(), var5, var5, null);
               }

               this.entries.put(var2, var4);
               return var4;
            }
         }
      }

      public void forget(Carver.Entry var1) {
         this.entries.remove(var1.pos.asLong());
      }

      public void breakFragile(BlockPos var1, BlockState var2) {
         if (var2.is(Blocks.TNT)) {
            TntBlock.explode(this.level, var1);
            this.level.setBlock(var1, Blocks.AIR.defaultBlockState(), 3);
         } else {
            this.level.destroyBlock(var1, this.breaker != null && !this.breaker.isCreative(), this.breaker);
            this.result.fragile++;
         }
      }

      public Carver.Job by(Player var1) {
         this.breaker = var1;
         return this;
      }

      private long[] support(BlockPos var1, Direction var2) {
         BlockPos var3 = var1.relative(var2);
         Carver.Entry var4 = (Carver.Entry)this.entries.get(var3.asLong());
         if (var4 != null) {
            return var4.bits;
         } else {
            BlockState var5 = this.level.getBlockState(var3);
            if (var5.isAir()) {
               return null;
            } else if (var5.getBlock() instanceof FragmentBlock) {
               FragmentBlockEntity var6 = FragmentBlock.entity(this.level, var3);
               return var6 == null ? Carver.FULL : var6.bits();
            } else {
               return var5.getCollisionShape(this.level, var3).isEmpty() ? null : Carver.FULL;
            }
         }
      }

      public Carver.Result finish() {
         long var1 = System.nanoTime();
         ObjectIterator var3 = this.entries.values().iterator();

         while (var3.hasNext()) {
            Carver.Entry var4 = (Carver.Entry)var3.next();
            if (var4.chip.removed != 0 && !Mask.isEmpty(var4.bits)) {
               Carver.Chip var5 = Loose.drop(var4, var2 -> this.support(var4.pos, var2), this.seed);
               if (var5 != null) {
                  this.result.loose.add(var5);
                  this.result.voxels = this.result.voxels + var5.removed;
               }
            }
         }

         this.looseNanos = System.nanoTime() - var1;
         var3 = this.entries.values().iterator();

         while (var3.hasNext()) {
            Carver.Entry var7 = (Carver.Entry)var3.next();
            if (var7.chip.removed != 0) {
               Carver.apply(this.level, var7);
               this.result.chips.add(var7.chip);
               this.result.voxels = this.result.voxels + var7.chip.removed;
            }
         }

         return this.result;
      }
   }

   public static final class Result {
      public final List<Carver.Chip> chips = new ArrayList<>();
      public final List<Carver.Chip> loose = new ArrayList<>();
      public int voxels;
      public int fragile;
   }
}
