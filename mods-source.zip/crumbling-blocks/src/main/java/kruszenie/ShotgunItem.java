package kruszenie;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class ShotgunItem extends Item {
   public static final int COOLDOWN = 17;

   public ShotgunItem(Item.Properties properties) {
      super(properties);
   }

   @Override
   public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
      ItemStack stack = player.getItemInHand(hand);
      if (player.getCooldowns().isOnCooldown(this)) {
         return InteractionResultHolder.fail(stack);
      }

      player.getCooldowns().addCooldown(this, COOLDOWN);
      if (level instanceof ServerLevel serverLevel && player instanceof ServerPlayer serverPlayer) {
         Tools.shoot(serverLevel, serverPlayer, stack, hand);
      } else {
         player.setXRot(player.getXRot() - 3.5F);
      }

      return InteractionResultHolder.consume(stack);
   }
}
