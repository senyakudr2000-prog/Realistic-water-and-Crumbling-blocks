package kruszenie;

import java.util.Arrays;
import net.minecraft.core.Direction;

public final class Mask {
   public static final int N = 16;
   public static final int WORDS = 64;
   public static final int VOXELS = 4096;
   public static final float VOX = 0.0625F;

   private Mask() {
   }

   public static long[] full() {
      long[] var0 = new long[64];
      Arrays.fill(var0, -1L);
      return var0;
   }

   public static int idx(int var0, int var1, int var2) {
      return (var1 << 4 | var2) << 4 | var0;
   }

   public static boolean get(long[] var0, int var1, int var2, int var3) {
      int var4 = idx(var1, var2, var3);
      return (var0[var4 >> 6] >>> (var4 & 63) & 1L) != 0L;
   }

   public static boolean get(long[] var0, int var1) {
      return (var0[var1 >> 6] >>> (var1 & 63) & 1L) != 0L;
   }

   public static void clear(long[] var0, int var1) {
      var0[var1 >> 6] = var0[var1 >> 6] & ~(1L << (var1 & 63));
   }

   public static void set(long[] var0, int var1) {
      var0[var1 >> 6] = var0[var1 >> 6] | 1L << (var1 & 63);
   }

   public static int count(long[] var0) {
      int var1 = 0;

      for (long var5 : var0) {
         var1 += Long.bitCount(var5);
      }

      return var1;
   }

   public static boolean isEmpty(long[] var0) {
      for (long var4 : var0) {
         if (var4 != 0L) {
            return false;
         }
      }

      return true;
   }

   public static boolean isFull(long[] var0) {
      for (long var4 : var0) {
         if (var4 != -1L) {
            return false;
         }
      }

      return true;
   }

   public static int row(long[] var0, int var1, int var2) {
      int var3 = var1 << 4 | var2;
      return (int)(var0[var3 >> 2] >>> ((var3 & 3) << 4)) & 65535;
   }

   public static boolean faceFull(long[] var0, Direction var1) {
      switch (var1) {
         case DOWN:
            return var0[0] == -1L && var0[1] == -1L && var0[2] == -1L && var0[3] == -1L;
         case UP:
            return var0[60] == -1L && var0[61] == -1L && var0[62] == -1L && var0[63] == -1L;
         case NORTH:
            for (int var9 = 0; var9 < 16; var9++) {
               if (row(var0, var9, 0) != 65535) {
                  return false;
               }
            }

            return true;
         case SOUTH:
            for (int var8 = 0; var8 < 16; var8++) {
               if (row(var0, var8, 15) != 65535) {
                  return false;
               }
            }

            return true;
         case WEST:
            for (long var12 : var0) {
               if ((var12 & 281479271743489L) != 281479271743489L) {
                  return false;
               }
            }

            return true;
         default:
            for (long var5 : var0) {
               if ((var5 & -9223231297218904064L) != -9223231297218904064L) {
                  return false;
               }
            }

            return true;
      }
   }

   public static int fullFaces(long[] var0) {
      int var1 = 0;

      for (Direction var5 : Direction.values()) {
         if (faceFull(var0, var5)) {
            var1 |= 1 << var5.ordinal();
         }
      }

      return var1;
   }

   public static int[] bounds(long[] var0) {
      int var1 = 16;
      int var2 = 16;
      int var3 = 16;
      int var4 = 0;
      int var5 = 0;
      int var6 = 0;

      for (int var7 = 0; var7 < 16; var7++) {
         for (int var8 = 0; var8 < 16; var8++) {
            int var9 = row(var0, var7, var8);
            if (var9 != 0) {
               var2 = Math.min(var2, var7);
               var5 = Math.max(var5, var7 + 1);
               var3 = Math.min(var3, var8);
               var6 = Math.max(var6, var8 + 1);
               var1 = Math.min(var1, Integer.numberOfTrailingZeros(var9));
               var4 = Math.max(var4, 32 - Integer.numberOfLeadingZeros(var9));
            }
         }
      }

      return var4 == 0 ? new int[6] : new int[]{var1, var2, var3, var4, var5, var6};
   }
}
