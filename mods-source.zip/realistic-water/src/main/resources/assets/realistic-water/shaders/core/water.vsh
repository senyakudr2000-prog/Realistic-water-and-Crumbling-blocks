#version 150

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;
uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform vec3 Anchor;
uniform float Time;

out vec3 vTint;
out vec3 vLight;
out vec3 vLocal;
out vec3 vViewPos;
out vec2 vInfo;

const float TAU = 6.28318530718;

float waveHeight(vec2 p, float t) {
    float h = 0.0;
    h += sin(dot(p, vec2(11.0, 7.0)) * TAU / 64.0 + t * TAU * 3.0 / 20.0) * 0.50;
    h += sin(dot(p, vec2(-5.0, 13.0)) * TAU / 64.0 + t * TAU * 4.0 / 20.0) * 0.30;
    h += sin(dot(p, vec2(17.0, -3.0)) * TAU / 64.0 + t * TAU * 5.0 / 20.0) * 0.20;
    h += sin(dot(p, vec2(-9.0, -12.0)) * TAU / 64.0 + t * TAU * 3.0 / 20.0) * 0.20;
    return h;
}

void main() {
    float disp = step(0.75, Color.a);
    vec3 pos = Position;
    pos.y += disp * waveHeight(Position.xz + Anchor.xz, Time) * 0.06;
    vec4 view = ModelViewMat * vec4(pos, 1.0);
    gl_Position = ProjMat * view;
    vTint = Color.rgb;
    vLight = texture(Sampler2, clamp(vec2(UV2) / 256.0, vec2(0.5 / 16.0), vec2(15.5 / 16.0))).rgb;
    vLocal = pos;
    vViewPos = view.xyz;
    vInfo = UV0;
}
