#version 150

in vec3 vTint;
in vec3 vLight;
in vec3 vLocal;
in vec3 vViewPos;
in vec2 vInfo;

uniform vec3 Anchor;
uniform vec3 CamRel;
uniform vec4 SunDir;
uniform float Time;
uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

out vec4 fragColor;

const float TAU = 6.28318530718;

vec2 waveGrad(vec2 p, float t) {
    vec2 g = vec2(0.0);
    vec2 k;
    float ph;
    k = vec2(11.0, 7.0) * TAU / 64.0;
    ph = dot(p, vec2(11.0, 7.0)) * TAU / 64.0 + t * TAU * 3.0 / 20.0;
    g += k * cos(ph) * 0.50;
    k = vec2(-5.0, 13.0) * TAU / 64.0;
    ph = dot(p, vec2(-5.0, 13.0)) * TAU / 64.0 + t * TAU * 4.0 / 20.0;
    g += k * cos(ph) * 0.30;
    k = vec2(17.0, -3.0) * TAU / 64.0;
    ph = dot(p, vec2(17.0, -3.0)) * TAU / 64.0 + t * TAU * 5.0 / 20.0;
    g += k * cos(ph) * 0.20;
    k = vec2(-9.0, -12.0) * TAU / 64.0;
    ph = dot(p, vec2(-9.0, -12.0)) * TAU / 64.0 + t * TAU * 3.0 / 20.0;
    g += k * cos(ph) * 0.20;
    return g;
}

void main() {
    bool side = vInfo.x > 0.5;
    bool slime = vInfo.y > 0.5;
    vec2 g = waveGrad(vLocal.xz + Anchor.xz, Time);
    vec3 N = side ? vec3(0.0, 1.0, 0.0) : normalize(vec3(-g.x * 0.25, 1.0, -g.y * 0.25));
    vec3 V = normalize(CamRel - vLocal);
    if (dot(N, V) < 0.0) {
        N = -N;
    }
    float ndv = clamp(dot(N, V), 0.0, 1.0);
    float fres = 0.02 + 0.98 * pow(1.0 - ndv, 5.0);
    if (slime) {
        fres *= 0.4;
    }
    vec3 R = reflect(-V, N);
    vec3 horizon = FogColor.rgb;
    vec3 zenith = FogColor.rgb * vec3(0.45, 0.7, 1.3);
    vec3 sky = mix(horizon, zenith, clamp(R.y * 1.3, 0.0, 1.0));
    vec3 base = vTint * 0.8;
    float sunUp = step(0.0, SunDir.y) * (1.0 - SunDir.w);
    vec3 Rs = reflect(-SunDir.xyz, N);
    float spec = pow(max(dot(Rs, V), 0.0), 180.0) * sunUp * 2.0;
    vec3 col = mix(base * vLight, sky * vLight, fres) + vec3(spec) * vLight;
    float alpha = side ? 0.82 : clamp(0.58 + fres * 0.38, 0.0, 0.95);
    if (slime) {
        alpha = 0.9;
    }
    float d = length(vViewPos);
    float f = clamp((d - FogStart) / max(FogEnd - FogStart, 0.001), 0.0, 1.0);
    col = mix(col, FogColor.rgb, f);
    fragColor = vec4(col, alpha) * ColorModulator;
}
