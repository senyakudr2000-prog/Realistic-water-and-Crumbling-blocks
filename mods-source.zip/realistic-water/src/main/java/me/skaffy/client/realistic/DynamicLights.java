package me.skaffy.client.realistic;

import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;
import it.unimi.dsi.fastutil.longs.Long2IntMap.Entry;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import me.skaffy.physics.RigidBody;
import me.skaffy.realistic.RealisticBlockEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.BlockPos.MutableBlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.lighting.LevelLightEngine;
import org.joml.Vector3d;

public final class DynamicLights {
   private static final double RANGE = 128.0;
   private static final int REFRESH_TICKS = 40;
   private static Long2IntOpenHashMap lights = new Long2IntOpenHashMap();
   private static int age;

   private DynamicLights() {
   }

   public static boolean any() {
      return !lights.isEmpty();
   }

   public static int emission(long blockNode) {
      return lights.get(blockNode);
   }

   public static void tick(Minecraft mc) {
      ClientLevel level = mc.level;
      if (level != null && mc.player != null) {
         if (!mc.isPaused()) {
            Long2IntOpenHashMap now = new Long2IntOpenHashMap();
            Vector3d c = new Vector3d();

            for (RealisticBlockEntity e : level.getEntitiesOfClass(RealisticBlockEntity.class, mc.player.getBoundingBox().inflate(128.0))) {
               for (RigidBody.Cell cell : e.body.cells) {
                  int light = cell.payload instanceof BlockState state ? state.getLightEmission() : 0;
                  if (light > 0) {
                     e.body.toWorld(cell.x + 0.5, cell.y + 0.5, cell.z + 0.5, c);
                     long pos = BlockPos.asLong((int)Math.floor(c.x), (int)Math.floor(c.y), (int)Math.floor(c.z));
                     if (light > now.get(pos)) {
                        now.put(pos, light);
                     }
                  }
               }
            }

            Long2IntOpenHashMap before = lights;
            boolean refresh = ++age >= 40;
            if (refresh) {
               age = 0;
            }

            lights = now;
            LevelLightEngine engine = level.getLightEngine();
            MutableBlockPos p = new MutableBlockPos();
            ObjectIterator var15 = before.long2IntEntrySet().iterator();

            while (var15.hasNext()) {
               Entry entry = (Entry)var15.next();
               if (now.get(entry.getLongKey()) != entry.getIntValue()) {
                  engine.checkBlock(p.set(entry.getLongKey()));
               }
            }

            var15 = now.long2IntEntrySet().iterator();

            while (var15.hasNext()) {
               Entry entry = (Entry)var15.next();
               if (refresh || before.get(entry.getLongKey()) != entry.getIntValue()) {
                  engine.checkBlock(p.set(entry.getLongKey()));
               }
            }
         }
      } else {
         lights = new Long2IntOpenHashMap();
      }
   }
}
