package me.skaffy.client.realistic;

import me.skaffy.RealisticWater;
import me.skaffy.realistic.ConverterMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

public class ConverterScreen extends AbstractContainerScreen<ConverterMenu> {
   private static final ResourceLocation TEXTURE = RealisticWater.id("textures/gui/container/realistic_converter.png");

   public ConverterScreen(ConverterMenu menu, Inventory inventory, Component title) {
      super(menu, inventory, title);
      this.inventoryLabelY = this.imageHeight - 94;
   }

   @Override
   public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
      super.render(graphics, mouseX, mouseY, partialTick);
      this.renderTooltip(graphics, mouseX, mouseY);
   }

   @Override
   protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
      int xo = (this.width - this.imageWidth) / 2;
      int yo = (this.height - this.imageHeight) / 2;
      graphics.blit(TEXTURE, xo, yo, 0, 0, this.imageWidth, this.imageHeight);
   }
}
