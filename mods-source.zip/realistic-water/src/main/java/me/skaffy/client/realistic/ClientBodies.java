package me.skaffy.client.realistic;

import java.util.ArrayList;
import java.util.List;
import me.skaffy.net.BodyPushPayload;
import me.skaffy.net.BodyStatePayload;
import me.skaffy.physics.PhysicsWorld;
import me.skaffy.physics.RigidBody;
import me.skaffy.realistic.RealisticBlockEntity;
import me.skaffy.realistic.RealisticPhysics;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.Direction.Axis;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import me.skaffy.util.Input;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.joml.Vector3d;
import org.joml.Vector3fc;
import me.skaffy.util.Nullable;

public final class ClientBodies {
   private static final double RANGE = 64.0;
   private static final double KICK_BOUNCE = 0.6;
   private static final Axis[] AXES = new Axis[]{Axis.Y, Axis.X, Axis.Z};
   private static final double LOOKAHEAD = 0.02;
   private static PhysicsWorld world = RealisticPhysics.newWorld();
   @Nullable
   private static RealisticPhysics.LevelView view;
   @Nullable
   private static ClientLevel viewLevel;
   private static long tick;
   private static boolean stepped;
   private static final List<BodyPushPayload> incoming = new ArrayList<>();
   private static final List<RealisticBlockEntity> simulated = new ArrayList<>();

   private ClientBodies() {
   }

   static Input keys(LocalPlayer player) {
      net.minecraft.client.player.Input in = player.input;
      return new Input(in.up, in.down, in.left, in.right, in.jumping, in.shiftKeyDown, player.isSprinting());
   }

   public static void startTick(Minecraft mc) {
      tick++;
      stepped = false;
   }

   public static void receive(BodyPushPayload push) {
      incoming.add(push);
   }

   public static void beforePlayerMove(LocalPlayer player, Vec3 movement) {
      Minecraft mc = Minecraft.getInstance();
      if (!stepped && mc.level != null && player == mc.player) {
         if (!player.isSpectator()) {
            pushesFrom(player, movement);
         }

         step(mc.level);
      }
   }

   public static void endTick(Minecraft mc) {
      if (mc.level != null && mc.player != null) {
         if (!mc.isPaused()) {
            if (!stepped) {
               step(mc.level);
            }

            claimAndRelease(mc.level, mc.player);

            for (RealisticBlockEntity e : simulated) {
               boolean touching = e.touchedTick == tick || e.hasPassenger(mc.player);
               send(e, (byte)((touching ? 1 : 0) | (e.body.floating() ? 4 : 0) | e.stateFlags()));
            }
         }
      } else {
         world = RealisticPhysics.newWorld();
         view = null;
         viewLevel = null;
         incoming.clear();
         simulated.clear();
      }
   }

   private static void step(ClientLevel level) {
      stepped = true;
      if (level != viewLevel || view == null) {
         view = new RealisticPhysics.LevelView(level);
         viewLevel = level;
         world = RealisticPhysics.newWorld();
      }

      view.clear();
      world.bodies.clear();
      simulated.clear();
      Minecraft mc = Minecraft.getInstance();
      AABB area = mc.player != null ? mc.player.getBoundingBox().inflate(64.0) : null;
      if (area != null) {
         for (RealisticBlockEntity e : level.getEntitiesOfClass(RealisticBlockEntity.class, area)) {
            if (!e.body.cells.isEmpty() && !(e.body.mass <= 0.0)) {
               if (e.isSimulated()) {
                  e.body.kinematic = false;
                  simulated.add(e);
               } else {
                  asObstacle(e);
               }

               world.bodies.add(e.body);
            }
         }
      }

      LocalPlayer me = mc.player;

      for (RealisticBlockEntity ex : simulated) {
         Input driver = me != null && me.getVehicle() == ex && ex.getControllingPassenger() == me ? keys(me) : null;
         ex.addLoads(world, driver);
      }

      for (BodyPushPayload p : incoming) {
         if (level.getEntity(p.entityId()) instanceof RealisticBlockEntity ex && ex.isSimulated()) {
            world.pushes.add(new PhysicsWorld.Push(ex.body, p.px(), p.py(), p.pz(), p.dx(), p.dy(), p.dz(), p.target(), p.force(), p.kick()));
         }
      }

      incoming.clear();
      if (!simulated.isEmpty()) {
         double dt = 0.008333333333333333;

         for (int s = 0; s < 6; s++) {
            world.step(view, dt, (body, cell) -> {});
         }

         for (RealisticBlockEntity ex : simulated) {
            ex.afterClientStep();

            for (Entity rider : ex.getPassengers()) {
               ex.repositionRider(rider);
            }
         }
      }

      world.pushes.clear();
      world.turns.clear();
   }

   private static void asObstacle(RealisticBlockEntity e) {
      e.syncClientBody(e.position(), e.renderRotation(1.0F));
      Vector3fc v = e.syncedVelocity();
      Vector3fc w = e.syncedSpin();
      e.body.vel.set(v.x(), v.y(), v.z());
      e.body.ang.set(w.x(), w.y(), w.z());
      e.body.kinematic = true;
   }

   private static void claimAndRelease(ClientLevel level, LocalPlayer player) {
      int me = player.getId();
      double claim = 32.0;
      simulated.clear();

      for (RealisticBlockEntity e : level.getEntitiesOfClass(RealisticBlockEntity.class, player.getBoundingBox().inflate(64.0))) {
         int owner = e.owner();
         double d2 = e.distanceToSqr(player);
         if (e.isSimulated()) {
            if (owner != -2 && (owner < 0 || owner == me)) {
               if (owner == me) {
                  e.claimAge = 0;
               } else if (++e.claimAge > 20) {
                  e.stopSimulating();
                  e.claimCooldown = 40;
                  continue;
               }

               if (d2 > (claim + 8.0) * (claim + 8.0)) {
                  send(e, (byte)2);
                  e.stopSimulating();
                  e.claimCooldown = 20;
               } else {
                  simulated.add(e);
               }
            } else {
               e.stopSimulating();
            }
         } else if (owner >= 0 && owner != me && player.getVehicle() == e && e.getControllingPassenger() == player) {
            send(e, (byte)1);
         } else if (e.claimCooldown > 0) {
            e.claimCooldown--;
         } else if (owner == me || owner == -1 && d2 < claim * claim) {
            e.startSimulating();
            simulated.add(e);
         }
      }
   }

   private static void send(RealisticBlockEntity e, byte flags) {
      if (ClientPlayNetworking.canSend(BodyStatePayload.TYPE)) {
         RigidBody b = e.body;
         ClientPlayNetworking.send(
            new BodyStatePayload(
               e.getId(),
               b.pos.x,
               b.pos.y,
               b.pos.z,
               (float)b.rot.x,
               (float)b.rot.y,
               (float)b.rot.z,
               (float)b.rot.w,
               (float)b.vel.x,
               (float)b.vel.y,
               (float)b.vel.z,
               (float)b.ang.x,
               (float)b.ang.y,
               (float)b.ang.z,
               flags
            )
         );
      }
   }

   private static void pushesFrom(LocalPlayer player, Vec3 movement) {
      AABB box = player.getBoundingBox();
      AABB sweep = box.expandTowards(movement).inflate(0.001);

      for (RealisticBlockEntity e : player.level().getEntitiesOfClass(RealisticBlockEntity.class, sweep.inflate(0.5))) {
         if (!e.isSimulated()) {
            asObstacle(e);
         }

         List<VoxelShape> shapes = e.collisionShapes(sweep);
         if (!shapes.isEmpty()) {
            for (Axis axis : AXES) {
               double want = movement.get(axis);
               if (!(Math.abs(want) < 1.0E-7)) {
                  double reach = axis == Axis.Y ? want : want + Math.signum(want) * 0.02;
                  double allowed = Shapes.collide(axis, box, shapes, reach);
                  if (Math.abs(reach - allowed) > 1.0E-7) {
                     contact(player, e, box, shapes, axis, want, Math.min(Math.abs(allowed), Math.abs(want)) * Math.signum(want));
                  }
               }
            }
         }
      }
   }

   private static void contact(LocalPlayer player, RealisticBlockEntity e, AABB box, List<VoxelShape> shapes, Axis axis, double want, double allowed) {
      double sign = Math.signum(want);
      double nx = axis == Axis.X ? sign : 0.0;
      double ny = axis == Axis.Y ? sign : 0.0;
      double nz = axis == Axis.Z ? sign : 0.0;
      AABB moved = box.move(nx * Math.abs(want), ny * Math.abs(want), nz * Math.abs(want));
      Vector3d p = new Vector3d();
      double weight = 0.0;

      for (VoxelShape shape : shapes) {
         AABB b = shape.bounds();
         if (b.intersects(moved)) {
            AABB o = b.intersect(moved);
            double w = Math.max(o.getXsize() * o.getYsize() * o.getZsize(), 1.0E-9);
            p.add(o.getCenter().x * w, o.getCenter().y * w, o.getCenter().z * w);
            weight += w;
         }
      }

      if (!(weight <= 0.0)) {
         p.div(weight);
         double face = sign > 0.0 ? box.max(axis) + allowed : box.min(axis) + allowed;
         if (axis == Axis.X) {
            p.x = face;
         } else if (axis == Axis.Y) {
            p.y = face;
         } else {
            p.z = face;
         }

         boolean fresh = e.touchedTick < tick - 1L;
         e.touchedTick = tick;
         double mass = 80.0;
         if (axis == Axis.Y && want < 0.0) {
            double fall = -want * 20.0;
            push(player, e, p, 0.0, -1.0, 0.0, Double.POSITIVE_INFINITY, mass * 9.81, fresh && fall > 4.0 ? mass * fall : 0.0);
         } else {
            double speed = Math.abs(want) * 20.0;
            if (axis != Axis.Y) {
               speed = Math.max(speed, walkSpeed(player) * walkAlong(player, nx, nz));
            }

            double into = speed - e.body.velocityAt(p.x, p.y, p.z, new Vector3d()).dot(nx, ny, nz);
            if (!(into <= 0.0)) {
               Input in = keys(player);
               boolean sneak = in.shift();
               double base = sneak ? 5000.0 : (player.isSprinting() ? 25000.0 : 15000.0);
               MobEffectInstance strengthEffect = player.getEffect(MobEffects.DAMAGE_BOOST);
               int strength = strengthEffect != null ? strengthEffect.getAmplifier() + 1 : 0;
               double force = RealisticPhysics.pushForce(base, strength, speed);
               double target = speed;
               double kick = 0.0;
               double power = speed / 5.6 * (1.0 + 0.5 * strength);
               if (fresh && power > 1.0) {
                  double bounce = 0.6 * Math.clamp(1.0 - e.body.mass / 400.0, 0.0, 1.0) * Math.min(power - 1.0, 1.0);
                  target = speed + bounce * into;
                  kick = mass * into * (1.0 + bounce) * (1.0 + 0.5 * strength);
               }

               push(player, e, p, nx, ny, nz, target, force, kick);
            }
         }
      }
   }

   private static double walkSpeed(LocalPlayer player) {
      double speed = player.getSpeed() * 43.17;
      if (keys(player).shift()) {
         speed *= 0.3;
      }

      if (player.isInWater()) {
         speed *= 0.45;
      }

      return speed;
   }

   private static double walkAlong(LocalPlayer player, double nx, double nz) {
      Input in = keys(player);
      double forward = (in.forward() ? 1 : 0) - (in.backward() ? 1 : 0);
      double strafe = (in.left() ? 1 : 0) - (in.right() ? 1 : 0);
      double len = Math.sqrt(forward * forward + strafe * strafe);
      if (len < 1.0E-6) {
         return 0.0;
      } else {
         double yaw = Math.toRadians(player.getYRot());
         double fx = -Math.sin(yaw);
         double fz = Math.cos(yaw);
         double wx = (forward * fx + strafe * fz) / len;
         double wz = (forward * fz - strafe * fx) / len;
         return Math.max(wx * nx + wz * nz, 0.0);
      }
   }

   private static void push(LocalPlayer player, RealisticBlockEntity e, Vector3d p, double dx, double dy, double dz, double target, double force, double kick) {
      int owner = e.owner();
      if (!e.isSimulated() && owner == -1 && e.claimCooldown <= 0) {
         e.startSimulating();
      }

      if (e.isSimulated()) {
         world.pushes.add(new PhysicsWorld.Push(e.body, p.x, p.y, p.z, dx, dy, dz, target, force, kick));
      } else {
         if (ClientPlayNetworking.canSend(BodyPushPayload.TYPE)) {
            ClientPlayNetworking.send(
               new BodyPushPayload(e.getId(), (float)p.x, (float)p.y, (float)p.z, (float)dx, (float)dy, (float)dz, (float)target, (float)force, (float)kick)
            );
         }

         if (owner >= 0 && owner != player.getId()) {
            send(e, (byte)1);
         }
      }
   }
}
