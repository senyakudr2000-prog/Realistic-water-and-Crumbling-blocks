package me.skaffy.client.mixin;

import me.skaffy.ModContent;
import me.skaffy.realistic.RealisticBlockItem;
import me.skaffy.realistic.RealisticBoatItem;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.BoatItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Realistic block / boat items are displayed with the model of the item they were converted from. */
@Mixin({ItemRenderer.class})
public abstract class ItemRendererMixin {
   @Inject(
      method = {"getModel"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void realisticWater$sourceModel(ItemStack stack, @Nullable Level level, @Nullable LivingEntity entity, int seed, CallbackInfoReturnable<BakedModel> cir) {
      if (stack.is(ModContent.REALISTIC_BLOCK_ITEM)) {
         Block block = RealisticBlockItem.blockOf(stack);
         if (block != null && block.asItem() != net.minecraft.world.item.Items.AIR) {
            cir.setReturnValue(((ItemRenderer)(Object)this).getModel(new ItemStack(block.asItem()), level, entity, seed));
         }
      } else if (stack.is(ModContent.REALISTIC_BOAT_ITEM)) {
         BoatItem boat = RealisticBoatItem.boatOf(stack);
         if (boat != null) {
            cir.setReturnValue(((ItemRenderer)(Object)this).getModel(new ItemStack(boat), level, entity, seed));
         }
      }
   }
}
