package me.skaffy.client.mixin;

import me.skaffy.client.realistic.RealisticMining;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({Minecraft.class})
public class MinecraftMixin {
   @Inject(
      method = {"startAttack"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void realisticWater$startMining(CallbackInfoReturnable<Boolean> cir) {
      Minecraft mc = (Minecraft)(Object)this;
      if (mc.player != null && !mc.player.isSpectator() && RealisticMining.start(mc)) {
         cir.setReturnValue(false);
      }
   }

   @Inject(
      method = {"continueAttack"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void realisticWater$keepMining(boolean down, CallbackInfo ci) {
      Minecraft mc = (Minecraft)(Object)this;
      if (mc.player != null && !mc.player.isUsingItem() && RealisticMining.tick(mc, down)) {
         ci.cancel();
      }
   }
}
