package me.skaffy.client.water;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexBuffer;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexFormat;
import me.skaffy.ModContent;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

/**
 * Draws realistic water and slime with an own shader: animated waves, sky reflection, sun glint.
 * The geometry is rebuilt from the loaded chunks every few ticks and drawn from a vertex buffer.
 */
public final class WaterRenderer {
   private static final int RADIUS_CHUNKS = 6;
   private static final Direction[] SIDES = new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST};
   public static boolean enabled = true;
   private static ShaderInstance shader;
   private static VertexBuffer buffer;
   private static boolean hasMesh;
   private static int ax;
   private static int ay;
   private static int az;
   private static int ticks;

   private WaterRenderer() {
   }

   public static void setShader(ShaderInstance instance) {
      shader = instance;
   }

   /** True while this renderer draws the fluids (the vanilla fluid renderer then skips them). */
   public static boolean active() {
      return enabled && shader != null;
   }

   private static boolean isCustom(BlockState state) {
      return state.getBlock() == ModContent.REALISTIC_WATER_BLOCK || state.getBlock() == ModContent.REALISTIC_SLIME_BLOCK;
   }

   public static void tick(Minecraft mc) {
      ClientLevel level = mc.level;
      if (level == null || mc.player == null || !active()) {
         hasMesh = false;
         return;
      }

      if (++ticks % 3 != 0) {
         return;
      }

      rebuild(mc, level);
   }

   private static void rebuild(Minecraft mc, ClientLevel level) {
      BlockPos cam = mc.player.blockPosition();
      ax = cam.getX();
      ay = cam.getY();
      az = cam.getZ();
      BufferBuilder builder = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR_TEX_LIGHTMAP);
      BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
      int count = 0;
      int ccx = cam.getX() >> 4;
      int ccz = cam.getZ() >> 4;

      for (int dz = -RADIUS_CHUNKS; dz <= RADIUS_CHUNKS; dz++) {
         for (int dx = -RADIUS_CHUNKS; dx <= RADIUS_CHUNKS; dx++) {
            ChunkAccess access = level.getChunk(ccx + dx, ccz + dz, ChunkStatus.FULL, false);
            if (!(access instanceof LevelChunk chunk)) {
               continue;
            }

            LevelChunkSection[] sections = chunk.getSections();
            for (int s = 0; s < sections.length; s++) {
               LevelChunkSection section = sections[s];
               if (section.hasOnlyAir() || !section.maybeHas(WaterRenderer::isCustom)) {
                  continue;
               }

               int baseY = level.getMinSection() + s << 4;
               for (int y = 0; y < 16; y++) {
                  for (int z = 0; z < 16; z++) {
                     for (int x = 0; x < 16; x++) {
                        BlockState state = section.getBlockState(x, y, z);
                        if (isCustom(state)) {
                           pos.set((ccx + dx << 4) + x, baseY + y, (ccz + dz << 4) + z);
                           count += emit(level, pos, state, builder);
                        }
                     }
                  }
               }
            }
         }
      }

      MeshData mesh = builder.build();
      if (mesh == null || count == 0) {
         hasMesh = false;
         return;
      }

      if (buffer == null) {
         buffer = new VertexBuffer(VertexBuffer.Usage.DYNAMIC);
      }

      buffer.bind();
      buffer.upload(mesh);
      VertexBuffer.unbind();
      hasMesh = true;
   }

   private static boolean same(FluidState fluid, Fluid reference) {
      return !fluid.isEmpty() && fluid.getType().isSame(reference);
   }

   private static float corner(ClientLevel level, BlockPos pos, int cx, int cz, Fluid reference) {
      float sum = 0.0F;
      float weight = 0.0F;
      BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
      for (int i = 0; i < 4; i++) {
         int x = pos.getX() + cx - (i & 1);
         int z = pos.getZ() + cz - (i >> 1 & 1);
         p.set(x, pos.getY(), z);
         if (same(level.getFluidState(p.above()), reference)) {
            return 1.0F;
         }

         FluidState fs = level.getFluidState(p);
         if (same(fs, reference)) {
            float h = fs.getOwnHeight();
            if (h >= 0.8F) {
               sum += h * 10.0F;
               weight += 10.0F;
            } else {
               sum += h;
               weight += 1.0F;
            }
         } else if (!level.getBlockState(p).isSolid()) {
            weight += 1.0F;
         }
      }

      return weight == 0.0F ? 0.0F : sum / weight;
   }

   private static void vertex(VertexConsumer b, float x, float y, float z, int r, int g, int bl, int flag, float side, float material, int light) {
      b.addVertex(x - ax, y - ay, z - az).setColor(r, g, bl, flag).setUv(side, material).setLight(light);
   }

   private static int emit(ClientLevel level, BlockPos pos, BlockState state, VertexConsumer b) {
      boolean slime = state.getBlock() == ModContent.REALISTIC_SLIME_BLOCK;
      Fluid reference = slime ? ModContent.REALISTIC_SLIME : ModContent.REALISTIC_WATER;
      int tint = slime ? 0x7ED05C : level.getBiome(pos).value().getWaterColor();
      int r = tint >> 16 & 255;
      int g = tint >> 8 & 255;
      int bl = tint & 255;
      float material = slime ? 1.0F : 0.0F;
      int light = LevelRenderer.getLightColor(level, pos);
      float x = pos.getX();
      float y = pos.getY();
      float z = pos.getZ();
      boolean covered = same(level.getFluidState(pos.above()), reference);
      float h00 = corner(level, pos, 0, 0, reference);
      float h10 = corner(level, pos, 1, 0, reference);
      float h01 = corner(level, pos, 0, 1, reference);
      float h11 = corner(level, pos, 1, 1, reference);
      int quads = 0;

      if (!covered) {
         vertex(b, x, y + h00, z, r, g, bl, 255, 0.0F, material, light);
         vertex(b, x, y + h01, z + 1, r, g, bl, 255, 0.0F, material, light);
         vertex(b, x + 1, y + h11, z + 1, r, g, bl, 255, 0.0F, material, light);
         vertex(b, x + 1, y + h10, z, r, g, bl, 255, 0.0F, material, light);
         quads++;
      }

      for (Direction d : SIDES) {
         BlockPos n = pos.relative(d);
         if (same(level.getFluidState(n), reference)) {
            continue;
         }

         BlockState ns = level.getBlockState(n);
         if (ns.isSolidRender(level, n)) {
            continue;
         }

         float xa;
         float za;
         float xb;
         float zb;
         float ha;
         float hb;
         switch (d) {
            case NORTH -> {
               xa = x; za = z; xb = x + 1; zb = z; ha = h00; hb = h10;
            }
            case SOUTH -> {
               xa = x + 1; za = z + 1; xb = x; zb = z + 1; ha = h11; hb = h01;
            }
            case WEST -> {
               xa = x; za = z + 1; xb = x; zb = z; ha = h01; hb = h00;
            }
            default -> {
               xa = x + 1; za = z; xb = x + 1; zb = z + 1; ha = h10; hb = h11;
            }
         }

         vertex(b, xa, y, za, r, g, bl, 128, 1.0F, material, light);
         vertex(b, xa, y + ha, za, r, g, bl, 255, 1.0F, material, light);
         vertex(b, xb, y + hb, zb, r, g, bl, 255, 1.0F, material, light);
         vertex(b, xb, y, zb, r, g, bl, 128, 1.0F, material, light);
         quads++;
      }

      return quads;
   }

   public static void render(WorldRenderContext context) {
      if (!active() || !hasMesh || buffer == null) {
         return;
      }

      Minecraft mc = Minecraft.getInstance();
      ClientLevel level = context.world();
      Camera camera = context.camera();
      if (level == null || camera == null || context.matrixStack() == null) {
         return;
      }

      Vec3 cp = camera.getPosition();
      Matrix4f modelView = new Matrix4f(context.matrixStack().last().pose()).translate((float)(ax - cp.x), (float)(ay - cp.y), (float)(az - cp.z));
      float partial = mc.getTimer().getGameTimeDeltaPartialTick(false);
      double seconds = (level.getGameTime() + partial) / 20.0;
      float time = (float)(seconds % 20.0);
      float angle = level.getTimeOfDay(partial) * (float)(Math.PI * 2.0);

      shader.safeGetUniform("Anchor").set((float)Math.floorMod(ax, 64), (float)Math.floorMod(ay, 64), (float)Math.floorMod(az, 64));
      shader.safeGetUniform("CamRel").set((float)(cp.x - ax), (float)(cp.y - ay), (float)(cp.z - az));
      shader.safeGetUniform("SunDir").set(-(float)Math.sin(angle), (float)Math.cos(angle), 0.0F, level.getRainLevel(partial));
      shader.safeGetUniform("Time").set(time);

      mc.gameRenderer.lightTexture().turnOnLightLayer();
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableCull();
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(false);
      buffer.bind();
      buffer.drawWithShader(modelView, context.projectionMatrix(), shader);
      VertexBuffer.unbind();
      RenderSystem.depthMask(true);
      RenderSystem.enableCull();
      RenderSystem.disableBlend();
      mc.gameRenderer.lightTexture().turnOffLightLayer();
   }
}
