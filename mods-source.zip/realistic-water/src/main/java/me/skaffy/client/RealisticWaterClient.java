package me.skaffy.client;

import me.skaffy.ModContent;
import me.skaffy.client.realistic.ClientBodies;
import me.skaffy.client.realistic.ConverterScreen;
import me.skaffy.client.realistic.DynamicLights;
import me.skaffy.client.realistic.RealisticBlockRenderer;
import me.skaffy.client.realistic.RealisticBoatRenderer;
import me.skaffy.client.realistic.RealisticPlatform;
import me.skaffy.client.water.WaterRenderer;
import me.skaffy.net.BodyPushPayload;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.CoreShaderRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import net.minecraft.network.chat.Component;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.fabricmc.fabric.api.client.render.fluid.v1.SimpleFluidRenderHandler;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.renderer.BiomeColors;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FluidState;
import org.jetbrains.annotations.Nullable;

public class RealisticWaterClient implements ClientModInitializer {
   @Override
   public void onInitializeClient() {
      registerFluids();
      CoreShaderRegistrationCallback.EVENT.register(
         context -> context.register(me.skaffy.RealisticWater.id("water"), DefaultVertexFormat.POSITION_COLOR_TEX_LIGHTMAP, WaterRenderer::setShader)
      );
      WorldRenderEvents.AFTER_TRANSLUCENT.register(WaterRenderer::render);
      ClientTickEvents.END_CLIENT_TICK.register(WaterRenderer::tick);
      ClientCommandRegistrationCallback.EVENT.register(
         (dispatcher, registryAccess) -> dispatcher.register(
            ClientCommandManager.literal("rwater").then(ClientCommandManager.literal("vanilla").executes(ctx -> {
               WaterRenderer.enabled = !WaterRenderer.enabled;
               net.minecraft.client.Minecraft.getInstance().levelRenderer.allChanged();
               ctx.getSource().sendFeedback(Component.literal("Realistic water shader: " + (WaterRenderer.enabled ? "on" : "off (vanilla)")));
               return 1;
            }))
         )
      );
      BlockRenderLayerMap.INSTANCE.putBlock(ModContent.REALISTIC_LEAVES, RenderType.cutoutMipped());
      EntityRendererRegistry.register(ModContent.REALISTIC_BLOCK_ENTITY, RealisticBlockRenderer::new);
      EntityRendererRegistry.register(ModContent.REALISTIC_BOAT, RealisticBoatRenderer::new);
      MenuScreens.register(ModContent.CONVERTER_MENU, ConverterScreen::new);
      ClientTickEvents.START_CLIENT_TICK.register(ClientBodies::startTick);
      ClientTickEvents.END_CLIENT_TICK.register(ClientBodies::endTick);
      ClientTickEvents.END_CLIENT_TICK.register(RealisticPlatform::tick);
      ClientTickEvents.END_CLIENT_TICK.register(DynamicLights::tick);
      ClientPlayNetworking.registerGlobalReceiver(BodyPushPayload.TYPE, (payload, context) -> context.client().execute(() -> ClientBodies.receive(payload)));
   }

   private static void registerFluids() {
      ResourceLocation waterStill = ResourceLocation.withDefaultNamespace("block/water_still");
      ResourceLocation waterFlow = ResourceLocation.withDefaultNamespace("block/water_flow");
      ResourceLocation waterOverlay = ResourceLocation.withDefaultNamespace("block/water_overlay");
      SimpleFluidRenderHandler water = new SimpleFluidRenderHandler(waterStill, waterFlow, waterOverlay, 0xFFFFFF) {
         @Override
         public void renderFluid(BlockPos pos, BlockAndTintGetter world, com.mojang.blaze3d.vertex.VertexConsumer consumer, net.minecraft.world.level.block.state.BlockState blockState, FluidState fluidState) {
            if (!WaterRenderer.active()) {
               super.renderFluid(pos, world, consumer, blockState, fluidState);
            }
         }

         @Override
         public int getFluidColor(@Nullable BlockAndTintGetter view, @Nullable BlockPos pos, FluidState state) {
            return view != null && pos != null ? BiomeColors.getAverageWaterColor(view, pos) : 0x3F76E4;
         }
      };
      SimpleFluidRenderHandler slime = new SimpleFluidRenderHandler(waterStill, waterFlow, waterOverlay, 0x7ED05C) {
         @Override
         public void renderFluid(BlockPos pos, BlockAndTintGetter world, com.mojang.blaze3d.vertex.VertexConsumer consumer, net.minecraft.world.level.block.state.BlockState blockState, FluidState fluidState) {
            if (!WaterRenderer.active()) {
               super.renderFluid(pos, world, consumer, blockState, fluidState);
            }
         }
      };
      SimpleFluidRenderHandler lava = new SimpleFluidRenderHandler(
         ResourceLocation.withDefaultNamespace("block/lava_still"), ResourceLocation.withDefaultNamespace("block/lava_flow")
      );
      register(ModContent.REALISTIC_WATER, ModContent.FLOWING_REALISTIC_WATER, water);
      register(ModContent.REALISTIC_SLIME, ModContent.FLOWING_REALISTIC_SLIME, slime);
      register(ModContent.REALISTIC_LAVA, ModContent.FLOWING_REALISTIC_LAVA, lava);
      BlockRenderLayerMap.INSTANCE.putFluids(
         RenderType.translucent(),
         ModContent.REALISTIC_WATER,
         ModContent.FLOWING_REALISTIC_WATER,
         ModContent.REALISTIC_SLIME,
         ModContent.FLOWING_REALISTIC_SLIME
      );
   }

   private static void register(Fluid still, Fluid flowing, SimpleFluidRenderHandler handler) {
      FluidRenderHandlerRegistry.INSTANCE.register(still, handler);
      FluidRenderHandlerRegistry.INSTANCE.register(flowing, handler);
   }
}
