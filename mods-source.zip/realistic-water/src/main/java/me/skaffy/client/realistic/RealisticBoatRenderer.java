package me.skaffy.client.realistic;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.util.EnumMap;
import java.util.Map;
import me.skaffy.realistic.RealisticBoatEntity;
import net.minecraft.client.model.BoatModel;
import net.minecraft.client.model.ChestBoatModel;
import net.minecraft.client.model.ChestRaftModel;
import net.minecraft.client.model.ListModel;
import net.minecraft.client.model.RaftModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.vehicle.Boat;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class RealisticBoatRenderer extends EntityRenderer<RealisticBoatEntity> {
   private record Baked(ListModel<Boat> model, ModelPart root) {
   }

   private final Context context;
   private final Map<Boat.Type, Baked> plain = new EnumMap<>(Boat.Type.class);
   private final Map<Boat.Type, Baked> chest = new EnumMap<>(Boat.Type.class);

   public RealisticBoatRenderer(Context context) {
      super(context);
      this.context = context;
      this.shadowRadius = 0.0F;
   }

   private Baked baked(Boat.Type type, boolean withChest) {
      Map<Boat.Type, Baked> cache = withChest ? this.chest : this.plain;
      return cache.computeIfAbsent(type, t -> {
         ModelPart part = this.context.bakeLayer(withChest ? ModelLayers.createChestBoatModelName(t) : ModelLayers.createBoatModelName(t));
         ListModel<Boat> model;
         if (t == Boat.Type.BAMBOO) {
            model = withChest ? new ChestRaftModel(part) : new RaftModel(part);
         } else {
            model = withChest ? new ChestBoatModel(part) : new BoatModel(part);
         }

         return new Baked(model, part);
      });
   }

   private static ResourceLocation texture(Boat.Type type, boolean withChest) {
      return ResourceLocation.withDefaultNamespace((withChest ? "textures/entity/chest_boat/" : "textures/entity/boat/") + type.getName() + ".png");
   }

   @Override
   public ResourceLocation getTextureLocation(RealisticBoatEntity entity) {
      return texture(entity.boatType(), entity.hasChest());
   }

   private static void paddle(ModelPart paddle, int side, float rowing) {
      paddle.xRot = Mth.clampedLerp((float)(-Math.PI / 3), (float)(-Math.PI / 12), (Mth.sin(-rowing) + 1.0F) / 2.0F);
      paddle.yRot = Mth.clampedLerp((float)(-Math.PI / 4), (float)(Math.PI / 4), (Mth.sin(-rowing + 1.0F) + 1.0F) / 2.0F);
      if (side == 1) {
         paddle.yRot = (float)Math.PI - paddle.yRot;
      }
   }

   @Override
   public void render(RealisticBoatEntity entity, float yaw, float partialTicks, PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
      if (entity.body.cells.isEmpty()) {
         return;
      }

      Boat.Type type = entity.boatType();
      boolean withChest = entity.hasChest();
      Baked baked = this.baked(type, withChest);
      Vec3 at = entity.renderPosition(partialTicks);
      Vec3 base = entity.getPosition(partialTicks);
      Quaternionf rotation = entity.renderRotation(partialTicks);
      entity.syncClientBody(at, rotation);
      Vector3f origin = rotation.transform(new Vector3f((float)-entity.body.com.x, (float)-entity.body.com.y, (float)-entity.body.com.z));

      poseStack.pushPose();
      poseStack.translate(at.x - base.x + origin.x, at.y - base.y + origin.y, at.z - base.z + origin.z);
      poseStack.mulPose(rotation);
      poseStack.translate(0.0F, 0.375F, 0.0F);
      poseStack.mulPose(Axis.YP.rotationDegrees(180.0F));
      poseStack.scale(-1.0F, -1.0F, 1.0F);
      poseStack.mulPose(Axis.YP.rotationDegrees(90.0F));
      paddle(baked.root().getChild("left_paddle"), 0, entity.rowingTime(0, partialTicks));
      paddle(baked.root().getChild("right_paddle"), 1, entity.rowingTime(1, partialTicks));
      VertexConsumer consumer = buffer.getBuffer(baked.model().renderType(texture(type, withChest)));
      baked.model().renderToBuffer(poseStack, consumer, packedLight, OverlayTexture.NO_OVERLAY, -1);
      poseStack.popPose();
   }

   @Override
   public boolean shouldRender(RealisticBoatEntity entity, Frustum frustum, double camX, double camY, double camZ) {
      return true;
   }
}
