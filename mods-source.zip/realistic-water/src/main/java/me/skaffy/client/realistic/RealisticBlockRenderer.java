package me.skaffy.client.realistic;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import me.skaffy.physics.RigidBody;
import me.skaffy.realistic.RealisticBlockEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider.Context;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.resources.model.ModelBakery;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.Shapes;
import com.mojang.blaze3d.vertex.SheetedDecalTextureGenerator;
import org.joml.Vector3d;

public class RealisticBlockRenderer extends EntityRenderer<RealisticBlockEntity> {
   public RealisticBlockRenderer(Context context) {
      super(context);
      this.shadowRadius = 0.0F;
   }

   @Override
   public ResourceLocation getTextureLocation(RealisticBlockEntity entity) {
      return TextureAtlas.LOCATION_BLOCKS;
   }

   private static int light(ClientLevel level, BlockPos at) {
      int sky = 0;
      int block = 0;
      BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();

      for (int d = -1; d < 6; d++) {
         if (d < 0) {
            p.set(at);
         } else {
            p.setWithOffset(at, Direction.from3DDataValue(d));
         }

         if (d < 0 || !level.getBlockState(p).canOcclude()) {
            sky = Math.max(sky, level.getBrightness(LightLayer.SKY, p));
            block = Math.max(block, level.getBrightness(LightLayer.BLOCK, p));
         }
      }

      return LightTexture.pack(block, sky);
   }

   @Override
   public void render(RealisticBlockEntity entity, float yaw, float partialTicks, PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
      RigidBody body = entity.body;
      if (body.cells.isEmpty()) {
         return;
      }

      Vec3 at = entity.renderPosition(partialTicks);
      Vec3 base = entity.getPosition(partialTicks);
      org.joml.Quaternionf rotation = entity.renderRotation(partialTicks);
      entity.syncClientBody(at, rotation);
      ClientLevel level = entity.level() instanceof ClientLevel client ? client : null;
      Minecraft mc = Minecraft.getInstance();
      RealisticHit hovered = mc.hitResult instanceof RealisticHit hit && hit.getEntity() == entity ? hit : null;

      poseStack.pushPose();
      poseStack.translate(at.x - base.x, at.y - base.y, at.z - base.z);
      poseStack.mulPose(rotation);
      Vector3d center = new Vector3d();

      for (RigidBody.Cell cell : body.cells) {
         BlockState state = (BlockState)cell.payload;
         if (state.getRenderShape() != RenderShape.MODEL) {
            continue;
         }

         int light = packedLight;
         if (level != null) {
            body.toWorld(cell.x + 0.5, cell.y + 0.5, cell.z + 0.5, center);
            light = light(level, BlockPos.containing(center.x, center.y, center.z));
         }

         poseStack.pushPose();
         poseStack.translate(cell.x - body.com.x, cell.y - body.com.y, cell.z - body.com.z);
         mc.getBlockRenderer().renderSingleBlock(state, poseStack, buffer, light, OverlayTexture.NO_OVERLAY);

         int stage = RealisticMining.stage(entity.getId(), cell.x, cell.y, cell.z);
         if (stage >= 0 && level != null) {
            VertexConsumer decal = new SheetedDecalTextureGenerator(
               buffer.getBuffer(ModelBakery.DESTROY_TYPES.get(Math.min(stage, ModelBakery.DESTROY_TYPES.size() - 1))), poseStack.last(), 1.0F
            );
            mc.getBlockRenderer().renderBreakingTexture(state, BlockPos.ZERO, level, poseStack, decal);
         }

         if (hovered != null && hovered.x == cell.x && hovered.y == cell.y && hovered.z == cell.z) {
            LevelRenderer.renderLineBox(poseStack, buffer.getBuffer(RenderType.lines()), new net.minecraft.world.phys.AABB(0, 0, 0, 1, 1, 1), 0.0F, 0.0F, 0.0F, 0.4F);
         }

         poseStack.popPose();
      }

      poseStack.popPose();
   }

   @Override
   public boolean shouldRender(RealisticBlockEntity entity, net.minecraft.client.renderer.culling.Frustum frustum, double camX, double camY, double camZ) {
      return true;
   }
}
