package me.skaffy.util;

/** Replacement for the 26.x player Input record (not present in 1.21.1). */
public record Input(boolean forward, boolean backward, boolean left, boolean right, boolean jump, boolean shift, boolean sprint) {
   public static final Input EMPTY = new Input(false, false, false, false, false, false, false);
}
