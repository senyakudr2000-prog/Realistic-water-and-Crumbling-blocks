package me.skaffy.physics;

public interface PhysicsView {
   int WATER_MASK = 15;
   int LAVA_SHIFT = 4;
   int FIRE = 256;

   double[][] boxes(int var1, int var2, int var3);

   int medium(int var1, int var2, int var3);

   default boolean flow(int x, int y, int z, double[] out) {
      return false;
   }

   default double friction(int x, int y, int z) {
      return 1.0;
   }
}
