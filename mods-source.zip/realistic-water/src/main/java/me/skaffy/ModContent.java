package me.skaffy;

import me.skaffy.block.RealisticLavaBlock;
import me.skaffy.block.RealisticLeavesBlock;
import me.skaffy.block.RealisticSandBlock;
import me.skaffy.block.RealisticWaterBlock;
import me.skaffy.block.WaveMakerBlock;
import me.skaffy.fluid.RealisticLavaFluid;
import me.skaffy.fluid.RealisticSlimeFluid;
import me.skaffy.fluid.RealisticWaterFluid;
import me.skaffy.realistic.ConverterItem;
import me.skaffy.realistic.ConverterMenu;
import me.skaffy.realistic.RealisticBlockEntity;
import me.skaffy.realistic.RealisticBlockItem;
import me.skaffy.realistic.RealisticBoatEntity;
import me.skaffy.realistic.RealisticBoatItem;
import me.skaffy.util.Nullable;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;

public final class ModContent {
   public static final FlowingFluid FLOWING_REALISTIC_WATER = Registry.register(
      BuiltInRegistries.FLUID, RealisticWater.id("flowing_realistic_water"), new RealisticWaterFluid.Flowing()
   );
   public static final FlowingFluid REALISTIC_WATER = Registry.register(
      BuiltInRegistries.FLUID, RealisticWater.id("realistic_water"), new RealisticWaterFluid.Source()
   );
   public static final Block REALISTIC_WATER_BLOCK = Registry.register(
      BuiltInRegistries.BLOCK,
      RealisticWater.id("realistic_water"),
      new RealisticWaterBlock(
         REALISTIC_WATER,
         BlockBehaviour.Properties.of()
            .mapColor(MapColor.WATER)
            .replaceable()
            .noCollission()
            .strength(100.0F)
            .pushReaction(PushReaction.DESTROY)
            .noLootTable()
            .liquid()
            .sound(SoundType.EMPTY)
      )
   );
   public static final Item REALISTIC_WATER_BUCKET = Registry.register(
      BuiltInRegistries.ITEM,
      RealisticWater.id("realistic_water_bucket"),
      new BucketItem(REALISTIC_WATER, new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1))
   );
   public static final FlowingFluid FLOWING_REALISTIC_LAVA = Registry.register(
      BuiltInRegistries.FLUID, RealisticWater.id("flowing_realistic_lava"), new RealisticLavaFluid.Flowing()
   );
   public static final FlowingFluid REALISTIC_LAVA = Registry.register(
      BuiltInRegistries.FLUID, RealisticWater.id("realistic_lava"), new RealisticLavaFluid.Source()
   );
   public static final Block REALISTIC_LAVA_BLOCK = Registry.register(
      BuiltInRegistries.BLOCK,
      RealisticWater.id("realistic_lava"),
      new RealisticLavaBlock(
         REALISTIC_LAVA,
         BlockBehaviour.Properties.of()
            .mapColor(MapColor.FIRE)
            .replaceable()
            .noCollission()
            .strength(100.0F)
            .pushReaction(PushReaction.DESTROY)
            .noLootTable()
            .liquid()
            .lightLevel(state -> 15)
            .sound(SoundType.EMPTY)
      )
   );
   public static final Item REALISTIC_LAVA_BUCKET = Registry.register(
      BuiltInRegistries.ITEM,
      RealisticWater.id("realistic_lava_bucket"),
      new BucketItem(REALISTIC_LAVA, new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1))
   );
   public static final FlowingFluid FLOWING_REALISTIC_SLIME = Registry.register(
      BuiltInRegistries.FLUID, RealisticWater.id("flowing_realistic_slime"), new RealisticSlimeFluid.Flowing()
   );
   public static final FlowingFluid REALISTIC_SLIME = Registry.register(
      BuiltInRegistries.FLUID, RealisticWater.id("realistic_slime"), new RealisticSlimeFluid.Source()
   );
   public static final Block REALISTIC_SLIME_BLOCK = Registry.register(
      BuiltInRegistries.BLOCK,
      RealisticWater.id("realistic_slime"),
      new RealisticWaterBlock(
         REALISTIC_SLIME,
         BlockBehaviour.Properties.of()
            .mapColor(MapColor.GRASS)
            .replaceable()
            .noCollission()
            .strength(100.0F)
            .pushReaction(PushReaction.DESTROY)
            .noLootTable()
            .liquid()
            .sound(SoundType.EMPTY)
      )
   );
   public static final Item REALISTIC_SLIME_BUCKET = Registry.register(
      BuiltInRegistries.ITEM,
      RealisticWater.id("realistic_slime_bucket"),
      new BucketItem(REALISTIC_SLIME, new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1)) {
         @Override
         protected void playEmptySound(@Nullable net.minecraft.world.entity.player.Player user, LevelAccessor level, BlockPos pos) {
            level.playSound(user, pos, SoundEvents.SLIME_BLOCK_PLACE, SoundSource.BLOCKS, 1.0F, 1.0F);
            level.gameEvent(user, GameEvent.FLUID_PLACE, pos);
         }
      }
   );
   public static final Block REALISTIC_SAND = Registry.register(
      BuiltInRegistries.BLOCK,
      RealisticWater.id("realistic_sand"),
      new RealisticSandBlock(
         BlockBehaviour.Properties.of()
            .mapColor(MapColor.SAND)
            .instrument(NoteBlockInstrument.SNARE)
            .strength(0.5F)
            .sound(SoundType.SAND)
            .noOcclusion()
            .pushReaction(PushReaction.DESTROY)
            .isSuffocating((state, level, pos) -> false)
            .isViewBlocking((state, level, pos) -> false)
      )
   );
   public static final Item REALISTIC_SAND_ITEM = registerBlockItem("realistic_sand", REALISTIC_SAND);
   public static final Block REALISTIC_LEAVES = Registry.register(
      BuiltInRegistries.BLOCK,
      RealisticWater.id("realistic_leaves"),
      new RealisticLeavesBlock(
         BlockBehaviour.Properties.of()
            .mapColor(MapColor.COLOR_ORANGE)
            .strength(0.2F)
            .sound(SoundType.AZALEA_LEAVES)
            .noOcclusion()
            .ignitedByLava()
            .pushReaction(PushReaction.DESTROY)
            .isSuffocating((state, level, pos) -> false)
            .isViewBlocking((state, level, pos) -> false)
      )
   );
   public static final Item REALISTIC_LEAVES_ITEM = registerBlockItem("realistic_leaves", REALISTIC_LEAVES);
   public static final Block WAVE_MAKER = Registry.register(
      BuiltInRegistries.BLOCK,
      RealisticWater.id("wave_maker"),
      new WaveMakerBlock(
         BlockBehaviour.Properties.of()
            .mapColor(MapColor.WARPED_WART_BLOCK)
            .instrument(NoteBlockInstrument.BASEDRUM)
            .strength(1.5F, 6.0F)
            .sound(SoundType.METAL)
      )
   );
   public static final Item WAVE_MAKER_ITEM = registerBlockItem("wave_maker", WAVE_MAKER);
   public static final SoundEvent WAVE_MAKER_RUN = Registry.register(
      BuiltInRegistries.SOUND_EVENT, RealisticWater.id("block.wave_maker.run"), SoundEvent.createVariableRangeEvent(RealisticWater.id("block.wave_maker.run"))
   );
   public static final DataComponentType<ResourceLocation> SOURCE_BLOCK = Registry.register(
      BuiltInRegistries.DATA_COMPONENT_TYPE,
      RealisticWater.id("source_block"),
      DataComponentType.<ResourceLocation>builder().persistent(ResourceLocation.CODEC).networkSynchronized(ResourceLocation.STREAM_CODEC).build()
   );
   public static final Item REALISTIC_BLOCK_ITEM = Registry.register(
      BuiltInRegistries.ITEM, RealisticWater.id("realistic_block"), new RealisticBlockItem(new Item.Properties())
   );
   public static final DataComponentType<ResourceLocation> SOURCE_ITEM = Registry.register(
      BuiltInRegistries.DATA_COMPONENT_TYPE,
      RealisticWater.id("source_item"),
      DataComponentType.<ResourceLocation>builder().persistent(ResourceLocation.CODEC).networkSynchronized(ResourceLocation.STREAM_CODEC).build()
   );
   public static final Item REALISTIC_BOAT_ITEM = Registry.register(
      BuiltInRegistries.ITEM, RealisticWater.id("realistic_boat"), new RealisticBoatItem(new Item.Properties().stacksTo(1))
   );
   public static final Item CONVERTER = Registry.register(
      BuiltInRegistries.ITEM, RealisticWater.id("realistic_converter"), new ConverterItem(new Item.Properties().stacksTo(1))
   );
   public static final MenuType<ConverterMenu> CONVERTER_MENU = Registry.register(
      BuiltInRegistries.MENU, RealisticWater.id("realistic_converter"), new MenuType<>(ConverterMenu::new, FeatureFlags.VANILLA_SET)
   );
   public static final EntityType<RealisticBlockEntity> REALISTIC_BLOCK_ENTITY = Registry.register(
      BuiltInRegistries.ENTITY_TYPE,
      RealisticWater.id("realistic_block"),
      EntityType.Builder.<RealisticBlockEntity>of(RealisticBlockEntity::new, MobCategory.MISC)
         .sized(1.0F, 1.0F)
         .clientTrackingRange(10)
         .updateInterval(1)
         .build("realistic_block")
   );
   public static final EntityType<RealisticBoatEntity> REALISTIC_BOAT = Registry.register(
      BuiltInRegistries.ENTITY_TYPE,
      RealisticWater.id("realistic_boat"),
      EntityType.Builder.<RealisticBoatEntity>of(RealisticBoatEntity::new, MobCategory.MISC)
         .sized(1.375F, 0.5625F)
         .clientTrackingRange(10)
         .updateInterval(1)
         .build("realistic_boat")
   );

   private ModContent() {
   }

   private static Item registerBlockItem(String name, Block block) {
      BlockItem item = new BlockItem(block, new Item.Properties());
      item.registerBlocks(Item.BY_BLOCK, item);
      return Registry.register(BuiltInRegistries.ITEM, RealisticWater.id(name), item);
   }

   static void init() {
      ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(entries -> {
         entries.addAfter(Items.WATER_BUCKET, REALISTIC_WATER_BUCKET);
         entries.addAfter(Items.LAVA_BUCKET, REALISTIC_LAVA_BUCKET);
         entries.addAfter(REALISTIC_LAVA_BUCKET, REALISTIC_SLIME_BUCKET);
         entries.addAfter(REALISTIC_SLIME_BUCKET, CONVERTER);
         entries.addAfter(CONVERTER, WAVE_MAKER_ITEM);
      });
      ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.NATURAL_BLOCKS).register(entries -> {
         entries.addAfter(Items.SAND, REALISTIC_SAND_ITEM);
         entries.addAfter(Items.OAK_LEAVES, REALISTIC_LEAVES_ITEM);
      });
   }
}
