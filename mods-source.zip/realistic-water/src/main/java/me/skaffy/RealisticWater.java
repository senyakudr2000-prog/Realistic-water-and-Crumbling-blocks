package me.skaffy;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import me.skaffy.net.BodyPushPayload;
import me.skaffy.net.BodyStatePayload;
import me.skaffy.net.BreakRealisticPayload;
import me.skaffy.net.RemoveAllWaterPayload;
import me.skaffy.net.SyncMaterial;
import me.skaffy.realistic.RealisticPhysics;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RealisticWater implements ModInitializer {
   public static final String MOD_ID = "realistic-water";
   public static final Logger LOGGER = LoggerFactory.getLogger("realistic-water");

   @Override
   public void onInitialize() {
      ModContent.init();
      PayloadTypeRegistry.playC2S().register(BreakRealisticPayload.TYPE, BreakRealisticPayload.CODEC);
      PayloadTypeRegistry.playC2S().register(BodyStatePayload.TYPE, BodyStatePayload.CODEC);
      PayloadTypeRegistry.playC2S().register(BodyPushPayload.TYPE, BodyPushPayload.CODEC);
      PayloadTypeRegistry.playS2C().register(BodyPushPayload.TYPE, BodyPushPayload.CODEC);
      ServerPlayNetworking.registerGlobalReceiver(BodyStatePayload.TYPE, (payload, context) -> context.server().execute(() -> payload.apply(context.player())));
      ServerPlayNetworking.registerGlobalReceiver(BodyPushPayload.TYPE, (payload, context) -> context.server().execute(() -> payload.apply(context.player())));
      ServerPlayNetworking.registerGlobalReceiver(
         BreakRealisticPayload.TYPE, (payload, context) -> context.server().execute(() -> payload.apply(context.player()))
      );
      ServerTickEvents.END_WORLD_TICK.register(RealisticPhysics::tick);
      ServerLifecycleEvents.SERVER_STOPPED.register(server -> RealisticPhysics.clear());
      CommandRegistrationCallback.EVENT.register(
         (dispatcher, registryAccess, environment) -> dispatcher.register(
            Commands.literal("realisticwater")
               .requires(source -> source.hasPermission(2))
               .then(
                  Commands.literal("remove")
                     .then(
                        Commands.argument("material", StringArgumentType.word())
                           .then(Commands.argument("chunks", IntegerArgumentType.integer(1, 16)).executes(ctx -> {
                              ServerPlayer player = ctx.getSource().getPlayerOrException();
                              byte material = switch (StringArgumentType.getString(ctx, "material")) {
                                 case "sand" -> SyncMaterial.SAND;
                                 case "lava" -> SyncMaterial.LAVA;
                                 case "slime" -> SyncMaterial.SLIME;
                                 case "leaves" -> SyncMaterial.LEAVES;
                                 default -> SyncMaterial.WATER;
                              };
                              int removed = new RemoveAllWaterPayload(IntegerArgumentType.getInteger(ctx, "chunks"), material).apply(player);
                              ctx.getSource().sendSuccess(() -> Component.literal("Removed " + removed + " realistic " + SyncMaterial.label(material) + " blocks"), true);
                              return removed;
                           }))
                     )
               )
         )
      );
   }

   public static ResourceLocation id(String path) {
      return ResourceLocation.fromNamespaceAndPath(MOD_ID, path);
   }
}
