package me.skaffy.fluid;

import java.util.Optional;
import me.skaffy.ModContent;
import me.skaffy.sim.FluidSim;
import net.minecraft.server.level.ServerLevel;
import me.skaffy.block.RealisticWaterBlock;
import me.skaffy.util.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FluidState;

public abstract class RealisticSlimeFluid extends FlowingFluid {
   @Override
   public Fluid getFlowing() {
      return ModContent.FLOWING_REALISTIC_SLIME;
   }

   @Override
   public Fluid getSource() {
      return ModContent.REALISTIC_SLIME;
   }

   @Override
   public Item getBucket() {
      return ModContent.REALISTIC_SLIME_BUCKET;
   }

   public static boolean isRealistic(FluidState state) {
      return !state.isEmpty() && state.getType() instanceof RealisticSlimeFluid;
   }

   @Override
   public void tick(Level level, BlockPos pos, FluidState state) {
      if (level instanceof ServerLevel server) {
         FluidSim.tick(server, pos, FluidSim.Kind.SLIME);
      }
   }

   @Nullable
   @Override
   public ParticleOptions getDripParticle() {
      return null;
   }

   @Override
   protected boolean canConvertToSource(Level level) {
      return false;
   }

   @Override
   protected void beforeDestroyingBlock(LevelAccessor level, BlockPos pos, BlockState state) {
      BlockEntity blockEntity = state.hasBlockEntity() ? level.getBlockEntity(pos) : null;
      Block.dropResources(state, level, pos, blockEntity);
   }

   @Override
   public int getSlopeFindDistance(LevelReader level) {
      return 2;
   }

   @Override
   public BlockState createLegacyBlock(FluidState fluidState) {
      return ModContent.REALISTIC_SLIME_BLOCK.defaultBlockState()
         .setValue(LiquidBlock.LEVEL, getLegacyLevel(fluidState))
         .setValue(RealisticWaterBlock.INFINITE, false);
   }

   @Override
   public boolean isSame(Fluid other) {
      return other == ModContent.REALISTIC_SLIME || other == ModContent.FLOWING_REALISTIC_SLIME;
   }

   @Override
   public int getDropOff(LevelReader level) {
      return 3;
   }

   @Override
   public int getTickDelay(LevelReader level) {
      return 12;
   }

   @Override
   public boolean canBeReplacedWith(FluidState state, BlockGetter level, BlockPos pos, Fluid other, Direction direction) {
      return false;
   }

   @Override
   protected float getExplosionResistance() {
      return 100.0F;
   }

   @Override
   public Optional<SoundEvent> getPickupSound() {
      return Optional.of(SoundEvents.BUCKET_FILL);
   }

   public static class Flowing extends RealisticSlimeFluid {
      @Override
      protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
         super.createFluidStateDefinition(builder);
         builder.add(LEVEL);
      }

      @Override
      public int getAmount(FluidState fluidState) {
         return fluidState.getValue(LEVEL);
      }

      @Override
      public boolean isSource(FluidState fluidState) {
         return false;
      }
   }

   public static class Source extends RealisticSlimeFluid {
      @Override
      public int getAmount(FluidState fluidState) {
         return 8;
      }

      @Override
      public boolean isSource(FluidState fluidState) {
         return true;
      }
   }
}
