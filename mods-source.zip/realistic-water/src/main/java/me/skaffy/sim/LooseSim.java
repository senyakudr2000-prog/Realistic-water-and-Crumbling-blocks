package me.skaffy.sim;

import me.skaffy.block.LooseLayerBlock;
import me.skaffy.block.RealisticLeavesBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/** Layered granular material (sand, leaves): falls and slumps until it rests at its angle of repose. */
public final class LooseSim {
   private static final Direction[] HORIZONTAL = new Direction[]{Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST};

   private LooseSim() {
   }

   private static int layers(BlockState state, LooseLayerBlock block) {
      return state.getBlock() == block ? state.getValue(LooseLayerBlock.LAYERS) : 0;
   }

   private static boolean canHold(ServerLevel level, BlockPos pos, LooseLayerBlock block) {
      if (level.isOutsideBuildHeight(pos) || !level.isLoaded(pos)) {
         return false;
      }

      BlockState state = level.getBlockState(pos);
      if (state.getBlock() == block || state.isAir()) {
         return true;
      }

      return state.getFluidState().isEmpty() && state.canBeReplaced() && !(state.getBlock() instanceof LooseLayerBlock);
   }

   private static void set(ServerLevel level, BlockPos pos, LooseLayerBlock block, int layers) {
      if (layers <= 0) {
         if (level.getBlockState(pos).getBlock() == block) {
            level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
         }

         return;
      }

      BlockState current = level.getBlockState(pos);
      if (current.getBlock() != block && !current.isAir()) {
         level.destroyBlock(pos, true);
      }

      BlockState target = block.defaultBlockState().setValue(LooseLayerBlock.LAYERS, Math.min(8, layers));
      if (current != target) {
         level.setBlock(pos, target, 3);
      }

      level.scheduleTick(pos, block, delay(block));
   }

   public static int delay(LooseLayerBlock block) {
      return block instanceof RealisticLeavesBlock ? 6 : 4;
   }

   public static void wake(ServerLevel level, BlockPos pos, LooseLayerBlock block) {
      level.scheduleTick(pos, block, delay(block));
   }

   public static void tick(ServerLevel level, BlockPos pos, LooseLayerBlock block) {
      BlockState self = level.getBlockState(pos);
      if (self.getBlock() != block) {
         return;
      }

      int l = self.getValue(LooseLayerBlock.LAYERS);
      boolean moved = false;
      BlockPos below = pos.below();
      if (canHold(level, below, block)) {
         int cap = 8 - layers(level.getBlockState(below), block);
         if (cap > 0) {
            int t = Math.min(l, cap);
            set(level, below, block, layers(level.getBlockState(below), block) + t);
            set(level, pos, block, l - t);
            l -= t;
            moved = true;
         }
      }

      if (l > 0) {
         int threshold = block instanceof RealisticLeavesBlock ? 3 : 4;
         int start = level.getRandom().nextInt(4);
         for (int i = 0; i < 4 && l > 0; i++) {
            BlockPos n = pos.relative(HORIZONTAL[(start + i) & 3]);
            if (!canHold(level, n, block)) {
               continue;
            }

            int nl = layers(level.getBlockState(n), block);
            if (l - nl >= threshold && nl < 8) {
               set(level, n, block, nl + 1);
               set(level, pos, block, l - 1);
               l -= 1;
               moved = true;
            }
         }
      }

      if (moved && level.getBlockState(pos).getBlock() == block) {
         level.scheduleTick(pos, block, delay(block));
      }
   }
}
