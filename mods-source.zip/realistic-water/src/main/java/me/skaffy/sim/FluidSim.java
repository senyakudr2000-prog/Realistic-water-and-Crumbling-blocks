package me.skaffy.sim;

import me.skaffy.ModContent;
import me.skaffy.block.RealisticLeavesBlock;
import me.skaffy.block.RealisticWaterBlock;
import me.skaffy.fluid.FluidMixing;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FlowingFluid;

/**
 * Server side cellular fluid simulation. Every realistic fluid block holds 1..8 "eighths" of fluid
 * (the block's LEVEL property is 8 - amount). The total amount is conserved; only blocks flagged
 * INFINITE (placed with a bucket) act as endless sources.
 *
 * This replaces the original client-side GPU particle simulation, which cannot run on 1.21.1 / Android.
 */
public final class FluidSim {
   private static final Direction[] HORIZONTAL = new Direction[]{Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST};

   public enum Kind {
      WATER(false),
      LAVA(true),
      SLIME(true);

      final boolean viscous;

      Kind(boolean viscous) {
         this.viscous = viscous;
      }

      public Block block() {
         return switch (this) {
            case WATER -> ModContent.REALISTIC_WATER_BLOCK;
            case LAVA -> ModContent.REALISTIC_LAVA_BLOCK;
            case SLIME -> ModContent.REALISTIC_SLIME_BLOCK;
         };
      }

      public FlowingFluid still() {
         return switch (this) {
            case WATER -> ModContent.REALISTIC_WATER;
            case LAVA -> ModContent.REALISTIC_LAVA;
            case SLIME -> ModContent.REALISTIC_SLIME;
         };
      }

      public int delay() {
         return switch (this) {
            case WATER -> 3;
            case LAVA -> 20;
            case SLIME -> 12;
         };
      }
   }

   private FluidSim() {
   }

   public static int amount(BlockState state, Kind kind) {
      if (state.getBlock() != kind.block()) {
         return 0;
      }

      if (state.getValue(RealisticWaterBlock.INFINITE)) {
         return 8;
      }

      int level = state.getValue(LiquidBlock.LEVEL);
      return level >= 8 ? 8 : 8 - level;
   }

   public static BlockState stateFor(Kind kind, int amount) {
      BlockState full = kind.block().defaultBlockState().setValue(RealisticWaterBlock.INFINITE, false);
      return amount >= 8 ? full : full.setValue(LiquidBlock.LEVEL, 8 - Math.max(1, amount));
   }

   private static boolean canHold(ServerLevel level, BlockPos pos, Kind kind) {
      if (level.isOutsideBuildHeight(pos) || !level.isLoaded(pos)) {
         return false;
      }

      BlockState state = level.getBlockState(pos);
      if (state.getBlock() == kind.block() || state.isAir() || state.getBlock() instanceof RealisticLeavesBlock) {
         return true;
      }

      return !(state.getBlock() instanceof LiquidBlock) && state.getFluidState().isEmpty() && state.canBeReplaced();
   }

   private static int head(ServerLevel level, BlockPos pos, Kind kind, int own) {
      int h = own;
      BlockPos p = pos.above();

      for (int i = 0; i < 24; i++) {
         int a = amount(level.getBlockState(p), kind);
         if (a <= 0) {
            break;
         }

         h += a;
         p = p.above();
      }

      return h;
   }

   /** Changes the amount stored in a cell. Infinite cells are never modified. */
   private static void adjust(ServerLevel level, BlockPos pos, Kind kind, int delta) {
      BlockState current = level.getBlockState(pos);
      if (current.getBlock() == kind.block() && current.getValue(RealisticWaterBlock.INFINITE)) {
         return;
      }

      int next = Math.max(0, Math.min(8, amount(current, kind) + delta));
      if (next <= 0) {
         if (current.getBlock() == kind.block()) {
            level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
         }

         return;
      }

      if (current.getBlock() != kind.block() && !current.isAir()) {
         // washing away plants and similar replaceable blocks
         if (!(current.getBlock() instanceof RealisticLeavesBlock)) {
            level.destroyBlock(pos, true);
         }
      }

      BlockState target = stateFor(kind, next);
      if (current != target) {
         level.setBlock(pos, target, 3);
      }

      level.scheduleTick(pos, target.getFluidState().getType(), kind.delay());
   }

   /** Moves up to {@code units} eighths of whatever fluid sits in {@code from} into {@code to}. */
   public static boolean pump(ServerLevel level, BlockPos from, BlockPos to, int units) {
      BlockState source = level.getBlockState(from);
      for (Kind kind : Kind.values()) {
         int have = amount(source, kind);
         if (have <= 0) {
            continue;
         }

         if (!canHold(level, to, kind)) {
            return false;
         }

         int cap = 8 - amount(level.getBlockState(to), kind);
         int t = Math.min(Math.min(units, have), cap);
         if (t <= 0) {
            return false;
         }

         adjust(level, to, kind, t);
         adjust(level, from, kind, -t);
         return true;
      }

      return false;
   }

   public static void wake(ServerLevel level, BlockPos pos, Kind kind) {
      BlockState state = level.getBlockState(pos);
      if (state.getBlock() == kind.block()) {
         level.scheduleTick(pos, state.getFluidState().getType(), kind.delay());
      }
   }

   public static void tick(ServerLevel level, BlockPos pos, Kind kind) {
      BlockState self = level.getBlockState(pos);
      if (self.getBlock() != kind.block()) {
         return;
      }

      boolean infinite = self.getValue(RealisticWaterBlock.INFINITE);
      if (kind == Kind.LAVA && FluidMixing.solidifyIfTouchingWater(level, pos)) {
         return;
      }

      if (kind == Kind.WATER) {
         FluidMixing.solidifyLavaAround(level, pos);
      }

      int a = amount(self, kind);
      if (a <= 0) {
         return;
      }

      RandomSource random = level.getRandom();
      boolean moved = false;

      // 1. fall
      BlockPos below = pos.below();
      if (canHold(level, below, kind)) {
         int cap = 8 - amount(level.getBlockState(below), kind);
         if (cap > 0) {
            int t = Math.min(a, cap);
            adjust(level, below, kind, t);
            if (!infinite) {
               adjust(level, pos, kind, -t);
               a -= t;
            }

            moved = true;
         }
      }

      // 2. spread sideways towards lower fluid heads (this also transmits pressure)
      if (a > 0 || infinite) {
         int start = random.nextInt(4);
         for (int i = 0; i < 4 && (a > 0 || infinite); i++) {
            Direction d = HORIZONTAL[(start + i) & 3];
            BlockPos n = pos.relative(d);
            if (!canHold(level, n, kind)) {
               continue;
            }

            int na = amount(level.getBlockState(n), kind);
            int cap = 8 - na;
            if (cap <= 0) {
               continue;
            }

            int diff = head(level, pos, kind, a) - head(level, n, kind, na);
            if (diff < 2) {
               continue;
            }

            int m = Math.min(Math.min(a, cap), Math.max(1, diff / 2));
            if (kind.viscous) {
               m = 1;
            }

            adjust(level, n, kind, m);
            if (!infinite) {
               adjust(level, pos, kind, -m);
               a -= m;
            }

            moved = true;
         }
      }

      // 3. a full cell under pressure pushes fluid upwards (communicating vessels)
      if (a >= 8 && !infinite) {
         BlockPos above = pos.above();
         if (canHold(level, above, kind) && amount(level.getBlockState(above), kind) < 8) {
            int own = head(level, pos, kind, a);
            for (Direction d : HORIZONTAL) {
               BlockPos n = pos.relative(d);
               int na = amount(level.getBlockState(n), kind);
               if (na > 0 && head(level, n, kind, na) - own >= 2) {
                  adjust(level, above, kind, 1);
                  adjust(level, pos, kind, -1);
                  moved = true;
                  break;
               }
            }
         }
      }

      if (moved) {
         if (level.getBlockState(pos).getBlock() == kind.block()) {
            level.scheduleTick(pos, level.getBlockState(pos).getFluidState().getType(), kind.delay());
         }

         return;
      }

      // 4. isolated thin films dry up instead of lingering forever
      if (a == 1 && !infinite) {
         boolean lonely = true;
         for (Direction d : Direction.values()) {
            if (amount(level.getBlockState(pos.relative(d)), kind) >= 2) {
               lonely = false;
               break;
            }
         }

         if (lonely) {
            if (random.nextInt(3) == 0) {
               level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
            } else {
               level.scheduleTick(pos, level.getBlockState(pos).getFluidState().getType(), kind.delay());
            }
         }
      }
   }
}
