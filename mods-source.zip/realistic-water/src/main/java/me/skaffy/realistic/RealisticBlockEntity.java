package me.skaffy.realistic;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap.Entry;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import me.skaffy.ModContent;
import me.skaffy.block.WaveMakerBlock;
import me.skaffy.net.BodyStatePayload;
import me.skaffy.physics.PhysicsWorld;
import me.skaffy.physics.RigidBody;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.SynchedEntityData.Builder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import org.joml.Vector3d;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import me.skaffy.util.Nullable;
import me.skaffy.util.Input;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.nbt.Tag;

public class RealisticBlockEntity extends Entity {
   private static final EntityDataAccessor<String> DATA_CELLS = SynchedEntityData.defineId(RealisticBlockEntity.class, EntityDataSerializers.STRING);
   private static final EntityDataAccessor<Quaternionf> DATA_ROT = SynchedEntityData.defineId(RealisticBlockEntity.class, EntityDataSerializers.QUATERNION);
   private static final EntityDataAccessor<Boolean> DATA_FLOATING = SynchedEntityData.defineId(RealisticBlockEntity.class, EntityDataSerializers.BOOLEAN);
   private static final EntityDataAccessor<Integer> DATA_OWNER = SynchedEntityData.defineId(RealisticBlockEntity.class, EntityDataSerializers.INT);
   private static final EntityDataAccessor<Vector3f> DATA_VEL = SynchedEntityData.defineId(RealisticBlockEntity.class, EntityDataSerializers.VECTOR3);
   private static final EntityDataAccessor<Vector3f> DATA_SPIN = SynchedEntityData.defineId(RealisticBlockEntity.class, EntityDataSerializers.VECTOR3);
   public static final int FREE = -1;
   public static final int LOCKED = -2;
   private static final int LOCK_TICKS = 10;
   private static final int OWNER_TIMEOUT = 20;
   public static final double CLAIM_RANGE = 32.0;
   public final RigidBody body = new RigidBody();
   private boolean bodyNeedsPosition;
   int burningTicks;
   @Nullable
   private GridRedstone redstone;
   private final Quaternionf rotO = new Quaternionf();
   private final Quaternionf rotNow = new Quaternionf();
   private final Quaternionf rotTarget = new Quaternionf();
   private int lastStateTick;
   private int ownerTouchTick;
   private int lockTicks;
   private boolean simulated;
   public int claimAge;
   public int claimCooldown;
   public long touchedTick = Long.MIN_VALUE;
   private final Vector3d renderFrom = new Vector3d();
   private final Vector3d renderTo = new Vector3d();
   private static final double PISTON_IMPULSE = 3000.0;
   private static final double[][] CUBE = new double[][]{{0.0, 0.0, 0.0, 1.0, 1.0, 1.0}};
   private static final Direction[] BOX_FACES = new Direction[]{Direction.WEST, Direction.EAST, Direction.DOWN, Direction.UP, Direction.NORTH, Direction.SOUTH};

   public RealisticBlockEntity(EntityType<? extends RealisticBlockEntity> type, Level level) {
      super(type, level);
      this.noPhysics = true;
   }

   public static RealisticBlockEntity spawn(ServerLevel level, List<RigidBody.Cell> cells, Vector3d center, @Nullable RigidBody like) {
      RealisticBlockEntity e = new RealisticBlockEntity(ModContent.REALISTIC_BLOCK_ENTITY, level);
      e.body.setCells(cells);
      if (like != null) {
         e.body.rot.set(like.rot);
      }

      e.body.rebuild();
      e.body.pos.set(center);
      e.body.updateDerived();
      if (like != null) {
         like.velocityAt(center.x, center.y, center.z, e.body.vel);
         e.body.ang.set(like.ang);
      }

      e.syncShape();
      e.syncRotation();
      e.setPos(center.x, center.y, center.z);
      level.addFreshEntity(e);
      return e;
   }

   @Override
   protected void defineSynchedData(Builder builder) {
      builder.define(DATA_CELLS, "");
      builder.define(DATA_ROT, new Quaternionf());
      builder.define(DATA_FLOATING, false);
      builder.define(DATA_OWNER, -1);
      builder.define(DATA_VEL, new Vector3f());
      builder.define(DATA_SPIN, new Vector3f());
   }

   public int owner() {
      return (Integer)this.entityData.get(DATA_OWNER);
   }

   private void setOwner(int owner) {
      this.entityData.set(DATA_OWNER, owner);
   }

   public boolean isClientAuthoritative() {
      return this.owner() >= 0;
   }

   protected boolean isLocalClientAuthoritative() {
      return this.simulated;
   }

   public boolean isSimulated() {
      return this.simulated;
   }

   public Vector3fc syncedVelocity() {
      return this.entityData.get(DATA_VEL);
   }

   public Vector3fc syncedSpin() {
      return this.entityData.get(DATA_SPIN);
   }

   void syncShape() {
      StringBuilder sb = new StringBuilder();

      for (RigidBody.Cell c : this.body.cells) {
         if (!sb.isEmpty()) {
            sb.append(';');
         }

         sb.append(c.x).append(',').append(c.y).append(',').append(c.z).append(',').append(Block.getId((BlockState)c.payload));
      }

      this.entityData.set(DATA_CELLS, sb.toString());
   }

   void syncRotation() {
      this.entityData.set(DATA_ROT, new Quaternionf((float)this.body.rot.x, (float)this.body.rot.y, (float)this.body.rot.z, (float)this.body.rot.w));
   }

   public void onSyncedDataUpdated(EntityDataAccessor<?> accessor) {
      super.onSyncedDataUpdated(accessor);
      if (this.level().isClientSide()) {
         if (DATA_CELLS.equals(accessor)) {
            this.cellsChanged();
         } else if (DATA_ROT.equals(accessor)) {
            Quaternionfc q = this.entityData.get(DATA_ROT);
            boolean first = this.tickCount == 0;
            this.rotTarget.set(q);
            if (first && !this.simulated) {
               this.rotNow.set(q);
               this.rotO.set(q);
            }
         }
      }
   }

   protected void cellsChanged() {
      List<RigidBody.Cell> cells = new ArrayList<>();

      for (String part : ((String)this.entityData.get(DATA_CELLS)).split(";")) {
         String[] f = part.split(",");
         if (f.length == 4) {
            BlockState state = Block.stateById(Integer.parseInt(f[3]));
            cells.add(this.makeCell(Integer.parseInt(f[0]), Integer.parseInt(f[1]), Integer.parseInt(f[2]), state));
         }
      }

      if (this.sameCells(cells)) {
         boolean reshaped = false;

         for (RigidBody.Cell c : cells) {
            RigidBody.Cell old = this.body.cellAt(c.x, c.y, c.z);
            if (old.payload != c.payload) {
               reshaped |= !Arrays.deepEquals(old.boxes, c.boxes) || old.density != c.density;
               this.body.replaceCell(c);
            }
         }

         if (reshaped) {
            this.body.rebuild();
            if (this.simulated) {
               this.setPos(this.body.pos.x, this.body.pos.y, this.body.pos.z);
            }
         }
      } else {
         this.stopSimulating();
         boolean had = !this.body.cells.isEmpty() && this.body.mass > 0.0;
         Vector3d oldCom = new Vector3d(this.body.com);
         this.body.setCells(cells);
         this.body.rebuild();
         if (!had) {
            this.setPos(this.position());
         } else {
            Vector3d shift = this.body.rot.transform(new Vector3d(this.body.com).sub(oldCom));
            this.xo = this.xo + shift.x;
            this.yo = this.yo + shift.y;
            this.zo = this.zo + shift.z;
            this.setPos(this.getX() + shift.x, this.getY() + shift.y, this.getZ() + shift.z);
         }
      }
   }

   protected RigidBody.Cell makeCell(int x, int y, int z, BlockState state) {
      return BlockMaterials.cell(x, y, z, state);
   }

   protected double[][] playerBoxes(RigidBody.Cell cell) {
      return cell.payload instanceof BlockState state ? BlockMaterials.collisionBoxes(state) : CUBE;
   }

   public void addLoads(PhysicsWorld world, @Nullable Input driver) {
   }

   public byte stateFlags() {
      return 0;
   }

   protected void receivedFlags(byte flags) {
   }

   private boolean sameCells(List<RigidBody.Cell> cells) {
      if (cells.size() == this.body.cells.size() && !cells.isEmpty()) {
         for (RigidBody.Cell c : cells) {
            if (!this.body.hasCell(c.x, c.y, c.z)) {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   private int lerpSteps;
   private double lerpX;
   private double lerpY;
   private double lerpZ;

   @Override
   public void lerpTo(double x, double y, double z, float yRot, float xRot, int steps) {
      if (this.simulated) {
         return;
      }
      if (this.tickCount == 0 || steps <= 0) {
         this.setPos(x, y, z);
         this.lerpSteps = 0;
      } else {
         this.lerpX = x;
         this.lerpY = y;
         this.lerpZ = z;
         this.lerpSteps = steps;
      }
   }

   public void startSimulating() {
      this.syncClientBody(this.position(), this.rotNow);
      Vector3fc v = this.syncedVelocity();
      Vector3fc w = this.syncedSpin();
      this.body.vel.set(v.x(), v.y(), v.z());
      this.body.ang.set(w.x(), w.y(), w.z());
      this.renderFrom.set(this.body.pos);
      this.renderTo.set(this.body.pos);
      this.rotO.set(this.rotNow);
      this.claimAge = 0;
      this.simulated = true;
   }

   public void stopSimulating() {
      if (this.simulated) {
         this.simulated = false;
         this.rotTarget.set(this.rotNow);
      }
   }

   public void afterClientStep() {
      this.renderFrom.set(this.renderTo);
      this.renderTo.set(this.body.pos);
      this.rotO.set(this.rotNow);
      this.rotNow.set((float)this.body.rot.x, (float)this.body.rot.y, (float)this.body.rot.z, (float)this.body.rot.w);
      this.setPos(this.body.pos.x, this.body.pos.y, this.body.pos.z);
   }

   public Vec3 renderPosition(float partialTicks) {
      return !this.simulated
         ? this.getPosition(partialTicks)
         : new Vec3(
            this.renderFrom.x + (this.renderTo.x - this.renderFrom.x) * partialTicks,
            this.renderFrom.y + (this.renderTo.y - this.renderFrom.y) * partialTicks,
            this.renderFrom.z + (this.renderTo.z - this.renderFrom.z) * partialTicks
         );
   }

   public Vector3d clientVelocity() {
      return this.simulated
         ? new Vector3d(this.body.vel)
         : new Vector3d((this.getX() - this.xo) * 20.0, (this.getY() - this.yo) * 20.0, (this.getZ() - this.zo) * 20.0);
   }

   public Vector3d clientSpin() {
      Quaternionf dq = new Quaternionf(this.rotNow).mul(new Quaternionf(this.rotO).conjugate());
      if (dq.w < 0.0F) {
         dq.set(-dq.x, -dq.y, -dq.z, -dq.w);
      }

      double s = Math.sqrt(dq.x * dq.x + dq.y * dq.y + dq.z * dq.z);
      if (s < 1.0E-6) {
         return new Vector3d();
      } else {
         double angle = 2.0 * Math.atan2(s, dq.w) * 20.0;
         return new Vector3d(dq.x / s * angle, dq.y / s * angle, dq.z / s * angle);
      }
   }

   public Quaternionf renderRotation(float partialTicks) {
      return new Quaternionf(this.rotO).slerp(this.rotNow, partialTicks);
   }

   public void syncClientBody(Vec3 position, Quaternionfc rotation) {
      if (!this.simulated) {
         this.body.pos.set(position.x, position.y, position.z);
         this.body.rot.set(rotation.x(), rotation.y(), rotation.z(), rotation.w());
         if (!this.body.cells.isEmpty()) {
            this.body.updateDerived();
         }
      }
   }

   public void tick() {
      if (this.level().isClientSide()) {
         if (!this.simulated) {
            this.setOldPosAndRot();
            if (this.lerpSteps > 0) {
               double t = 1.0 / this.lerpSteps;
               this.lerpSteps--;
               this.setPos(this.getX() + (this.lerpX - this.getX()) * t, this.getY() + (this.lerpY - this.getY()) * t, this.getZ() + (this.lerpZ - this.getZ()) * t);
            }
            this.rotO.set(this.rotNow);
            this.rotNow.set(this.rotTarget);
            this.setPos(this.position());
         }
      } else if (this.body.cells.isEmpty()) {
         this.discard();
      } else {
         if (this.bodyNeedsPosition) {
            this.bodyNeedsPosition = false;
            this.body.pos.set(this.getX(), this.getY(), this.getZ());
            this.body.updateDerived();
         }

         if (this.burningTicks > 0) {
            this.burningTicks--;
         }

         this.checkOwner();
         if (this.redstone == null) {
            this.redstone = new GridRedstone(this);
         }

         this.redstone.tick();
         if (!this.isRemoved() && !this.body.cells.isEmpty()) {
            this.setSharedFlagOnFire(this.burningTicks > 0);
            if (this.getY() < this.level().getMinBuildHeight() - 64) {
               this.discard();
            } else {
               RealisticPhysics.track(this);
            }
         }
      }
   }

   void afterPhysics() {
      this.afterPhysics(this.body.floating());
   }

   private void afterPhysics(boolean floating) {
      Vector3d p = this.body.pos;
      if (p.x != this.getX() || p.y != this.getY() || p.z != this.getZ()) {
         this.setPos(p.x, p.y, p.z);
      }

      this.syncRotation();
      this.entityData.set(DATA_FLOATING, floating);
      this.entityData.set(DATA_VEL, new Vector3f((float)this.body.vel.x, (float)this.body.vel.y, (float)this.body.vel.z));
      this.entityData.set(DATA_SPIN, new Vector3f((float)this.body.ang.x, (float)this.body.ang.y, (float)this.body.ang.z));
   }

   private int serverTick() {
      return ((ServerLevel)this.level()).getServer().getTickCount();
   }

   private void checkOwner() {
      int owner = this.owner();
      if (owner == -2) {
         if (--this.lockTicks <= 0) {
            this.setOwner(-1);
         }
      } else if (owner >= 0
         && (this.serverTick() - this.lastStateTick > 20 || !(this.level().getEntity(owner) instanceof ServerPlayer p && !(p.distanceToSqr(this) > 4096.0)))) {
         this.setOwner(-1);
      }
   }

   void setCellStates(Long2ObjectMap<BlockState> changes) {
      boolean reshaped = false;
      ObjectIterator var3 = changes.long2ObjectEntrySet().iterator();

      while (var3.hasNext()) {
         Entry<BlockState> entry = (Entry<BlockState>)var3.next();
         long k = entry.getLongKey();
         RigidBody.Cell old = this.body.cellAt(BlockPos.getX(k), BlockPos.getY(k), BlockPos.getZ(k));
         if (old != null) {
            RigidBody.Cell next = this.makeCell(old.x, old.y, old.z, (BlockState)entry.getValue());
            reshaped |= !Arrays.deepEquals(old.boxes, next.boxes) || old.density != next.density;
            this.body.replaceCell(next);
         }
      }

      if (reshaped) {
         this.body.rebuild();
         this.setPos(this.body.pos.x, this.body.pos.y, this.body.pos.z);
      }

      this.syncShape();
   }

   void extendPiston(long base, BlockState extended, long front, BlockState head, List<Long> line, Direction facing, boolean kick) {
      this.lock();

      for (int i = line.size() - 1; i >= 0; i--) {
         long k = line.get(i);
         RigidBody.Cell c = this.body.removeCell(BlockPos.getX(k), BlockPos.getY(k), BlockPos.getZ(k));
         if (c != null) {
            this.body.addCell(c.moved(c.x + facing.getStepX(), c.y + facing.getStepY(), c.z + facing.getStepZ()));
         }
      }

      this.body.replaceCell(BlockMaterials.cell(BlockPos.getX(base), BlockPos.getY(base), BlockPos.getZ(base), extended));
      this.body.addCell(BlockMaterials.cell(BlockPos.getX(front), BlockPos.getY(front), BlockPos.getZ(front), head));
      this.body.rebuild();
      this.syncShape();
      this.afterPhysics();
      Vector3d tip = this.body
         .toWorld(
            BlockPos.getX(front) + 0.5 + facing.getStepX() * 0.3,
            BlockPos.getY(front) + 0.5 + facing.getStepY() * 0.3,
            BlockPos.getZ(front) + 0.5 + facing.getStepZ() * 0.3,
            new Vector3d()
         );
      this.level().playSound(null, tip.x, tip.y, tip.z, SoundEvents.PISTON_EXTEND, SoundSource.BLOCKS, 0.5F, this.random.nextFloat() * 0.25F + 0.6F);
      if (kick) {
         Vector3d dir = this.body.dirToWorld(facing.getStepX(), facing.getStepY(), facing.getStepZ(), new Vector3d());
         BlockPos at = BlockPos.containing(tip.x, tip.y, tip.z);
         RealisticBlockEntity other = null;

         for (RealisticBlockEntity e : this.level().getEntitiesOfClass(RealisticBlockEntity.class, new AABB(at).inflate(0.5))) {
            if (e != this && e.body.containsWorld(tip.x, tip.y, tip.z)) {
               other = e;
               break;
            }
         }

         boolean wall = !this.level().getBlockState(at).getCollisionShape(this.level(), at).isEmpty();
         if (wall || other != null) {
            double impulse = Math.min(3000.0, this.body.mass * 8.0);
            RealisticPhysics.push(this, tip.x, tip.y, tip.z, -dir.x, -dir.y, -dir.z, Double.POSITIVE_INFINITY, 0.0, impulse);
            if (other != null) {
               RealisticPhysics.push(other, tip.x, tip.y, tip.z, dir.x, dir.y, dir.z, Double.POSITIVE_INFINITY, 0.0, Math.min(3000.0, other.body.mass * 8.0));
            }
         }
      }
   }

   private void lock() {
      this.setOwner(-2);
      this.lockTicks = 10;
   }

   public void acceptState(ServerPlayer player, BodyStatePayload s) {
      if (!this.isRemoved() && !this.body.cells.isEmpty() && this.owner() != -2 && !(player.distanceToSqr(this) > 4096.0)) {
         int now = this.serverTick();
         int owner = this.owner();
         if (owner != player.getId()) {
            boolean free = owner == -1 || now - this.lastStateTick > 20;
            boolean idleOwner = s.has((byte)1) && now - this.ownerTouchTick > 10 || this.getControllingPassenger() == player;
            if (s.has((byte)2) || !free && !idleOwner || player.distanceToSqr(this) > 1024.0) {
               return;
            }
         }

         double[] all = new double[]{s.x(), s.y(), s.z(), s.qx(), s.qy(), s.qz(), s.qw(), s.vx(), s.vy(), s.vz(), s.wx(), s.wy(), s.wz()};

         for (double d : all) {
            if (!Double.isFinite(d)) {
               return;
            }
         }

         if (!(this.body.pos.distanceSquared(s.x(), s.y(), s.z()) > 64.0)) {
            this.body.pos.set(s.x(), s.y(), s.z());
            this.body.rot.set(s.qx(), s.qy(), s.qz(), s.qw());
            this.body.vel.set(s.vx(), s.vy(), s.vz());
            this.body.ang.set(s.wx(), s.wy(), s.wz());
            double speed = this.body.vel.length();
            if (speed > 60.0) {
               this.body.vel.mul(60.0 / speed);
            }

            this.body.updateDerived();
            this.afterPhysics(s.has((byte)4));
            this.receivedFlags(s.flags());
            if (s.has((byte)2)) {
               this.setOwner(-1);
            } else {
               this.setOwner(player.getId());
               this.lastStateTick = now;
               if (s.has((byte)1)) {
                  this.ownerTouchTick = now;
               }
            }
         }
      }
   }

   public void repositionRider(Entity rider) {
      this.positionRider(rider);
   }

   public boolean isFloating() {
      return (Boolean)this.entityData.get(DATA_FLOATING);
   }

   protected AABB makeBoundingBox() {
      Vec3 position = this.position();
      if (this.body != null && !this.body.cells.isEmpty()) {
         if (this.level() != null && this.level().isClientSide()) {
            this.syncClientBody(position, this.rotNow);
         } else {
            this.body.pos.set(position.x, position.y, position.z);
            this.body.updateDerived();
         }

         return new AABB(this.body.minX, this.body.minY, this.body.minZ, this.body.maxX, this.body.maxY, this.body.maxZ);
      } else {
         return super.makeBoundingBox();
      }
   }

   public List<VoxelShape> collisionShapes(AABB area) {
      List<VoxelShape> out = new ArrayList<>();
      RigidBody b = this.body;
      if (b.cells.isEmpty()) {
         return out;
      } else {
         Vector3d c = new Vector3d();
         Vector3d ax = new Vector3d();
         Vector3d ay = new Vector3d();
         Vector3d az = new Vector3d();

         for (RigidBody.Cell cell : b.cells) {
            double[][] boxes = this.playerBoxes(cell);

            for (double[] box : boxes) {
               double sx = box[3] - box[0];
               double sy = box[4] - box[1];
               double sz = box[5] - box[2];
               b.dirToWorld(sx * 0.25, 0.0, 0.0, ax);
               b.dirToWorld(0.0, sy * 0.25, 0.0, ay);
               b.dirToWorld(0.0, 0.0, sz * 0.25, az);
               double ex = Math.abs(ax.x) + Math.abs(ay.x) + Math.abs(az.x);
               double ey = Math.abs(ax.y) + Math.abs(ay.y) + Math.abs(az.y);
               double ez = Math.abs(ax.z) + Math.abs(ay.z) + Math.abs(az.z);

               for (int s = 0; s < 8; s++) {
                  b.toWorld(
                     cell.x + box[0] + sx * (0.25 + 0.5 * (s & 1)),
                     cell.y + box[1] + sy * (0.25 + 0.5 * (s >> 1 & 1)),
                     cell.z + box[2] + sz * (0.25 + 0.5 * (s >> 2)),
                     c
                  );
                  AABB sub = new AABB(c.x - ex, c.y - ey, c.z - ez, c.x + ex, c.y + ey, c.z + ez);
                  if (sub.intersects(area)) {
                     out.add(Shapes.create(sub));
                  }
               }
            }
         }

         return out;
      }
   }

   public static boolean wallAhead(Entity mover, Vec3 movement) {
      if (!(mover instanceof RealisticBlockEntity) && !(movement.horizontalDistanceSqr() < 1.0E-8)) {
         AABB box = mover.getBoundingBox();
         AABB moved = box.move(movement.x, 0.0, movement.z).deflate(1.0E-4);

         for (RealisticBlockEntity e : mover.level().getEntitiesOfClass(RealisticBlockEntity.class, moved.inflate(0.1))) {
            for (VoxelShape shape : e.collisionShapes(moved)) {
               AABB b = shape.bounds();
               if (b.maxY > box.minY + 0.01 && b.intersects(moved)) {
                  return true;
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   @Override
   public boolean hurt(DamageSource source, float damage) {
      return false;
   }

   public boolean isPickable() {
      return !this.isRemoved();
   }

   public boolean canBeCollidedWith() {
      return true;
   }

   public boolean isPushable() {
      return false;
   }

   public boolean isAttackable() {
      return false;
   }

   public boolean skipAttackInteraction(Entity source) {
      return true;
   }

   public void push(double xa, double ya, double za) {
   }

   public void push(Entity entity) {
   }

   public void pushFromExplosion(Vec3 impulse) {
      if (!this.level().isClientSide()) {
         RealisticPhysics.explosion(this, impulse);
      }
   }

   /** 1.21.1 explosions knock entities back through setDeltaMovement; turn that into a physics impulse. */
   @Override
   public void setDeltaMovement(Vec3 v) {
      if (this.body != null && this.level() != null && !this.level().isClientSide() && !this.body.cells.isEmpty()) {
         Vec3 impulse = v.subtract(this.getDeltaMovement());
         if (impulse.lengthSqr() > 1.0E-8) {
            this.pushFromExplosion(impulse);
         }
         return;
      }
      super.setDeltaMovement(v);
   }

   public void move(MoverType moverType, Vec3 delta) {
      if (!this.level().isClientSide() && moverType != MoverType.SELF && moverType != MoverType.PLAYER) {
         this.lock();
         this.body.pos.add(delta.x, delta.y, delta.z);
         this.body.vel.set(delta.x * 5.0, Math.max(delta.y * 5.0, this.body.vel.y), delta.z * 5.0);
         this.body.updateDerived();
         this.afterPhysics();
      }
   }

   @Override
   public InteractionResult interactAt(Player player, Vec3 location, InteractionHand hand) {
      ItemStack stack = player.getItemInHand(hand);
      Block block = RealisticBlockItem.blockOf(stack);
      Vec3 clicked = this.position().add(location);
      if (block == null) {
         return this.useCell(player, clicked);
      } else if (this.level().isClientSide()) {
         return InteractionResult.SUCCESS;
      } else {
         int[] spot = this.faceAt(clicked);
         if (spot != null && !this.body.hasCell(spot[0], spot[1], spot[2])) {
            Vector3d hit = this.body.toGrid(clicked.x, clicked.y, clicked.z, new Vector3d()).sub(spot[0], spot[1], spot[2]);
            Vec3 view = player.getViewVector(1.0F);
            Vector3d look = this.body.dirToGrid(view.x, view.y, view.z, new Vector3d());
            BlockState state = GridPlacement.stateFor(block, Direction.from3DDataValue(spot[3]), hit, look);
            if (state == null) {
               return InteractionResult.FAIL;
            } else {
               Vector3d center = this.body.toWorld(spot[0] + 0.5, spot[1] + 0.5, spot[2] + 0.5, new Vector3d());
               BlockPos at = BlockPos.containing(center.x, center.y, center.z);
               if (!this.level().getBlockState(at).getCollisionShape(this.level(), at).isEmpty()) {
                  return InteractionResult.FAIL;
               } else {
                  this.lock();
                  this.body.addCell(BlockMaterials.cell(spot[0], spot[1], spot[2], state));
                  this.body.rebuild();
                  this.syncShape();
                  this.afterPhysics();
                  SoundType sound = state.getSoundType();
                  this.level()
                     .playSound(
                        null,
                        center.x,
                        center.y,
                        center.z,
                        sound.getPlaceSound(),
                        SoundSource.BLOCKS,
                        (sound.getVolume() + 1.0F) / 2.0F,
                        sound.getPitch() * 0.8F
                     );
                  if (!player.getAbilities().instabuild) {
                     stack.shrink(1);
                  }

                  return InteractionResult.SUCCESS;
               }
            }
         } else {
            return InteractionResult.FAIL;
         }
      }
   }

   private InteractionResult useCell(Player player, Vec3 clicked) {
      RigidBody.Cell cell = this.cellAt(clicked);
      if (cell == null || !(cell.payload instanceof BlockState state && state.getBlock() instanceof WaveMakerBlock)) {
         return InteractionResult.PASS;
      } else if (this.level().isClientSide()) {
         return InteractionResult.SUCCESS;
      } else {
         BlockState next = (BlockState)state.cycle(WaveMakerBlock.SPEED);
         Long2ObjectOpenHashMap<BlockState> change = new Long2ObjectOpenHashMap();
         change.put(BlockPos.asLong(cell.x, cell.y, cell.z), next);
         this.setCellStates(change);
         WaveMakerBlock.announceSpeed(this.level(), player, clicked.x, clicked.y, clicked.z, next);
         return InteractionResult.SUCCESS;
      }
   }

   @Nullable
   public RigidBody.Cell cellAt(Vec3 world) {
      Vector3d g = this.body.toGrid(world.x, world.y, world.z, new Vector3d());
      int bx = (int)Math.floor(g.x);
      int by = (int)Math.floor(g.y);
      int bz = (int)Math.floor(g.z);

      for (int dx = -1; dx <= 1; dx++) {
         for (int dy = -1; dy <= 1; dy++) {
            for (int dz = -1; dz <= 1; dz++) {
               RigidBody.Cell cell = this.body.cellAt(bx + dx, by + dy, bz + dz);
               if (cell != null) {
                  for (double[] box : cell.boxes == null ? CUBE : cell.boxes) {
                     if (g.x > cell.x + box[0] - 0.03
                        && g.x < cell.x + box[3] + 0.03
                        && g.y > cell.y + box[1] - 0.03
                        && g.y < cell.y + box[4] + 0.03
                        && g.z > cell.z + box[2] - 0.03
                        && g.z < cell.z + box[5] + 0.03) {
                        return cell;
                     }
                  }
               }
            }
         }
      }

      return null;
   }

   @Nullable
   public int[] faceAt(Vec3 world) {
      Vector3d g = this.body.toGrid(world.x, world.y, world.z, new Vector3d());
      int[] best = null;
      double bestDist = 0.03;
      int bx = (int)Math.floor(g.x);
      int by = (int)Math.floor(g.y);
      int bz = (int)Math.floor(g.z);

      for (int dx = -1; dx <= 1; dx++) {
         for (int dy = -1; dy <= 1; dy++) {
            for (int dz = -1; dz <= 1; dz++) {
               RigidBody.Cell cell = this.body.cellAt(bx + dx, by + dy, bz + dz);
               if (cell != null) {
                  for (double[] box : cell.boxes == null ? CUBE : cell.boxes) {
                     double[] d = new double[]{
                        g.x - cell.x - box[0],
                        cell.x + box[3] - g.x,
                        g.y - cell.y - box[1],
                        cell.y + box[4] - g.y,
                        g.z - cell.z - box[2],
                        cell.z + box[5] - g.z
                     };
                     if (!(d[0] < -0.03) && !(d[1] < -0.03) && !(d[2] < -0.03) && !(d[3] < -0.03) && !(d[4] < -0.03) && !(d[5] < -0.03)) {
                        for (int f = 0; f < 6; f++) {
                           double dist = Math.abs(d[f]);
                           Direction face = BOX_FACES[f];
                           int[] n = new int[]{cell.x + face.getStepX(), cell.y + face.getStepY(), cell.z + face.getStepZ(), face.get3DDataValue()};
                           if (dist < bestDist && !this.body.hasCell(n[0], n[1], n[2])) {
                              bestDist = dist;
                              best = n;
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      return best;
   }

   public void removeCell(int x, int y, int z) {
      if (this.body.removeCell(x, y, z) != null) {
         this.lock();
         if (this.body.cells.isEmpty()) {
            this.discard();
         } else {
            List<List<RigidBody.Cell>> parts = this.body.components();
            if (parts.size() > 1 && this.level() instanceof ServerLevel server) {
               parts.sort(Comparator.comparingInt(List::size));

               for (List<RigidBody.Cell> part : parts.subList(0, parts.size() - 1)) {
                  for (RigidBody.Cell c : part) {
                     this.body.removeCell(c.x, c.y, c.z);
                  }

                  RigidBody probe = new RigidBody();
                  probe.setCells(part);
                  probe.rebuild();
                  Vector3d center = this.body.toWorld(probe.com.x, probe.com.y, probe.com.z, new Vector3d());
                  spawn(server, part, center, this.body);
               }
            }

            this.body.rebuild();
            this.syncShape();
            this.afterPhysics();
         }
      }
   }

   @Override
   protected void addAdditionalSaveData(CompoundTag output) {
      ListTag list = new ListTag();

      for (RigidBody.Cell c : this.body.cells) {
         CompoundTag o = new CompoundTag();
         o.putInt("x", c.x);
         o.putInt("y", c.y);
         o.putInt("z", c.z);
         o.put("state", NbtUtils.writeBlockState((BlockState)c.payload));
         o.putDouble("burn", c.burn);
         list.add(o);
      }

      output.put("cells", list);
      output.putDouble("qx", this.body.rot.x);
      output.putDouble("qy", this.body.rot.y);
      output.putDouble("qz", this.body.rot.z);
      output.putDouble("qw", this.body.rot.w);
      output.putDouble("vx", this.body.vel.x);
      output.putDouble("vy", this.body.vel.y);
      output.putDouble("vz", this.body.vel.z);
      output.putDouble("wx", this.body.ang.x);
      output.putDouble("wy", this.body.ang.y);
      output.putDouble("wz", this.body.ang.z);
   }

   @Override
   protected void readAdditionalSaveData(CompoundTag input) {
      List<RigidBody.Cell> cells = new ArrayList<>();
      ListTag list = input.getList("cells", Tag.TAG_COMPOUND);

      for (int i = 0; i < list.size(); i++) {
         CompoundTag o = list.getCompound(i);
         BlockState state = NbtUtils.readBlockState(BuiltInRegistries.BLOCK.asLookup(), o.getCompound("state"));
         RigidBody.Cell c = this.makeCell(o.getInt("x"), o.getInt("y"), o.getInt("z"), state);
         c.burn = o.getDouble("burn");
         cells.add(c);
      }

      this.body.setCells(cells);
      this.body.rot.set(input.getDouble("qx"), input.getDouble("qy"), input.getDouble("qz"), input.contains("qw") ? input.getDouble("qw") : 1.0);
      this.body.vel.set(input.getDouble("vx"), input.getDouble("vy"), input.getDouble("vz"));
      this.body.ang.set(input.getDouble("wx"), input.getDouble("wy"), input.getDouble("wz"));
      this.body.rebuild();
      this.bodyNeedsPosition = true;
      this.setPos(this.position());
      this.syncShape();
      this.syncRotation();
   }
}
