package me.skaffy.realistic;

import java.util.Objects;
import me.skaffy.ModContent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.ResultContainer;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

public class ConverterMenu extends AbstractContainerMenu {
   private static final int INPUT = 0;
   private static final int RESULT = 1;
   private static final int INV_START = 2;
   private static final int INV_END = 38;
   private final ContainerLevelAccess access;
   private final Container input = new SimpleContainer(1) {
      {
         Objects.requireNonNull(ConverterMenu.this);
      }

      public void setChanged() {
         super.setChanged();
         ConverterMenu.this.slotsChanged(this);
      }
   };
   private final ResultContainer result = new ResultContainer();

   public ConverterMenu(int containerId, Inventory inventory) {
      this(containerId, inventory, ContainerLevelAccess.NULL);
   }

   public ConverterMenu(int containerId, Inventory inventory, final ContainerLevelAccess access) {
      super(ModContent.CONVERTER_MENU, containerId);
      this.access = access;
      this.addSlot(new Slot(this.input, 0, 56, 35) {
         {
            Objects.requireNonNull(ConverterMenu.this);
         }

         public boolean mayPlace(ItemStack stack) {
            return RealisticBlockItem.convertible(stack);
         }
      });
      this.addSlot(new Slot(this.result, 0, 116, 35) {
         {
            Objects.requireNonNull(ConverterMenu.this);
         }

         public boolean mayPlace(ItemStack stack) {
            return false;
         }

         public void onTake(Player player, ItemStack carried) {
            ConverterMenu.this.input.removeItem(0, carried.getCount());
            access.execute((level, pos) -> level.playSound(null, pos, SoundEvents.UI_STONECUTTER_TAKE_RESULT, SoundSource.BLOCKS, 1.0F, 1.0F));
            super.onTake(player, carried);
         }
      });
      for (int row = 0; row < 3; row++) {
         for (int col = 0; col < 9; col++) {
            this.addSlot(new Slot(inventory, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
         }
      }

      for (int col = 0; col < 9; col++) {
         this.addSlot(new Slot(inventory, col, 8 + col * 18, 142));
      }
   }

   public void slotsChanged(Container container) {
      super.slotsChanged(container);
      if (container == this.input) {
         this.result.setItem(0, RealisticBlockItem.convert(this.input.getItem(0)));
         this.broadcastChanges();
      }
   }

   public ItemStack quickMoveStack(Player player, int slotIndex) {
      Slot slot = (Slot)this.slots.get(slotIndex);
      if (!slot.hasItem()) {
         return ItemStack.EMPTY;
      } else {
         ItemStack stack = slot.getItem();
         ItemStack copy = stack.copy();
         if (slotIndex == 1) {
            if (!this.moveItemStackTo(stack, 2, 38, true)) {
               return ItemStack.EMPTY;
            } else {
               int moved = copy.getCount() - stack.getCount();
               slot.onTake(player, copy.copyWithCount(moved));
               this.slotsChanged(this.input);
               return ItemStack.EMPTY;
            }
         } else {
            if (slotIndex == 0) {
               if (!this.moveItemStackTo(stack, 2, 38, false)) {
                  return ItemStack.EMPTY;
               }
            } else if (RealisticBlockItem.convertible(stack)) {
               if (!this.moveItemStackTo(stack, 0, 1, false)) {
                  return ItemStack.EMPTY;
               }
            } else if (slotIndex < 29) {
               if (!this.moveItemStackTo(stack, 29, 38, false)) {
                  return ItemStack.EMPTY;
               }
            } else if (!this.moveItemStackTo(stack, 2, 29, false)) {
               return ItemStack.EMPTY;
            }

            if (stack.isEmpty()) {
               slot.setByPlayer(ItemStack.EMPTY);
            } else {
               slot.setChanged();
            }

            return copy.getCount() == stack.getCount() ? ItemStack.EMPTY : copy;
         }
      }
   }

   public boolean stillValid(Player player) {
      return true;
   }

   public void removed(Player player) {
      super.removed(player);
      this.result.removeItemNoUpdate(0);
      this.access.execute((level, pos) -> this.clearContainer(player, this.input));
   }
}
