package me.skaffy.realistic;

import java.util.List;
import me.skaffy.ModContent;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BoatItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item.Properties;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.EmptyBlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseTorchBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.ComparatorBlock;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.RedstoneWireBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.AABB;
import org.joml.Vector3d;
import me.skaffy.util.Nullable;

public class RealisticBlockItem extends Item {
   public RealisticBlockItem(Properties properties) {
      super(properties);
   }

   public static boolean convertible(ItemStack stack) {
      if (stack.getItem() instanceof BoatItem) {
         return true;
      } else if (!(stack.getItem() instanceof BlockItem item)) {
         return false;
      } else {
         Block block = item.getBlock();
         if (block != ModContent.WAVE_MAKER && !(block instanceof ComparatorBlock)) {
            if (!(block instanceof EntityBlock) && !BuiltInRegistries.BLOCK.getKey(block).getNamespace().equals("realistic-water")) {
               BlockState state = block.defaultBlockState();
               boolean walkThrough = block instanceof BaseTorchBlock || block instanceof RedstoneWireBlock;
               return state.getRenderShape() == RenderShape.MODEL
                  && state.getFluidState().isEmpty()
                  && (walkThrough || !state.getCollisionShape(EmptyBlockGetter.INSTANCE, BlockPos.ZERO).isEmpty());
            } else {
               return false;
            }
         } else {
            return true;
         }
      }
   }

   public static ItemStack of(Block block, int count) {
      ItemStack stack = new ItemStack(ModContent.REALISTIC_BLOCK_ITEM, count);
      stack.set(ModContent.SOURCE_BLOCK, BuiltInRegistries.BLOCK.getKey(block));
      stack.set(DataComponents.ITEM_NAME, Component.translatable("item.realistic-water.realistic_block.of", block.getName()));
      return stack;
   }

   public static ItemStack convert(ItemStack stack) {
      if (stack.getItem() instanceof BoatItem boat) {
         return RealisticBoatItem.of(boat, stack.getCount());
      } else {
         return convertible(stack) ? of(((BlockItem)stack.getItem()).getBlock(), stack.getCount()) : ItemStack.EMPTY;
      }
   }

   @Nullable
   public static Block blockOf(ItemStack stack) {
      if (!stack.is(ModContent.REALISTIC_BLOCK_ITEM)) {
         return null;
      } else {
         ResourceLocation id = (ResourceLocation)stack.get(ModContent.SOURCE_BLOCK);
         return id == null ? null : (Block)BuiltInRegistries.BLOCK.getOptional(id).orElse(null);
      }
   }

   @Override
   public InteractionResult useOn(UseOnContext context) {
      ItemStack stack = context.getItemInHand();
      Block block = blockOf(stack);
      if (block == null) {
         return InteractionResult.FAIL;
      } else {
         BlockPlaceContext place = new BlockPlaceContext(context);
         if (!place.canPlace()) {
            return InteractionResult.FAIL;
         } else {
            Level level = context.getLevel();
            BlockPos pos = place.getClickedPos();
            Vector3d center = new Vector3d(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5);

            for (RealisticBlockEntity e : level.getEntitiesOfClass(RealisticBlockEntity.class, new AABB(pos).inflate(1.0))) {
               if (e.body.containsWorld(center.x, center.y, center.z)) {
                  return InteractionResult.FAIL;
               }
            }

            BlockState state = block.getStateForPlacement(place);
            if (state == null) {
               state = block.defaultBlockState();
            }

            if (level instanceof ServerLevel server) {
               RealisticBlockEntity.spawn(server, List.of(BlockMaterials.cell(0, 0, 0, state)), center, null);
               SoundType sound = state.getSoundType();
               level.playSound(null, pos, sound.getPlaceSound(), SoundSource.BLOCKS, (sound.getVolume() + 1.0F) / 2.0F, sound.getPitch() * 0.8F);
               Player player = context.getPlayer();
               level.gameEvent(player, GameEvent.BLOCK_PLACE, pos);
               if (player == null || !player.getAbilities().instabuild) {
                  stack.shrink(1);
               }
            }

            return InteractionResult.SUCCESS;
         }
      }
   }
}
