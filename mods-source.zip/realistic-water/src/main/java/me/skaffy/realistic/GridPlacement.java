package me.skaffy.realistic;

import me.skaffy.block.WaveMakerBlock;
import me.skaffy.mixin.StandingAndWallBlockItemAccessor;
import net.minecraft.core.Direction;
import net.minecraft.world.item.StandingAndWallBlockItem;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DiodeBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.piston.PistonBaseBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.level.block.state.properties.SlabType;
import org.joml.Vector3d;
import me.skaffy.util.Nullable;

final class GridPlacement {
   private GridPlacement() {
   }

   static Direction nearestDir(double x, double y, double z) {
      Direction best = Direction.NORTH;
      double bestDot = Double.NEGATIVE_INFINITY;
      for (Direction d : Direction.values()) {
         double dot = x * d.getStepX() + y * d.getStepY() + z * d.getStepZ();
         if (dot > bestDot) {
            bestDot = dot;
            best = d;
         }
      }
      return best;
   }

   @Nullable
   static BlockState stateFor(Block block, Direction face, Vector3d hit, Vector3d look) {
      Direction horizontal = Math.abs(look.x) > Math.abs(look.z)
         ? (look.x > 0.0 ? Direction.EAST : Direction.WEST)
         : (look.z > 0.0 ? Direction.SOUTH : Direction.NORTH);
      Direction nearest = nearestDir(look.x, look.y, look.z);
      boolean upperHalf = face == Direction.DOWN || face != Direction.UP && hit.y > 0.5;
      if (block.asItem() instanceof StandingAndWallBlockItem item) {
         if (face == Direction.UP) {
            return block.defaultBlockState();
         } else if (face == Direction.DOWN) {
            return null;
         } else {
            BlockState wall = ((StandingAndWallBlockItemAccessor)item).realisticWater$wallBlock().defaultBlockState();
            return wall.hasProperty(BlockStateProperties.HORIZONTAL_FACING) ? (BlockState)wall.setValue(BlockStateProperties.HORIZONTAL_FACING, face) : wall;
         }
      } else {
         BlockState state = block.defaultBlockState();
         if (block instanceof SlabBlock) {
            return (BlockState)state.setValue(SlabBlock.TYPE, upperHalf ? SlabType.TOP : SlabType.BOTTOM);
         } else if (block instanceof StairBlock) {
            return (BlockState)((BlockState)state.setValue(StairBlock.FACING, horizontal)).setValue(StairBlock.HALF, upperHalf ? Half.TOP : Half.BOTTOM);
         } else if (block instanceof DiodeBlock) {
            return (BlockState)state.setValue(DiodeBlock.FACING, horizontal.getOpposite());
         } else if (block instanceof PistonBaseBlock) {
            return (BlockState)((BlockState)state.setValue(PistonBaseBlock.FACING, nearest.getOpposite())).setValue(PistonBaseBlock.EXTENDED, false);
         } else if (block instanceof WaveMakerBlock) {
            return (BlockState)state.setValue(WaveMakerBlock.FACING, WaveMakerBlock.placedFacing(nearest));
         } else if (state.hasProperty(BlockStateProperties.AXIS)) {
            return (BlockState)state.setValue(BlockStateProperties.AXIS, face.getAxis());
         } else if (state.hasProperty(BlockStateProperties.HORIZONTAL_FACING)) {
            return (BlockState)state.setValue(BlockStateProperties.HORIZONTAL_FACING, horizontal.getOpposite());
         } else {
            return state.hasProperty(BlockStateProperties.FACING) ? (BlockState)state.setValue(BlockStateProperties.FACING, nearest.getOpposite()) : state;
         }
      }
   }
}
