package me.skaffy.realistic;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import me.skaffy.block.WaveMakerBlock;
import me.skaffy.physics.RigidBody;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.EmptyBlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RedstoneWireBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.VoxelShape;
import me.skaffy.util.Nullable;

public final class BlockMaterials {
   public static final double WEIGHT = 0.5;
   private static final Set<SoundType> METAL = Set.of(
      SoundType.METAL,
      SoundType.ANVIL,
      SoundType.NETHERITE_BLOCK,
      SoundType.ANCIENT_DEBRIS,
      SoundType.LODESTONE,
      SoundType.CHAIN,
      SoundType.COPPER,
      SoundType.COPPER_BULB,
      SoundType.COPPER_GRATE,
      SoundType.HEAVY_CORE,
      SoundType.LANTERN
   );
   private static final Set<SoundType> LOOSE = Set.of(
      SoundType.SAND,
      SoundType.GRAVEL,
      SoundType.GRASS,
      SoundType.ROOTED_DIRT,
      SoundType.MUD,
      SoundType.SOUL_SAND,
      SoundType.SOUL_SOIL,
      SoundType.SUSPICIOUS_SAND,
      SoundType.SUSPICIOUS_GRAVEL,
      SoundType.MOSS
   );
   private static final Set<Block> FEATHER = Set.of(
      Blocks.OAK_PLANKS,
      Blocks.OAK_STAIRS,
      Blocks.OAK_LOG,
      Blocks.COBBLESTONE,
      Blocks.COBBLESTONE_SLAB,
      Blocks.COBBLESTONE_STAIRS,
      Blocks.COBBLESTONE_WALL,
      Blocks.GLASS,
      Blocks.TORCH,
      Blocks.WALL_TORCH
   );
   private static final double[][] FULL = new double[][]{{0.0, 0.0, 0.0, 1.0, 1.0, 1.0}};
   private static final double[][] NONE = new double[0][];
   private static final Map<BlockState, double[][]> SOLID = new ConcurrentHashMap<>();
   private static final Map<BlockState, double[][]> COLLISION = new ConcurrentHashMap<>();

   private BlockMaterials() {
   }

   public static double density(BlockState state) {
      SoundType sound = state.getSoundType();
      if (FEATHER.contains(state.getBlock())) {
         return 50.0;
      } else if (state.is(BlockTags.WOOL) || state.getBlock() instanceof WaveMakerBlock || state.is(Blocks.REDSTONE_BLOCK)) {
         return 250.0;
      } else if (state.is(BlockTags.LEAVES)) {
         return 300.0;
      } else if (state.is(BlockTags.LOGS)) {
         return 700.0;
      } else if (state.is(BlockTags.PLANKS)) {
         return 600.0;
      } else if (state.is(BlockTags.ICE)) {
         return 917.0;
      } else if (state.is(BlockTags.SNOW) || sound == SoundType.SNOW || sound == SoundType.POWDER_SNOW) {
         return 400.0;
      } else if (sound == SoundType.SPONGE || sound == SoundType.WET_SPONGE || sound == SoundType.SLIME_BLOCK || sound == SoundType.HONEY_BLOCK) {
         return sound == SoundType.SPONGE ? 150.0 : 1100.0;
      } else if (METAL.contains(sound)) {
         return 7800.0;
      } else if (state.ignitedByLava()) {
         return 550.0;
      } else if (sound == SoundType.GLASS) {
         return 2500.0;
      } else {
         return LOOSE.contains(sound) ? 1600.0 : 2500.0;
      }
   }

   public static boolean flammable(BlockState state) {
      return state.ignitedByLava() || state.is(BlockTags.WOOL) || state.is(BlockTags.LEAVES) || state.is(BlockTags.LOGS) || state.is(BlockTags.PLANKS);
   }

   public static double grip(float vanillaFriction) {
      return Math.clamp((1.0 - vanillaFriction) / 0.4, 0.05, 1.5);
   }

   public static RigidBody.Cell cell(int x, int y, int z, BlockState state) {
      return new RigidBody.Cell(x, y, z, density(state) * 0.5, flammable(state), grip(state.getBlock().getFriction()), state, solidBoxes(state));
   }

   @Nullable
   public static double[][] solidBoxes(BlockState state) {
      double[][] boxes = SOLID.computeIfAbsent(state, s -> {
         if (s.getBlock() instanceof RedstoneWireBlock) {
            s = s.getBlock().defaultBlockState();
         }

         double[][] b = boxes(s.getCollisionShape(EmptyBlockGetter.INSTANCE, BlockPos.ZERO));
         if (b.length == 0) {
            b = boxes(s.getShape(EmptyBlockGetter.INSTANCE, BlockPos.ZERO));
         }

         return b.length == 0 ? FULL : b;
      });
      return boxes == FULL ? null : boxes;
   }

   public static double[][] collisionBoxes(BlockState state) {
      return COLLISION.computeIfAbsent(state, s -> boxes(s.getCollisionShape(EmptyBlockGetter.INSTANCE, BlockPos.ZERO)));
   }

   private static double[][] boxes(VoxelShape shape) {
      if (shape.isEmpty()) {
         return NONE;
      } else {
         List<AABB> list = shape.toAabbs();
         double[][] out = new double[list.size()][];

         for (int i = 0; i < list.size(); i++) {
            AABB b = list.get(i);
            out[i] = new double[]{b.minX, b.minY, b.minZ, b.maxX, b.maxY, b.maxZ};
         }

         return out;
      }
   }
}
