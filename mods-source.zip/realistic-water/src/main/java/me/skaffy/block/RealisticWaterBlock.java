package me.skaffy.block;

import me.skaffy.fluid.RealisticSlimeFluid;
import me.skaffy.sim.FluidSim;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.world.phys.Vec3;

public class RealisticWaterBlock extends LiquidBlock {
   public static final BooleanProperty INFINITE = BooleanProperty.create("infinite");
   private static final Vec3 SLIME_STUCK = new Vec3(0.45, 0.3, 0.45);

   private final FlowingFluid simFluid;

   public RealisticWaterBlock(FlowingFluid fluid, BlockBehaviour.Properties properties) {
      super(fluid, properties);
      this.simFluid = fluid;
      this.registerDefaultState(this.defaultBlockState().setValue(INFINITE, false));
   }

   public static boolean isInfinite(BlockState state) {
      return state.getBlock() instanceof RealisticWaterBlock && state.getValue(INFINITE);
   }

   @Override
   protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
      super.createBlockStateDefinition(builder);
      builder.add(INFINITE);
   }

   protected FluidSim.Kind kind() {
      return this.simFluid instanceof RealisticSlimeFluid ? FluidSim.Kind.SLIME : FluidSim.Kind.WATER;
   }

   @Override
   protected void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
      if (level instanceof ServerLevel server) {
         FluidSim.wake(server, pos, this.kind());
      }
   }

   @Override
   protected void neighborChanged(BlockState state, Level level, BlockPos pos, Block block, BlockPos fromPos, boolean movedByPiston) {
      if (level instanceof ServerLevel server) {
         FluidSim.wake(server, pos, this.kind());
      }
   }

   @Override
   protected boolean propagatesSkylightDown(BlockState state, net.minecraft.world.level.BlockGetter level, BlockPos pos) {
      return true;
   }

   @Override
   protected void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
      if (RealisticSlimeFluid.isRealistic(state.getFluidState())) {
         entity.makeStuckInBlock(state, SLIME_STUCK);
      }
   }
}
