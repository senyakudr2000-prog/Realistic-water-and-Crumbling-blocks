package me.skaffy.block;

import me.skaffy.sim.LooseSim;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.tags.TagKey;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.EntityCollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public abstract class LooseLayerBlock extends Block {
   public static final int MAX_LAYERS = 8;
   public static final IntegerProperty LAYERS = BlockStateProperties.LAYERS;
   private static final VoxelShape[] SHAPES = new VoxelShape[9];

   static {
      for (int h = 0; h <= 8; h++) {
         SHAPES[h] = Block.box(0.0, 0.0, 0.0, 16.0, h * 2, 16.0);
      }
   }

   protected LooseLayerBlock(BlockBehaviour.Properties properties) {
      super(properties);
      this.registerDefaultState(this.stateDefinition.any().setValue(LAYERS, 8));
   }

   protected abstract TagKey<Item> digTool();

   @Override
   protected RenderShape getRenderShape(BlockState state) {
      return RenderShape.MODEL;
   }

   @Override
   protected void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
      if (level instanceof ServerLevel server) {
         LooseSim.wake(server, pos, this);
      }
   }

   @Override
   protected void neighborChanged(BlockState state, Level level, BlockPos pos, Block block, BlockPos fromPos, boolean movedByPiston) {
      if (level instanceof ServerLevel server) {
         LooseSim.wake(server, pos, this);
      }
   }

   @Override
   protected void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
      LooseSim.tick(level, pos, this);
   }

   @Override
   protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
      return context instanceof EntityCollisionContext entityContext
            && entityContext.getEntity() instanceof Player player
            && player.getMainHandItem().is(this.digTool())
         ? SHAPES[state.getValue(LAYERS)]
         : Shapes.empty();
   }

   @Override
   protected VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
      return Shapes.empty();
   }

   @Override
   protected VoxelShape getBlockSupportShape(BlockState state, BlockGetter level, BlockPos pos) {
      return SHAPES[state.getValue(LAYERS)];
   }

   @Override
   protected VoxelShape getVisualShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
      return Shapes.empty();
   }

   @Override
   protected boolean propagatesSkylightDown(BlockState state, BlockGetter level, BlockPos pos) {
      return true;
   }

   @Override
   protected boolean isPathfindable(BlockState state, PathComputationType type) {
      return true;
   }

   @Override
   protected boolean canBeReplaced(BlockState state, BlockPlaceContext context) {
      return context.getItemInHand().is(this.asItem()) ? state.getValue(LAYERS) < 8 : true;
   }

   @Override
   protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
      builder.add(LAYERS);
   }
}
