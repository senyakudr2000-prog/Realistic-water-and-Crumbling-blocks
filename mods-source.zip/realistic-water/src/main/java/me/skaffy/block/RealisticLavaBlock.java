package me.skaffy.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FlowingFluid;

public class RealisticLavaBlock extends RealisticWaterBlock {
   public RealisticLavaBlock(FlowingFluid fluid, BlockBehaviour.Properties properties) {
      super(fluid, properties);
   }

   @Override
   protected me.skaffy.sim.FluidSim.Kind kind() {
      return me.skaffy.sim.FluidSim.Kind.LAVA;
   }

   @Override
   protected boolean propagatesSkylightDown(BlockState state, BlockGetter level, BlockPos pos) {
      return false;
   }
}
