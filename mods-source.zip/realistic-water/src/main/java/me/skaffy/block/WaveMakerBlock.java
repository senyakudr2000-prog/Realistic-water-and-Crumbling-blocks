package me.skaffy.block;

import me.skaffy.util.Nullable;
import me.skaffy.ModContent;
import me.skaffy.sim.FluidSim;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DirectionalBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;

public class WaveMakerBlock extends Block {
   public static final DirectionProperty FACING = DirectionalBlock.FACING;
   public static final IntegerProperty POWER = BlockStateProperties.POWER;
   public static final IntegerProperty SPEED = IntegerProperty.create("speed", 0, 2);
   private static final String[] SPEED_NAMES = new String[]{"slow", "medium", "fast"};

   public WaveMakerBlock(BlockBehaviour.Properties properties) {
      super(properties);
      this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(POWER, 0).setValue(SPEED, 1));
   }

   @Nullable
   @Override
   public BlockState getStateForPlacement(BlockPlaceContext context) {
      return this.defaultBlockState()
         .setValue(FACING, placedFacing(context.getNearestLookingDirection()))
         .setValue(POWER, context.getLevel().getBestNeighborSignal(context.getClickedPos()));
   }

   public static Direction placedFacing(Direction look) {
      return look.getAxis().isVertical() ? look.getOpposite() : look;
   }

   @Override
   protected void neighborChanged(BlockState state, Level level, BlockPos pos, Block block, BlockPos fromPos, boolean movedByPiston) {
      if (!level.isClientSide()) {
         int power = level.getBestNeighborSignal(pos);
         if (power != state.getValue(POWER)) {
            level.setBlock(pos, state.setValue(POWER, power), 2);
         }

         if (power > 0 && level instanceof ServerLevel server) {
            server.scheduleTick(pos, this, 4);
         }
      }
   }

   @Override
   protected void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
      if (state.getValue(POWER) > 0 && level instanceof ServerLevel server) {
         server.scheduleTick(pos, this, 4);
      }
   }

   @Override
   protected void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
      if (state.getValue(POWER) <= 0) {
         return;
      }

      Direction facing = state.getValue(FACING);
      int units = 1 << (state.getValue(SPEED) + 1);
      FluidSim.pump(level, pos.relative(facing.getOpposite()), pos.relative(facing), units);
      if (random.nextInt(8) == 0) {
         level.playSound(null, pos, ModContent.WAVE_MAKER_RUN, SoundSource.BLOCKS, 0.4F, 1.0F);
      }

      level.scheduleTick(pos, this, 4);
   }

   @Override
   protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hitResult) {
      if (!level.isClientSide()) {
         BlockState next = state.cycle(SPEED);
         level.setBlock(pos, next, 2);
         announceSpeed(level, player, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, next);
      }

      return InteractionResult.SUCCESS;
   }

   public static void announceSpeed(Level level, Player player, double x, double y, double z, BlockState next) {
      level.playSound(null, x, y, z, SoundEvents.COMPARATOR_CLICK, SoundSource.BLOCKS, 0.5F, 0.6F + 0.2F * next.getValue(SPEED));
      player.displayClientMessage(
         Component.translatable(
            "block.realistic-water.wave_maker.speed",
            Component.translatable("block.realistic-water.wave_maker.speed." + SPEED_NAMES[next.getValue(SPEED)])
         ),
         true
      );
   }

   @Override
   protected BlockState rotate(BlockState state, Rotation rotation) {
      return state.setValue(FACING, rotation.rotate(state.getValue(FACING)));
   }

   @Override
   protected BlockState mirror(BlockState state, Mirror mirror) {
      return state.rotate(mirror.getRotation(state.getValue(FACING)));
   }

   @Override
   protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
      builder.add(FACING, POWER, SPEED);
   }
}
