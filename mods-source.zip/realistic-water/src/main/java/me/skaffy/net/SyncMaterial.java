package me.skaffy.net;

import me.skaffy.ModContent;
import net.minecraft.world.level.block.Block;

public final class SyncMaterial {
   public static final byte WATER = 0;
   public static final byte SAND = 1;
   public static final byte LAVA = 2;
   public static final byte SLIME = 3;
   public static final byte LEAVES = 4;

   private SyncMaterial() {
   }

   public static Block block(byte material) {
      return switch (material) {
         case 1 -> ModContent.REALISTIC_SAND;
         case 2 -> ModContent.REALISTIC_LAVA_BLOCK;
         case 3 -> ModContent.REALISTIC_SLIME_BLOCK;
         case 4 -> ModContent.REALISTIC_LEAVES;
         default -> ModContent.REALISTIC_WATER_BLOCK;
      };
   }

   public static String label(byte material) {
      return switch (material) {
         case 1 -> "sand";
         case 2 -> "lava";
         case 3 -> "slime";
         case 4 -> "leaves";
         default -> "water";
      };
   }
}
